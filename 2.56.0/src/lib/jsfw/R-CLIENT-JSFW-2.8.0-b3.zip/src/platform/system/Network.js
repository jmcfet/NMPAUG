/**
 * Exposes methods to get the current network connection type and allows the calling application to be
 * notified when the network connection type changes.
 *
 * @class $N.platform.system.Network
 * @singleton
 *
 */
/*global define */
define('jsfw/platform/system/Network',
	[],
	function () {
		window.$N = $N || {};
		$N.platform = $N.platform || {};
		$N.platform.system = $N.platform.system || {};

		$N.platform.system.Network = (function () {
			var listeners = [],
				connectionState,
				connectionType,
				TYPE = {					
					OFFLINE: "offline",
					ONLINE: "online",
					NONE: "none"
				};

			/**
			 * Gets the network connection type.
			 * @method getConnectionType
			 * @return {String} Network connection type. E.G. 3g, WIFI, offline, online
			 */
			function getConnectionType() {
				
				if (window.navigator && window.navigator.connection) {
					if (window.navigator.connection.type === TYPE.NONE) {
						return TYPE.OFFLINE; // mobile connection offline
					}
					return window.navigator.connection.type;
				} 
				
				if (connectionState === TYPE.OFFLINE) {
					return TYPE.OFFLINE;
				}

				return TYPE.ONLINE; 
			}

			/**
			 * Checks if the connection type has changed. Executes any listeners if true.
			 * @method _checkForConnectionTypeChange
			 * @private
			 */
			function _checkForConnectionTypeChange(state) {
				var newConnection;
				
				connectionState = state;
				newConnection = getConnectionType();
				
				if (connectionType !== newConnection ) {
					connectionType = newConnection;
					_executeListeners(connectionType);
				}
			}

			/**
			 * Executes each listener passing the new connection type
			 * @method _executeListeners
			 * @param connectionType the new connection type
			 * @private
			 */
			function _executeListeners(connectionType) {
				listeners.forEach(function (listener) {
					listener(connectionType);
				});
			}

			/**
			 * Called by NMP when the network enters an online state
			 * @method ononline
			 * @private
			 */
			window.ononline = function () {
				_checkForConnectionTypeChange(TYPE.ONLINE);
			};

			/**
			 * Called by NMP when the network enters an offline state
			 * @method onoffline
			 * @private
			 */
			window.onoffline = function () {
				_checkForConnectionTypeChange(TYPE.OFFLINE);
			};

			/**
			 * Registers a network type change listener which will be executed when the network connection type changes
			 * @method registerListener
			 * @param {Function} listener Network connection change listener function to add
			 */
			function registerListener(listener) {
				listeners.push(listener);
			}

			/**
			 * Unregisters a network type change listener.
			 * @method unregisterListener
			 * @param {Function} listener Network connection change listener function to remove
			 */
			function unregisterListener(listener) {
				var i;
				for (i = 0; i < listeners.length; i++) {
					if (listeners[i].listener === listener) {
						listeners.splice(i, 1);
						break;
					}
				}
			}

			return {
				getConnectionType: getConnectionType,
				registerListener: registerListener,
				unregisterListener: unregisterListener
			};
		}());
		return $N.platform.system.Network;
	});