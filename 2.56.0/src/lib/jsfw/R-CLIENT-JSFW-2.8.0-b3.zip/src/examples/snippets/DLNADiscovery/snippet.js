/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require([
	'jsfw/platform/output/PlayoutManager',
	'jsfw/platform/media/DLNA'],
	function (PlayoutManager, DLNA) {
		var playoutManager;

		function showServerMessage(html) {
			$("#status").html(html);
		}

		function getDeviceListCallback(devices) {
			var i;
			
			$("#discoverDevices").show();
			$("#deviceContainer").show();
			showServerMessage("Network Device Discovery Complete");

			for (i = 0; i < devices.length; i++) {
				$("#devices").append("<li>" + devices[i].modelDescription + "</li>");
			}
			$("#deviceContainer").show();
			showServerMessage("Network Device Discovery Complete");
		}

		function discoverDevices() {
			var devices = DLNA.getDeviceList(getDeviceListCallback, DLNA.SERVICETYPE['BROWSE']);
			showServerMessage("Discovering DLNA Compatible Devices on the Network.... ");
			$("#deviceContainer").hide();
			$("#devices").empty();
		}

		(function init() {
			$("#discoverDevices").click(discoverDevices);

			playoutManager = new PlayoutManager({
				parent : document.getElementById("player"),
				videoLoadedCallback : discoverDevices,
				forceHTML : false,
				attributes : {
					width : 0,
					height : 0,
					controls : false,
					autoPlay : false
				}
			});
		}());
	});