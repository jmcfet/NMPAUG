/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('vodView',
	[],
	function () {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.vodView = (function () {

			var limitList = $("#limitList")[0],
				sortList1 = $("#sortList1")[0],
				sortList2 = $("#sortList2")[0],
				deviceList = $("#deviceList")[0],
				eventInfo = $("#eventObj"),
				notificationMessage = $("#notification"),
				productNotification = $("#products"),
				savedEvents = {},
				prop,
				$detailsDialog;

/*
 * INITIALISE DATA
 */
			function populateLimitList() {
				var i,
					optionName;
				for (i = 1; i < 21; i++) {
					optionName = new Option(i, i);
					limitList.options[limitList.length] = optionName;
				}
			}

			function populateSortList() {
				var optionName;

				optionName = new Option('None', 'None');
				sortList1.options[sortList1.length] = optionName;

				optionName = new Option('Title', 'editorial.title');
				sortList1.options[sortList1.length] = optionName;

				optionName = new Option('Rating', 'editorial.Rating');
				sortList1.options[sortList1.length] = optionName;

				optionName = new Option('Price', 'product.price.value');
				sortList1.options[sortList1.length] = optionName;

				optionName = new Option('None', 'None');
				sortList2.options[sortList2.length] = optionName;

				optionName = new Option('Title', 'editorial.title');
				sortList2.options[sortList2.length] = optionName;

				optionName = new Option('Rating', 'editorial.Rating');
				sortList2.options[sortList2.length] = optionName;

				optionName = new Option('Price', 'product.price.value');
				sortList2.options[sortList2.length] = optionName;
			}

			function populateDeviceList() {
				var optionName,
					targetLength;

				optionName = new Option('', 'ALL');
				targetLength = deviceList.length;
				deviceList.options[targetLength] = optionName;

				optionName = new Option('PC', 'PC');
				targetLength = deviceList.length;
				deviceList.options[targetLength] = optionName;

				optionName = new Option('TABLET', 'TABLET');
				targetLength = deviceList.length;
				deviceList.options[targetLength] = optionName;

				optionName = new Option('PHONE', 'PHONE');
				targetLength = deviceList.length;
				deviceList.options[targetLength] = optionName;

				optionName = new Option('STB', 'STB');
				targetLength = deviceList.length;
				deviceList.options[targetLength] = optionName;
			}

/*
 * INITIALISE
 */
			function initialiseDialog() {
			}

			function init() {
				$detailsDialog = $('#details').dialog({
					autoOpen: false,
					width: 800,
					height: 500,
					close: function (event, ui) {
						$(this).dialog('close');
					}
				});
				populateLimitList();
				populateSortList();
				populateDeviceList();
			}

/*
 * POPULATE DATA
 */
			function populateCatalogues(catalogueList, elementId) {
				var currentCatalogue,
					catalogueOption,
					catalogueName,
					catalogueId,
					i,
					$catalogueList = $('#' + elementId);

				$catalogueList.empty();

				for (i = 0; i < catalogueList.length; i++) {
					currentCatalogue = catalogueList[i];
					catalogueOption = $('<option />');
					catalogueName = currentCatalogue.Title + ' (' + currentCatalogue.id + ')';
					catalogueId = currentCatalogue.id;
					catalogueOption.text(catalogueName).val(currentCatalogue.id);
					catalogueOption.text(catalogueName).val(catalogueId);
					$catalogueList.append(catalogueOption);
				}
				$('#getChildCatalogues').show();
			}

			function showNotificationMessage(message) {
				notificationMessage.html('<p>' + message + '</p>').show();
			}

			function showProductNotification(message) {
				productNotification.html('<p>' + message + '</p>').show();
			}

			function populateAssets(assets, count) {
				var i,
					assetsHtml = '',
					currentAsset;

				if (assets && assets.length > 0) {
					assetsHtml += '<p>' + count + ' assets available for catalogue</p>';
					for (i = 0; i < assets.length; i++) {
						currentAsset = assets[i];
						currentAsset.parentalRatingValue = currentAsset.parentalRatingValue ? (' : ' + currentAsset.parentalRatingValue) : '';
						assetsHtml += '<p id="' + currentAsset.id + '">' + currentAsset.Title + currentAsset.parentalRatingValue + '</p>\n';
					}
				} else {
					assetsHtml += '<p>No assets available for catalogue</p>';
				}
				showNotificationMessage(assetsHtml);
			}

			function populateProducts(products, detailCallback) {
				var i,
					productsHtml = '',
					currentProduct;

				if (products && products.length > 0) {
					productsHtml += '<p>' + products.length + ' products available for asset</p>';
					for (i = 0; i < products.length; i++) {
						currentProduct = products[i];
						currentProduct.cost = currentProduct.price.value + " " +  currentProduct.price.currency;
						productsHtml += '<p id="' + currentProduct.id + '">' + currentProduct.title + " - " + currentProduct.cost + '</p>\n';
					}
				} else {
					productsHtml += '<p>No products available for assets</p>';
				}
				showProductNotification(productsHtml);
			}

/*
 * POPULATE PRETTIFIED DATA
 */

			function prettify(objects, title) {
				$('#details').html(prettyPrint(objects));
				$detailsDialog.dialog({title: title});
				$detailsDialog.dialog('open');
			}

			function showAsset(asset) {
				$detailsDialog.dialog('close');
				prettify(asset, asset.Title + " - Asset details");
			}

			function showPurchasedAssets(assets) {
				$detailsDialog.dialog('close');
				prettify(assets, "List of purchased assets");
			}

			function hidePurchase() {
				$('#purchase').hide();
				$('#purchaseWithPromotion').hide();
			}

			function showIsPurchased() {
				$('#isPurchased').show();
			}

			function showProducts(selectedAsset, detailCallback) {
				var i,
					products = [];
				for (i = 0; i < selectedAsset.technicals.length; i++) {
					products = products.concat(selectedAsset.technicals[i].products);
				}
				populateProducts(products, detailCallback);
				//showIsPurchased();
				//hidePurchase();
			}

			function showProductDetails(selectedProduct) {
				$detailsDialog.dialog('close');
				prettify(selectedProduct, selectedProduct.title + " - Product details");
			}

/*
 * SHOW / HIDE ELEMENTS
 */
			function hideElements() {
				$('#getChildCatalogues').hide();
				$('#getAssets').hide();
				$('#getPagedAssets').hide();
				$('#limit').hide();
				$('#catalogueContainer').hide();
				$('#childCatalogues').hide();
				if ($detailsDialog.dialog('isOpen')) {
					$('#details').empty();
					$detailsDialog.dialog('close');
				}
				$('#getContentType').hide();
			}

			function showElements() {
				$('#getAssets').show();
				$('#getPagedAssets').show();
				$('#limitList').show();
				$('#catalogueList').show();
				$('#catalogueListLabel').show();
				$('#sortList1').show();
				$('#sortList2').show();
				$('#sortListLabel').show();
				$('#sortOption').show();
				$('#catalogueContainer').show();
				$('#deviceList').show();
				$('#setDeviceType').show();
				$('#promotionIdInputLabel').show();
				$('#getAssetsByPromotionId').show();
				$('#getPagedAssetsByPromotionId').show();
				$('#promotionIdInput').show();
				$('#notification').hide();
			}

			function hideChildCatalogues() {
				$('#childCatalogues').hide();
			}

			function showChildCatalogues() {
				$('#childCatalogues').show();
				if ($detailsDialog.dialog('isOpen')) {
					$('#details').empty();
					$detailsDialog.dialog('close');
				}
			}

			function initialiseChildCatalogues() {
				$('#childCatalogues').empty();
				hideChildCatalogues();
			}

			function showPurchase() {
				$('#purchase').show();
			}

			function showPurchaseWithPromotion() {
				$('#purchaseWithPromotion').show();
			}

			function showPlay() {
				$('#playButton').show();
			}

			function hidePlay() {
				$('#playButton').hide();
			}

			function isPlayShown() {
				return $('#playButton').is(":visible");
			}

			function showButton() {
				$('#getPurchasedAssets').show();
				$('#getContentType').show();
			}
/*
 * RETURN DATA
 */
			function getSelectedCatalogue() {
				return $('#childCatalogues').val() || $('#catalogueList').val();
			}

			function getSortArray() {
				var sortArray = [];
				if ($('#sortList1').val() === 'None') {
					sortArray = null;
				} else {
					if ($('#sortDescending').is(':checked')) {
						sortArray.push([$('#sortList1').val(), -1]);
					} else {
						sortArray.push([$('#sortList1').val(), 1]);
					}
					if ($('#sortList2').val() === 'None') {
					} else {
						if ($('#sortDescending').is(':checked')) {
							sortArray.push([$('#sortList2').val(), -1]);
						} else {
							sortArray.push([$('#sortList2').val(), 1]);
						}
					}
				}
				return sortArray;
			}

			function getDeviceTypeArray() {
				var i,
					deviceArray = [];

				for (i = 0; i < deviceList.options.length; i++) {
					if (deviceList.options[i].selected === true) {
						if (deviceList.options[i].value === 'ALL') {
							deviceArray = [];
							break;
						}
						deviceArray.push(deviceList.options[i].value);
					}
				}
				return deviceArray;
			}

			function getPagingList() {
				return parseInt($('#limitList').val(), 10);
			}

			function getPromotionId() {
				return $('#promotionIdInput').val();
			}

			/*
			 * Public API
			 */
			return {
				init: init,
				populateCatalogues: populateCatalogues,
				showNotificationMessage: showNotificationMessage,
				populateAssets: populateAssets,
				showProducts: showProducts,
				showProductDetails: showProductDetails,
				showAsset: showAsset,
				showPurchasedAssets: showPurchasedAssets,
				hideElements: hideElements,
				showElements: showElements,
				hideChildCatalogues: hideChildCatalogues,
				showChildCatalogues: showChildCatalogues,
				initialiseChildCatalogues: initialiseChildCatalogues,
				showIsPurchased: showIsPurchased,
				showPurchase: showPurchase,
				showPurchaseWithPromotion: showPurchaseWithPromotion,
				hidePurchase: hidePurchase,
				showPlay: showPlay,
				hidePlay: hidePlay,
				isPlayShown: isPlayShown,
				getSelectedCatalogue: getSelectedCatalogue,
				getSortArray: getSortArray,
				getDeviceTypeArray: getDeviceTypeArray,
				getPagingList: getPagingList,
				getPromotionId: getPromotionId,
				showButton: showButton
			};
		}());
		return $N.app.vodView;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('vodModel',
	[
		'jsfw/Config',
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/BaseService',
		'jsfw/services/sdp/Signon',
		'jsfw/services/sdp/AcquiredContent',
		'jsfw/services/sdp/VOD',
		'jsfw/services/sdp/Ratings',
		'jsfw/platform/output/PlayoutManager',
		'jsfw/services/sdp/MetadataService',
		'jsfw/services/sdp/ServiceFactory',
		'jsfw/services/sdp/Promotions'
	],
	function (Config, Log, BaseService, Signon, AcquiredContent, VOD, Ratings, PlayoutManager, MetadataService, ServiceFactory, Promotions) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.vodModel = (function () {

			var MDS = {},
				SDP = {},
				promotionsSupported = true,
				userId,
				password,
				accountUid,
				userUid,
				locale,
				player,
				videoPath,
				signOnSuccessCallback,
				device;

/*
 * CONFIGURATION
 */
			function usePromotions(isPromotionsSupported) {
				promotionsSupported = isPromotionsSupported;
			}

			function init(mds, sdp, DEFAULT_DEVICE, VIDEO_PATH, signOnFailureCallback) {
				$N.apps.core.Log.Config.configure({
					defaultValues: 0,
					classLogging: {
						VOD: 1,
						DRM: 1,
						PRM: 1,
						MetadataService: 0,
						PlayoutManager: 1,
						AcquiredContent: 1
					}
				});

				MDS = mds;
				SDP = sdp;
				device = DEFAULT_DEVICE;
				userId = SDP.USER;
				password = SDP.PASSWORD;
				videoPath = VIDEO_PATH;
				$N.services.sdp.Signon.setSignonFailedCallback(signOnFailureCallback);
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, null, MDS.LOCALE);
			}

/*
 * REFRESH ACQUIRED CONTENT
 */

			function registerAcquiredContentRefreshListener(listener) {
				$N.services.sdp.AcquiredContent.registerAclChangeCallBack(listener);
			}

			function removeAcquiredContentRefreshListener() {
				$N.services.sdp.AcquiredContent.removeAclChangeCallback();
			}

			function refreshAcquiredContent() {
				$N.services.sdp.AcquiredContent.refresh();
			}

/*
 * INITIALISATION
 */
			function initialisation() {
				removeAcquiredContentRefreshListener();
				$N.services.sdp.VOD.initialise(userUid, accountUid, null, true, locale, [device]);
				$N.services.sdp.AcquiredContent.initialise(accountUid, locale);
				$N.services.sdp.Ratings.cacheRatingTable(locale, function () {}, function () {});
				if (promotionsSupported) {
					$N.services.sdp.Promotions.initialise();
				}
			}

			function getContext(callback) {
				$N.services.sdp.ServiceFactory.get("ContextService").getCurrentContext(this, function (context) {
					userUid = context.userUid;
					accountUid = context.accountUid;
					locale = context.locale;
					initialisation();
					callback ? callback() : signOnSuccessCallback();
				}, function () {});
			}

/*
 * SIGN ON BY USER
 */
			function signonByUserAndDevice(callback) {
				var successCallback = function () {
					getContext(callback);
				};
				$N.services.sdp.Signon.init();
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, MDS.LOCALE);
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.registerListener(successCallback, this);
				$N.services.sdp.Signon.signonByUser(userId, password);
			}
/*
 * SIGN ON AND INITIALISE BY NMP
 */
			function initialiseAndSignon() {
				var successCallback = function () {
					getContext(null);
				};
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.init();
				$N.services.sdp.Signon.registerListener(successCallback, this);
				$N.services.sdp.Signon.signonAndInitialiseForNMP(userId, password);
				if (promotionsSupported) {
					$N.services.sdp.Promotions.initialise();
				}
			}

			function setPlayoutManager(callback) {
				signOnSuccessCallback = callback;
				player = new $N.platform.output.PlayoutManager({parent: document.getElementById("vodPlayout"), videoLoadedCallback: initialiseAndSignon, forceHTML: false, attributes: {width: 320, height: 180, controls: true, autoPlay: true } });
				if (videoPath) {
					player.setVideoPath(videoPath);
				}
			}

/*
 * GET CATALOGUES
 */
			function setDeviceType(array) {
				$N.services.sdp.VOD.setFeatureNameList(array);
			}

			function getRootCatalogues(successCallback, failureCallback) {
				$N.services.sdp.VOD.getRootCatalogues(successCallback, null, failureCallback);
			}

			function getDetailedCatalogues(successCallback, failureCallback, catalogueId) {
				$N.services.sdp.VOD.getDetailedCatalogues(successCallback, null, failureCallback, catalogueId);
			}

			function getCatalogueScheduleCount(successCallback, failureCallback, selectedCatalogue, assetString) {
				$N.services.sdp.VOD.getCatalogueScheduleCount(successCallback, failureCallback, selectedCatalogue, assetString);
			}
/*
 * GET ASSETS
 */
			function getDetailedAssets(successCallback, catalogueId, sortArray) {
				$N.services.sdp.VOD.getDetailedAssets(null, successCallback, null, catalogueId, null, sortArray);
			}

			function getDetailedAssetByUid(assetId, successCallback) {
				$N.services.sdp.VOD.getDetailedAssetByUid(assetId, successCallback, null, true);
			}

			function getPagedDetailedAssets(getAssetsCallback, detailSuccessCallback, failureCallback, selectedCatalogue, startIndex, endIndex, sortArray) {
				$N.services.sdp.VOD.getPagedDetailedAssets(getAssetsCallback, detailSuccessCallback, failureCallback, selectedCatalogue, null, startIndex, endIndex, sortArray);
			}

			function getAssetsByPromotionId(promotionId, successCallback, failureCallback, sortArray) {
				$N.services.sdp.VOD.getAssetsByPromotionId(promotionId, successCallback, failureCallback, true, sortArray);
			}

			function getPagedAssetsByPromotionId(promotionId, successCallback, failureCallback, sortArray, startIndex, endIndex) {
				$N.services.sdp.VOD.getPagedAssetsByPromotionId(promotionId, successCallback, failureCallback, true, sortArray, startIndex, endIndex);
			}

			function getAssetsByPromotionIdCount(promotionId, successCallback, failureCallback) {
				$N.services.sdp.VOD.getAssetsByPromotionIdCount(promotionId, successCallback, failureCallback);
			}

/*
 * GET PURCHASED ASSETS (ACQUIRED CONTENT)
 */
			function getAssetsWithEditorialData() {
				return $N.services.sdp.AcquiredContent.getAssetsWithEditorialData();
			}

/*
 * GET PROMOTION PRICE FOR PROMOTIONS
 */
			function getPromotionPricesForProduct(product) {
				return $N.services.sdp.Promotions.getAllPricesForProduct(product);
			}

/*
 * CHECK ACQUIRED CONTENT LIST
 */
			function getTechnicalAssetId(inAsset) {
				return inAsset.technicals[0].id;
			}

			function getEditorialAssetId(inAsset) {
				return inAsset.id;
			}

			function getProductId(inAsset) {
				return inAsset.technicals[0].products[0].id;
			}

			function isAssetPurchased(selectedAsset) {
				return $N.services.sdp.AcquiredContent.isAssetPurchased(getTechnicalAssetId(selectedAsset)) || $N.services.sdp.AcquiredContent.doesContainPurchasedAsset(getEditorialAssetId(selectedAsset));
			}

			function isAssetSubscribed(selectedAsset) {
				return $N.services.sdp.AcquiredContent.isAssetSubscribed(getTechnicalAssetId(selectedAsset)) ||  $N.services.sdp.AcquiredContent.doesContainSubscribedAsset(getEditorialAssetId(selectedAsset));
			}

			function getAssetExpiryDate(selectedAsset) {
				return $N.services.sdp.AcquiredContent.getAssetExpiryDate(getTechnicalAssetId(selectedAsset)) || $N.services.sdp.AcquiredContent.getPolicyGroupExpiryDate(getProductId(selectedAsset));
			}

/*
 * PURCHASE PRODUCT
 */
			function subscribeToPolicyGroup(selectedProduct, caller, successCallback, failCallback) {
				$N.services.sdp.VOD.subscribeToPolicyGroup(selectedProduct.id, caller, successCallback, failCallback);
			}

			function subscribeToPolicyGroupWithPromotion(selectedProduct, caller, successCallback, failCallback, promotionId) {
				$N.services.sdp.VOD.subscribeToPolicyGroup(selectedProduct.id, caller, successCallback, failCallback, promotionId);
			}

/*
 * PLAY CONTENT
 */
			function playContent(asset) {
				player.playContent(asset);
			}

			function getContentType() {
				var contentType;
				switch (player.getContentType()) {
				case player.CONTENT_TYPE.BTV:
					contentType = "BTV";
					break;
				case player.CONTENT_TYPE.VOD:
					contentType = "VOD";
					break;
				case null:
					contentType = "No content mapper provided or playContent not yet called";
					break;
				default:
					contentType = null;
				}
				return contentType;
			}

			return {
				init: init,
				usePromotions: usePromotions,
				signonByUserAndDevice: signonByUserAndDevice,
				setPlayoutManager: setPlayoutManager,
				setDeviceType: setDeviceType,
				getRootCatalogues: getRootCatalogues,
				getDetailedCatalogues: getDetailedCatalogues,
				getCatalogueScheduleCount: getCatalogueScheduleCount,
				getDetailedAssets: getDetailedAssets,
				getPagedDetailedAssets: getPagedDetailedAssets,
				getDetailedAssetByUid: getDetailedAssetByUid,
				getAssetsWithEditorialData: getAssetsWithEditorialData,
				subscribeToPolicyGroup: subscribeToPolicyGroup,
				subscribeToPolicyGroupWithPromotion: subscribeToPolicyGroupWithPromotion,
				refreshAcquiredContent: refreshAcquiredContent,
				registerAcquiredContentRefreshListener: registerAcquiredContentRefreshListener,
				removeAcquiredContentRefreshListener: removeAcquiredContentRefreshListener,
				isAssetPurchased: isAssetPurchased,
				isAssetSubscribed: isAssetSubscribed,
				getAssetExpiryDate: getAssetExpiryDate,
				getAssetsByPromotionId: getAssetsByPromotionId,
				getPagedAssetsByPromotionId: getPagedAssetsByPromotionId,
				getAssetsByPromotionIdCount: getAssetsByPromotionIdCount,
				getPromotionPricesForProduct: getPromotionPricesForProduct,
				playContent: playContent,
				getContentType: getContentType
			};
		}());
		return $N.app.vodModel;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('vodController',
	[
		'vodView',
		'vodModel'
	],
	function (VODView, VODModel) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.vodController = (function () {



			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp'
				},

			/*
			var	MDS = {
					LOCALE : "en_GB",
					URL : "ms22-01-srv01.mspu.hq.k.grp",
					PATH : "/metadata/delivery",
					PORT : "",
					SERVICE_PROVIDER : "CMS4X"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ms22-01-srv01.mspu.hq.k.grp",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp'
				},
			*/
				USE_PROMOTIONS = false,
				SIGN_ON_BY_NMP = true,
				DEFAULT_DEVICE = "PC",
				VIDEO_PATH = "http://ott.nagra.com/stable/videopath/",
				TEST_END_TO_END = true,
				isSigningOn = true,
				pagingLimit = null,
				totalPagedAssetsCount = 0,
				totalCount = 0,
				selectedAsset = null,
				selectedProduct = null,
				pagedResultSetIndex = 0,
				hasSignedOn = false,
				resultSetIndex = 0;

	/*
	 * INITIALISE
	 */
			function signOnFailureCallback(error) {
				hasSignedOn = false;
				alert("SIGN ON FAILED!!! " + error.response + " failure type " + error.failure);
			}

			function initialise() {
				VODView.init();
				VODView.hideElements();
				VODModel.usePromotions(USE_PROMOTIONS);
				VODModel.init(MDS, SDP, DEFAULT_DEVICE, VIDEO_PATH, signOnFailureCallback);
			}

	/*
	 * GET ACQUIRED CONTENT (PURCHASED ASSETS)
	 */
			function registerAcquiredContentRefreshListener() {
				var acquiredContentRefreshed = function () {
					if (isSigningOn) {
						isSigningOn = false;
					} else {
						alert("acquired content refresh successful");
					}
				};
				VODModel.registerAcquiredContentRefreshListener(acquiredContentRefreshed);
			}

			function getPurchasedAssets() {
				VODView.showPurchasedAssets(VODModel.getAssetsWithEditorialData());
			}

	/*
	 * SIGN ON
	 */
			function signOnSuccessCallback() {
				VODView.showButton();
				hasSignedOn = true;
				registerAcquiredContentRefreshListener();
			}

			function signOn() {
				if (SIGN_ON_BY_NMP) {
					VODModel.setPlayoutManager(signOnSuccessCallback);
				} else {
					VODModel.signonByUserAndDevice(signOnSuccessCallback);
				}
			}

	/*
	 * GET CATALOGUES
	 */
			function populateRootCatalogue() {
				var successCallback = function (catalogues) {
						var cataloguesHtml = '';
						if (catalogues && catalogues.length) {
							VODView.populateCatalogues(catalogues, 'catalogueList');

						} else {
							VODView.hideChildCatalogues();
							VODView.showNotificationMessage("No root catalogues available");
						}
					},
					failureCallback = function () {
						alert('* rootCatalogue failure ');
					};
				VODView.showElements();
				VODModel.getRootCatalogues(successCallback, failureCallback);
				VODModel.setDeviceType(VODView.getDeviceTypeArray());
			}

			function populateChildCatalogues() {
				var	successCallback = function (catalogues) {
						if (catalogues && catalogues.length) {
							VODView.populateCatalogues(catalogues, 'childCatalogues');
							VODView.showChildCatalogues();
						} else {
							VODView.initialiseChildCatalogues();
						}
					},
					failureCallback = function () {
						VODView.initialiseChildCatalogues();
					};
				VODModel.getDetailedCatalogues(successCallback, failureCallback, $('#catalogueList').val());
			}

			function getScheduleCount(countCallback, isFiltered) {
				var assetSubString,
					cataloguesHtml = '',
					successCallback = function (catalogueCount) {
						totalCount = catalogueCount;
						if (typeof (countCallback) !== 'undefined' && typeof (countCallback) === 'function') {
							countCallback(catalogueCount);
						}
					},
					failureCallback = function () {
						VODView.showNotificationMessage('<p>No schedules for catalogue </p>');
					};

				if (isFiltered === false) {
					assetSubString = null;
				} else {
					assetSubString = $('#assetSubString').val();
				}
				VODModel.getCatalogueScheduleCount(successCallback, failureCallback, VODView.getSelectedCatalogue(), assetSubString || null);
			}

			function setDeviceType() {
				VODModel.setDeviceType(VODView.getDeviceTypeArray());
			}

	/*
	 * GET PRODUCTS
	 */
			function showProductDetails(id, callback) {
				var i,
					j,
					k,
					Product,
					promotionId,
					promotionPrice,
					promotionPriceLookup = {};

				VODView.hidePurchase();

				selectedProduct = null;
				for (i = 0; i < selectedAsset.technicals.length; i++) {
					for (j = 0; j < selectedAsset.technicals[i].products.length; j++) {
						Product = selectedAsset.technicals[i].products[j];
						if (USE_PROMOTIONS) {
							promotionPriceLookup = VODModel.getPromotionPricesForProduct(Product);
							if (Product.promotions) {
								Product.promotionPrice = [];
								for (k = 0; k < Product.promotions.length; k++) {
									promotionId = Product.promotions[k];
									promotionPrice = promotionPriceLookup[promotionId];
									Product.promotionPrice[k] = { id: promotionId,
															price: promotionPrice };
								}
							}
						}
						if (Product.id === id) {
							selectedProduct = Product;
							callback(selectedProduct);
							break;
						}
					}
				}
				if (selectedProduct) {
					VODView.showProductDetails(selectedProduct);
				}
			}

			function showProducts() {
				VODView.showProducts(selectedAsset);
				$('#products p').click(function (event) {
					var detailCallback = function (Product) {
						selectedProduct = Product;
						VODView.showProductDetails(Product);
						if (hasSignedOn) {
							VODView.showIsPurchased();
						}
					};
					showProductDetails(event.target.id, detailCallback);
				});
			}

	/*
	 * GET ASSETS
	 */

			function addClickEvent() {
				$('#notification p').click(function () {
					var detailCallback = function (asset) {
						selectedAsset = asset;
						VODView.showAsset(asset);
						showProducts();
						VODView.hidePlay();
						VODView.hidePurchase();
					};
					VODModel.getDetailedAssetByUid(this.id, detailCallback);
				});
			}

			function getAssetsCallback(assets) {
				VODView.populateAssets(assets, assets.length);
				addClickEvent();
			}

			function getPagedAssetsCallback(assets) {
				VODView.populateAssets(assets, totalPagedAssetsCount);
				addClickEvent();
			}

			function getAssetsByPromotionCallback(result) {
				VODView.populateAssets(result.editorials, result.editorials.length);
				addClickEvent();
			}

			function getPagedAssets() {
				var selectedCatalogue,
					startIndex,
					endIndex,
					countCallback = function (count) {
						var failureCallback = function () {
								//alert('failureCallback');
							},
							detailSuccessCallback = function () {
								//alert('detailSuccessCallback');
							};
						pagingLimit = VODView.getPagingList();
						if (pagedResultSetIndex + 1 > count) {
							pagedResultSetIndex = 0;
							VODView.showNotificationMessage('No more assets. Press button to retrieve from beginning');
						} else {
							startIndex = pagedResultSetIndex;
							endIndex = startIndex + pagingLimit;
							pagedResultSetIndex = endIndex;
							totalPagedAssetsCount = count;
							VODModel.getPagedDetailedAssets(getPagedAssetsCallback, detailSuccessCallback, failureCallback, VODView.getSelectedCatalogue(), startIndex, endIndex, VODView.getSortArray());
						}
					};
				getScheduleCount(countCallback, false);
			}

			function getAssets() {
				VODView.showNotificationMessage();
				VODModel.getDetailedAssets(getAssetsCallback, VODView.getSelectedCatalogue(), VODView.getSortArray());
			}

			function getAssetsByPromotionId() {
				var failureCallback = function () {
					alert("****************************** getAssetsByPromotionId failure");
				};
				VODView.showNotificationMessage();
				VODModel.getAssetsByPromotionId(VODView.getPromotionId(), getAssetsByPromotionCallback, failureCallback, VODView.getSortArray());
			}

			function getPagedAssetsByPromotionId() {
				var startIndex,
					endIndex,
					successCallback = function (result) {
						totalPagedAssetsCount = result.total_records;
						getPagedAssetsCallback(result.editorials);
					},
					failureCallback = function () {
						alert("****************************** getAssetsByPromotionId failure");
					};

				if (pagedResultSetIndex + 1 <= totalPagedAssetsCount || totalPagedAssetsCount === 0) {
					pagingLimit = VODView.getPagingList();
					startIndex = pagedResultSetIndex;
					endIndex = startIndex + pagingLimit;
					pagedResultSetIndex = endIndex;
					VODModel.getPagedAssetsByPromotionId(VODView.getPromotionId(), successCallback, failureCallback,  VODView.getSortArray(), startIndex, endIndex);
				} else {
					VODView.showNotificationMessage('No more assets. Press button to retrieve from beginning');
					pagedResultSetIndex = 0;
					totalPagedAssetsCount = 0;
				}
			}

	/*
	 * PURCHASE
	 */
			function purchase() {
				var successCallback = function () {
						alert("purchase successful");
						VODView.hidePurchase();
						VODView.showPlay();
					},
					failCallback = function (err) {
						alert("purchase failed " + err);
					};
				VODModel.subscribeToPolicyGroup(selectedProduct, this, successCallback, failCallback);
			}

			function purchaseWithPromotion() {
				var successCallback = function () {
						alert("purchase with promotion successful");
						VODView.hidePurchase();
						VODView.showPlay();
					},
					failCallback = function (err) {
						alert("purchase with promotion failed " + err);
					};
				VODModel.subscribeToPolicyGroupWithPromotion(selectedProduct, this, successCallback, failCallback, VODView.getPromotionId());
			}

	/*
	 * CHECK IS PURCHASED
	 */

			function isPurchasedOrSubscribed() {
				var editorialAssetId,
					technicalAssetId,
					productId,
					isAssetPurchased,
					isAssetSubscribed,
					isAssetAvailable,
					assetExpiryDate,
					outputStr,
					acquiredContentRefreshed = function () {
						if (selectedAsset) {
							isAssetPurchased = VODModel.isAssetPurchased(selectedAsset);
							isAssetSubscribed = VODModel.isAssetSubscribed(selectedAsset);
							assetExpiryDate = VODModel.getAssetExpiryDate(selectedAsset);
							isAssetAvailable = assetExpiryDate >= (new Date().getTime());
							if (isAssetAvailable) {
								if (isAssetPurchased || isAssetSubscribed) {
									VODView.showPlay();
									VODView.showPurchase();
									VODView.hidePurchase();
								} else {
									VODView.hidePlay();
									if (selectedProduct) {
										VODView.showPurchase();
										if (selectedProduct.promotions && selectedProduct.promotions.length > 0) {
											VODView.showPurchaseWithPromotion();
										}
									}
								}
							} else {
								VODView.hidePlay();
								if (selectedProduct) {
									VODView.showPurchase();
									if (selectedProduct.promotions && selectedProduct.promotions.length > 0) {
										VODView.showPurchaseWithPromotion();
									}
								}
							}
							outputStr = 'Asset purchased? ' + isAssetPurchased + '\n\nAvailable to play? ' + isAssetAvailable + '\n\nSubscribed? ' + isAssetSubscribed;
							alert(outputStr);
						}
					};
				VODModel.removeAcquiredContentRefreshListener();
				VODModel.registerAcquiredContentRefreshListener(acquiredContentRefreshed);
				VODModel.refreshAcquiredContent();
			}

	/*
	 * PLAY ASSET
	 */
			function playAsset() {
				VODModel.playContent(selectedAsset.technicals[0]);
			}

			function getContentType() {
				alert("Content type: " + VODModel.getContentType());
			}

			function init() {

				initialise();
				$('#signOn').click(signOn);
				$('#getRootCatalogue').click(populateRootCatalogue);
				$('#getChildCatalogues').click(populateChildCatalogues);
				$('#catalogueList').change(function () {
					VODView.initialiseChildCatalogues();
				});
				$('#getAssets').click(getAssets);
				$('#getPagedAssets').click(getPagedAssets);
				$('#setDeviceType').click(setDeviceType);
				$('#getCatalogueScheduleCount').click(getScheduleCount);

				$('#getAssetsByPromotionId').click(getAssetsByPromotionId);
				$('#getPagedAssetsByPromotionId').click(getPagedAssetsByPromotionId);
				$('#getContentType').click(getContentType);

				if (TEST_END_TO_END) {
					$('#getPurchasedAssets').click(getPurchasedAssets);
					$('#purchase').click(purchase);
					$('#purchaseWithPromotion').click(purchaseWithPromotion);
					$('#isPurchased').click(isPurchasedOrSubscribed);
					$('#getPurchasedAssets').click(getPurchasedAssets);
					$('#playButton').click(playAsset);
				}
			}

			return {
				init: init
			};
		}());
		return $N.app.vodController;
	}
);
/*global require*/
window.$N = {};
require.config({
	baseUrl: '',
    paths : {
        'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform': '../../src/platform/html5'
	}
});
require(['jsfw/services/sdp/VOD'],
	function (VOD) {
		require(['vodController'], function (Controller) {
			Controller.init();
		});
	}
);