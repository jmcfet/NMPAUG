/*global require*/
window.$N = {};
require.config({
  baseUrl: '',
  paths: {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
  }
});

require(
	[
		'jsfw/services/sdp/BaseService',
		'jsfw/services/sdp/Signon',
		'jsfw/platform/output/PlayoutManager',
		'jsfw/services/sdp/VOD',
		'jsfw/apps/core/Version',
		'jsfw/services/sdp/MetadataService'
	],
	function (BaseService, Signon, PlayoutManager, VOD, Version, MetaDataService) {

		var IN_THE_CLEAR = false, //Change to true to not use DRM
			url = "ott.nagra.com/stable",
			mdsPath = "/metadata/delivery",
			serviceProviderId = "B1",
			vodPromoUrl = "http://ott.nagra.com/stable/imagepath/",
			featureName = ["PC","TABLET"],
			macAddress = "00-05-9E-00-00-18",
			catalogueUid = IN_THE_CLEAR ? "B1_OPENSOURCE" : "B1_HOTPICKS",
			userId = "nmp@nagra.com",
			password = "nmp",
			locale = 'en_gb',
			assetLookup = {},
			videoPlayer;

		if (!IN_THE_CLEAR) {
			$N.Config.DRM = true;
		}

		function reloadtabs() {
			function resetTabs() {
				$("#content > div").hide();
				$("#tabs a").attr("id", "");
			}

			var myUrl = window.location.href;
			var myUrlTab = myUrl.substring(myUrl.indexOf("#"));
			var myUrlTabName = myUrlTab.substring(0, 4);

			$("#content > div").hide();
			$("#tabs li:first a").attr("id", "current");
			$("#content > div:first").fadeIn();

			$("#tabs a").on("click", function (e) {
				e.preventDefault();
				if ($(this).attr("id") === "current") {
					return;
				}
				else{
					resetTabs();
					$(this).attr("id","current");
					$($(this).attr('name')).fadeIn();
					}
				});

			for (i = 1; i <= $("#tabs li").length; i++) {
				if (myUrlTab == myUrlTabName + i) {
				resetTabs();
				$("a[name='"+myUrlTab+"']").attr("id","current");
				$(myUrlTab).fadeIn();
				}
			}
		}

		function assetSuccessCallback(assets) {
			var i,
				j=0;

			for (i = 0; i < assets.length; i++) {

				if (i%5 === 0) {
					j++;
					// Create Tabs
					var createtabs = document.createElement('li');
					createtabs.innerHTML = '<a href="#" name="#tab' + j + '">' + j + '</a></li>';
					document.getElementById("tabs").appendChild(createtabs);
					// Create Tabs Content Container
					var createtabsContainer = document.createElement('div');
					createtabsContainer.setAttribute('id', 'tab' + j);
					document.getElementById("content").appendChild(createtabsContainer);
					reloadtabs();
				}
				var assetUID = assets[i].id;
				assetLookup[assetUID] = assets[i];
				var assetImage = vodPromoUrl + assets[i].PromoImages[0];
				var createAsset = document.createElement('div');
				var category = assets[i].Categories ? assets[i].Categories[0] : "";
				createAsset.setAttribute('id', assetUID);
				createAsset.setAttribute('class', 'vodasset');
				createAsset.innerHTML = '<img src="' + assetImage + '"height="103" width="184"><h1>' + assets[i].Title + '</h1><p>' + category + '</p>';
				document.getElementById("tab" + j).appendChild(createAsset);
			}

		}
		function getScheduledItems() {
			VOD.getAssets(catalogueUid, assetSuccessCallback);
			showGallery();
		}
		function showGallery() {
			$("#video").css("margin-left", "-10000px");
			$("#gallery").show();
			videoPlayer.stop();

			// Get Version
			document.getElementById('version').innerHTML = '<p>SDP Ver : ' + Version.sdp + '</p><p>Ninja Ver : ' + Version.ninja + '</p><p>NMP Ver : ' + Version.nmp + '</p>';
		}

		function showVideo() {
			$("#video").css("margin-left", "auto");
			$("#gallery").hide();
		}

		function assetSelected(uid) {
			showVideo();
			var name = assetLookup[uid].Title;
			var directors = assetLookup[uid].Producers ? assetLookup[uid].Producers.join(", ") : "";
			var actors = assetLookup[uid].Actors ? assetLookup[uid].Actors.join(", ") : "";
			var description = assetLookup[uid].Description;

			document.getElementById('description').innerHTML = '<button id="back">Back</button><h2>' + name + '</h2><p><strong>Director : </strong>' + directors + '</p><strong>Actors : </strong>' + actors + '</p><h2>Description</h2><p>' + description + '</p>';
			videoPlayer.playContent(assetLookup[uid].technicals[0]);
		}

	 	(function init() {
			$(document).delegate('[class="vodasset"]', 'click', function () { assetSelected(this.id) });
			$(document).delegate('[id="Title"]', 'click', showGallery);
			$(document).delegate('[id="back"]', 'click', showGallery);

			function videoLoaded() {
				videoPlayer.addEventListener("error", function() {
					console.log('video error');
				});
				videoPlayer.addEventListener("playing", function() {
					console.log('video playing');
				});
				if (IN_THE_CLEAR) {
					Signon.signonByMACAddress(macAddress);
				} else {
					Signon.signonAndInitialiseForNMP(userId, password);
				}
			}
			function upgradeCallback (data) {
				console.log(data)
			}
			videoPlayer = new PlayoutManager({parent: document.getElementById("player"), videoLoadedCallback: videoLoaded, forceHTML: false, attributes: {width: 640, height: 500, controls: false, autoPlay: true } });

			videoPlayer.setVideoPath("http://ott.nagra.com/stable/videopath/");

			BaseService.initialise(url);
			MetaDataService.init(url, '', mdsPath, serviceProviderId, locale);
			Signon.init();
			Signon.registerListener(function () {
				VOD.initialise(null, null, null, null, locale, featureName);
				getScheduledItems();
			}, self);
		}());
	}
);