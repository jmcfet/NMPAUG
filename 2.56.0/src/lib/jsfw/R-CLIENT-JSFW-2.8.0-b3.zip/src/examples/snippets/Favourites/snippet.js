/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require([
	'jsfw/services/sdp/Favourites',
	'jsfw/services/sdp/Preferences',
	'jsfw/services/sdp/BaseService',
	'jsfw/services/sdp/Signon'],
	function (Favourites, Preferences, BaseService, Signon) {
		var assets = [{
			id: "VOD Content Item 1",
			type: "VOD"
		}, {
			id: "VOD Content Item 2",
			type: "VOD"
		}, {
			id: "BTV  Content Item 1",
			type: "BTV"
		}, {
			id: "BTV  Content Item 2",
			type: "BTV"
		}], lookup = {};

		function showServerMessage(html) {
			$("#status").html(html);
		}

		// Update an elements text value
		function updateAssetList(element, asset) {
			element.innerHTML =  'ID: ' + asset.id  + '. is favourite?<strong>: [' + asset.isFavourite + ']</strong></li>';
		}

		// Either remove or add a favourite on the server depending on the asset isFavourite value
		function updateServerValue(asset) {
			showServerMessage("Updating Server....");
			if (asset.isFavourite) {
				Favourites.addToFavourites(asset.id, asset.type, function () {
					showServerMessage("Successfull added favourite: <strong>[" + asset.id + "]</strong> to server");
				});
			} else {
				Favourites.removeFromFavourites(asset.id, asset.type, function () {
					showServerMessage("Successfull deleted favourite: <strong>[" + asset.id + "]</strong> from server");
				});
			}
		}
		// Prints each asset to the screen including favourite value
		function printAssets() {
			var i,
				asset,
				list = $("#favourites");

			$("#serverStatus").empty();
			for (i = 0; i < assets.length; i++) {
				asset = lookup[assets[i].id];
				if (asset) {
					list.append('<li id = "' + asset.id + '"> ID: ' + asset.id + '. is favourite?<strong>: [' + asset.isFavourite + ']</strong></li>');
				}
			}
		}

		// Adds a click handler to each list item. Inverts the favourite value when click.
		function addHandlers() {
			$('#favourites').children().each(function (index) {
				$(this).click(function () {
					var asset = lookup[this.id];
					asset.isFavourite = !asset.isFavourite;
					updateAssetList(this, asset);
					updateServerValue(asset);
				});
			});
		}

		function createLookup(serverFavourites) {
			var i,
				j,
				asset,
				serverAsset,
				lookupAsset;

			// Create lookup based on a local list of assets.
			for (i = 0; i < assets.length; i++) {
				asset = assets[i];
				asset.isFavourite = false;
				lookup[asset.id] = asset;
			}

			// Append the lookup objects with favourite values from server. 
			for (j = 0; j < serverFavourites.length; j++) {
				serverAsset = serverFavourites[j];
				lookupAsset = lookup[serverAsset.cId];
				if (lookupAsset) {
					lookupAsset.isFavourite = true;
				}
			}
			printAssets();
			addHandlers();
		}

		function getFavourites() {
			Favourites.getFavourites(function (favs) {
				createLookup(favs);
				showServerMessage("Server favourites data loaded");
			});
		}

		function signonSuccessCallback() {
			Preferences.initialise(2, 6);
			Favourites.init();
			getFavourites();
		}

		//Perform initialisation
		showServerMessage("Loading Favourites....");
		BaseService.initialise("ott.nagra.com/stable", null, null, null, "/qsp/gateway/http/js", false);
		Signon.init();
		Signon.registerListener(signonSuccessCallback);
		Signon.signonByUser("nmp@nagra.com", "nmp");
	});