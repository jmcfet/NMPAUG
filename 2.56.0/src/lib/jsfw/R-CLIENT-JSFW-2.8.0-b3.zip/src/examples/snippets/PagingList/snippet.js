var pageXML = '<?xml version="1.0" encoding="UTF-8" ?> \
<view xmlns="http://www.example.org/nagra"> \
	<label id="title" x="100" y="100" cssStyle="font-size:25" text="Example Paging List" /> \
    <customisablePagingList id="list" x="200" y="200" width="200" itemHeight="40" itemTemplate="TextItem" /> \
</view>';

var view = {};

var keyHandler = function (key){
    view.list.keyHandler(key);
};

$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);
$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
    keyHandler(key);
});

var data = [{"title": "title one"}, {"title": "title two"}, {"title": "title three"}, {"title": "title four"}, {"title": "title five"}, {"title": "title six"}, {"title": "title seven"}, {"title": "title eight"}, {"title": "title nine"}, {"title": "title ten"}];

var dataMapper = {
	getText: function (item) {
		return item.title;
	}
};

view.list.setVisibleItemCount(5);
view.list.setDataMapper(dataMapper);
view.list.initialise();
view.list.setData(data);
view.list.displayData();