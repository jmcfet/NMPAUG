/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/platform/output/PlayoutManager'], 
	function(PlayoutManager) {

		var playoutManager;
		
		// Set the video source to start playback once the video player has loaded
		function videoLoadedCallback() {
			playoutManager.src = "http://ott.nagra.com/stable/videopath/big-buck-bunny-sample_B1_100ASSETS_CONT_3_20131024_144716/index.m3u8";
		}
		
		function showSeekRate() {
			var seekRate = playoutManager.trickplay.getTrickPlayRate();
			$("#seekRateVal").html(seekRate);
			$("#seekRate").show();
		}
		
		function hideSeekRate() {
			$("#seekRate").hide();
		}
		
		// Initialise a playout manager instance
		playoutManager = new PlayoutManager({
			parent : document.getElementById("player"),
			videoLoadedCallback : videoLoadedCallback,
			forceHTML : false,
			attributes : {
				width : 535,
				height : 300,
				controls : false,
				autoPlay : false
			}
		});
		
		// Register event listeners
		$("#stop").click(function () {
			playoutManager.stop();
			hideSeekRate();
		});
		
		$("#play").click(function () {
			playoutManager.play();
			hideSeekRate();
		});
		
		$("#pause").click(function () {
			playoutManager.pause();
			hideSeekRate();
		});
		
		$("#fastforward").click(function () {
			playoutManager.fastForward();
			showSeekRate();
		});
		
		$("#rewind").click(function () {
			playoutManager.rewind();
			showSeekRate();
		});
});		
