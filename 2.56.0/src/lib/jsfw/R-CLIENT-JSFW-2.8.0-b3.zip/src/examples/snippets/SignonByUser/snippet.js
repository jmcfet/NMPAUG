/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	[
	 'jsfw/services/sdp/BaseService',
	 'jsfw/services/sdp/Signon'
	], 
	function(BaseService, Signon) {
		var username,
			password;
		
		function signonSuccessCallback() {
			$("#signonStatus").html("Sign on success");
		}
		
		function signonFailedCallback() {
			$("#signonStatus").html("Sign on failed");
		}
		
		// Perform initialisation and register sign on listeners
		$N.services.sdp.BaseService.initialise("ott.nagra.com/stable", null, null, null, "/qsp/gateway/http/js");
		$N.services.sdp.Signon.init();
		$N.services.sdp.Signon.registerListener(signonSuccessCallback, this);
		$N.services.sdp.Signon.setSignonFailedCallback(signonFailedCallback);
		
		// Perform sign on
		$("#signon").click(function () {
			username = $("#user").val();
			password = $("#password").val();
			$N.services.sdp.Signon.signonByUser(username, password);
		});
	});	