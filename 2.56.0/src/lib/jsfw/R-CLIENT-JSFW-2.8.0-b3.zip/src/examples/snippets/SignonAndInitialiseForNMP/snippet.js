/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	[
	 'jsfw/services/sdp/BaseService',
	 'jsfw/services/sdp/Signon',
	 'jsfw/platform/output/PlayoutManager'
	],
	function(BaseService, Signon, PlayoutManager) {
		var playoutManager;

		function signonFailedCallback(error) {
			if (error.failure) {
		        switch (error.failure) {
		        case $N.services.sdp.Signon.ERROR.SIGNON_BY_USER:
		            $("#signonStatus").html("Sign on by failed - unable to sign on with username and password");
		            break;
		        case $N.services.sdp.Signon.ERROR.INITIALIZE_DEVICE:
		            $("#signonStatus").html("Sign on failed - unable to initialize device");
		            break;
		        case $N.services.sdp.Signon.ERROR.PERSONALIZE_DEVICE:
		            $("#signonStatus").html("Sign on failed - unable to personalize device");
		            break;
		        case $N.services.sdp.Signon.ERROR.SIGNON_BY_USER_DEVICE_ID:
		            $("#signonStatus").html("Sign on failed - unable to sign on with device ID");
		            break;
		        case $N.services.sdp.Signon.ERROR.SIGNON_BY_DEVICE_ID:
		            $("#signonStatus").html("Sign on failed - unable to sign on with device ID");
		            break;
		        case $N.services.sdp.Signon.ERROR.INVALID_DEVICE_ID:
		            $("#signonStatus").html("Sign on failed - invalid device ID");
		            break;
		        case $N.services.sdp.Signon.ERROR.MAX_DEVICES_REACHED:
		            $("#signonStatus").html("Sign on failed - maximum devices reached");
		            break;
		        case $N.services.sdp.Signon.ERROR.SERVER_CONNECTION:
		            $("#signonStatus").html("Sign on failed - unable to connect to server");
		            break;
		        default:
		        	$("#signonStatus").html("Sign on failed - unable to connect to server");
		        }
		    }
		}

		function signonSuccessCallback() {
			$("#signonStatus").html("Sign on success");
		}

		// Perform initialisation and sign on once video has loaded
		function videoLoadedCallback() {
			$N.services.sdp.BaseService.initialise("ott.nagra.com/stable", null, null, null, "/qsp/gateway/http/js");
			$N.services.sdp.Signon.init();
			$N.services.sdp.Signon.registerListener(signonSuccessCallback, this);
			$N.services.sdp.Signon.setSignonFailedCallback(signonFailedCallback);
			$N.services.sdp.Signon.signonAndInitialiseForNMP("nmp@nagra.com", "nmp");
		}

		// Initialise a playout manager instance
		playoutManager = new $N.platform.output.PlayoutManager({
			parent : document.getElementById("player"),
			videoLoadedCallback : videoLoadedCallback,
			forceHTML : false,
			attributes : {
				width : 0,
				height : 0,
				controls : false,
				autoPlay : false
			}
		});
});