/*global require, $*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require([
	'jsfw/platform/output/PlayoutManager',
	'jsfw/platform/media/DLNA'],
	function (PlayoutManager, DLNA) {
		var playoutManager,
			currentDevice;

		function showServerMessage(html) {
			$("#status").html(html);
		}

		function getDeviceListCallback(devices) {
			showServerMessage("Network Device Discovery Complete");
			var i,
				listItem,
				device,
				option;

			$("#discoverDevices").show();
			$("#selectDevice").empty();
			$("#selectDevice").append('<option id = "default" selected="selected">Select a DLNA device</option>');
			for (i = 0; i < devices.length; i++) {
				device = devices[i];
				option = document.createElement("option");
				option.setAttribute('id', device.UDN);
				option.innerHTML = device.modelDescription;
				$("#selectDevice").append(option);
			}
			$("#selectDevice").show();
		}

		function browseCallback(data) {
			showServerMessage("Browsing Device Complete");
			var i,
				listItem,
				itemContent,
				displayPrevious,
				displayPreviousText,
				contentItem,
				count,
				itemHref,
				deviceIDN = data.UDN;

			if (data.parent) {
				displayPrevious = document.createElement('li');
				displayPrevious.setAttribute('id', data.parent);
				itemHref = document.createElement('a');
				itemHref.setAttribute('href', '#');
				itemHref.innerHTML = "../Back";
				displayPrevious.appendChild(itemHref);
				$("#displayfolderlist").append(displayPrevious);
			}

			for (i = 0; i < data.container.length; i++) {
				listItem = document.createElement('li');
				listItem.setAttribute('id', data.container[i].id);
				itemHref = document.createElement('a');
				itemHref.setAttribute('href', '#');
				itemHref.innerHTML = data.container[i].title;
				count = data.container[i].childCount || 0;
				itemHref.innerHTML += "[" + count + "]";
				listItem.appendChild(itemHref);
				$("#displayfolderlist").append(listItem);
			}

			for (i = 0; i < data.item.length; i++) {
				contentItem = document.createElement('li');
				contentItem.setAttribute('id', data.item[i].id);
				contentItem.innerHTML = data.item[i].title;
				$("#displayItemList").append(contentItem);
			}
		}

		function browseDevice(UDN, containerId, startIndex) {
			showServerMessage("Browsing Device...... ");
			var config = {};
			config.containerId = containerId;
			config.sortCriteria = "";
			config.filter = '*';
			config.startIndex = startIndex || '0';
			config.itemCount = '200';
			DLNA.browseDevice(UDN, config, 'BrowseDirectChildren', browseCallback);
		}

		function discoverDevices() {
			showServerMessage("Discovering DLNA Compatible Devices on the Network...... ");
			$("#selectDevice").hide();
			$("#browseContainer").hide();
			var devices = DLNA.getDeviceList(getDeviceListCallback, DLNA.SERVICETYPE.BROWSE);
		}

		function initHandlers() {
			$("#discoverDevices").click(discoverDevices);

			$('#selectDevice').change(function () {
				currentDevice = $(this).children(":selected").attr("id");
				$("#displayfolderlist").empty();
				$("#displayItemList").empty();
				$("#browseDeviceId").empty();
				if (currentDevice !== "default") {
					$("#browseDeviceId").html("Browsing device: [" + $(this).val() + "]");
					$("#browseContainer").show();
					browseDevice(currentDevice, '0');
				}
			});

			$('#displayfolderlist').on('click', 'li', function () {
				var id = $(this).attr('id');
				$("#displayfolderlist").empty();
				$("#displayItemList").empty();
				browseDevice(currentDevice, id);
			});
		}

		(function init() {
			initHandlers();
			playoutManager = new PlayoutManager({
				parent : document.getElementById("player"),
				videoLoadedCallback : discoverDevices,
				forceHTML : false,
				attributes : {
					width : 0,
					height : 0,
					controls : false,
					autoPlay : false
				}
			});
		}());
	});