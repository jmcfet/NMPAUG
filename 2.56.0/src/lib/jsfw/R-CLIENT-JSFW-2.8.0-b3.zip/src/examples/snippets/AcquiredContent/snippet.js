/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('aclView',
	[],
	function () {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.aclView = (function () {

			var $detailsDialog,
				process = {
					SIGN_ON_SUCCESSFUL:		'This page demonstrates the retrieval of acquired content from the Nagra MediaLive Service platform. ' + "</br>"
											+ 'Acquired content for a signed in accout id is retrieved from the server on initialisation of the Acquired Content class.  ' + "</br>"
											+ 'The retrieved data is cached within the framework.' + "</br>"
											+ 'It is the responsibility of the client application to ensure that the cached data is periodically refreshed. ' + "</br>"
											+ 'Server requests are viewable in a chrome browser under Tools / Javascript Console / Network / XHR'
				};


			function init() {
				$detailsDialog = $('#details').dialog({
					autoOpen: false,
					width: 800,
					height: 500,
					close: function (event, ui) {
						$(this).dialog('close');
					}
				});
			}

			function prettify(objects, title) {
				$('#details').html(prettyPrint(objects));
				$detailsDialog.dialog({title: title});
				$detailsDialog.dialog('open');
			}

			function showPurchasedAssets(assets) {
				$detailsDialog.dialog('close');
				prettify(assets, "List of acquired content");
			}

			function setHelpText(message) {
				$("#helpText").html('<p>' + message + '</p>').show();
			}

			/*
			 * Public API
			 */
			return {
				init: init,
				showPurchasedAssets: showPurchasedAssets,
				setHelpText: setHelpText,
				PROCESS: process
			};

		}());
		return $N.app.aclView;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('aclModel',
	[
		'jsfw/Config',
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/BaseService',
		'jsfw/services/sdp/Signon',
		'jsfw/services/sdp/MetadataService',
		'jsfw/services/sdp/AcquiredContent',
		'jsfw/services/sdp/ServiceFactory'
	],
	function (Config, Log, BaseService, Signon, MetadataService, AcquiredContent, ServiceFactory) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.aclModel = (function () {

			var accountUid,
				userUid,
				locale;

/*
 * INITIALISATION
 */
			function getContext(callback) {
				$N.services.sdp.ServiceFactory.get("ContextService").getCurrentContext(this, function (context) {
					userUid = context.userUid;
					accountUid = context.accountUid;
					locale = context.locale;
					$N.services.sdp.AcquiredContent.initialise(accountUid, locale);
					callback();
				}, function () {});
			}

			function init(MDS, SDP, signOnSuccessCallback) {
				var successCallback = function () {
					getContext(signOnSuccessCallback);
				};
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, MDS.LOCALE);
				$N.apps.core.Log.Config.configure({
					defaultValues: 1,
					classLogging: {
						EPG: 1,
						SDP: 1
					}
				});
				$N.services.sdp.Signon.init();
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.registerListener(successCallback, this);
				$N.services.sdp.Signon.signonByUser(SDP.USER, SDP.PASSWORD);
			}

/*
 * REFRESH ACQUIRED CONTENT
 */

			function registerAcquiredContentRefreshListener(listener) {
				$N.services.sdp.AcquiredContent.registerAclChangeCallBack(listener);
			}

			function removeAcquiredContentRefreshListener() {
				$N.services.sdp.AcquiredContent.removeAclChangeCallback();
			}

			function refreshAcquiredContent() {
				$N.services.sdp.AcquiredContent.refresh();
			}

/*
 * GET PURCHASED ASSETS (ACQUIRED CONTENT)
 */
			function getAssetsWithEditorialData() {
				return $N.services.sdp.AcquiredContent.getAssetsWithEditorialData();
			}

			return {
				init: init,
				getAssetsWithEditorialData: getAssetsWithEditorialData,
				refreshAcquiredContent: refreshAcquiredContent,
				registerAcquiredContentRefreshListener: registerAcquiredContentRefreshListener,
				removeAcquiredContentRefreshListener: removeAcquiredContentRefreshListener
			};
		}());
		return $N.app.aclModel;
	}
);
/*global require,Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('aclController',
	[
		'aclView',
		'aclModel'
	],
	function (aclView, aclModel) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.aclController = (function () {

			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp'
				};

			function signOnSuccessCallback() {
				console.log("****************************************************************************");
				console.log("********************************************* sign on success callback fired");
				console.log("****************************************************************************");
				aclView.setHelpText(aclView.PROCESS.SIGN_ON_SUCCESSFUL);
			}

			function getPurchasedAssets() {
				aclView.showPurchasedAssets(aclModel.getAssetsWithEditorialData());
			}

			function refreshPurchasedAssets() {
				aclModel.refreshAcquiredContent();
			}

			function registerListener() {
				var acquiredContentRefreshed = function () {
					alert("acquired content refresh successful");
					};
				aclModel.registerAcquiredContentRefreshListener(acquiredContentRefreshed);
			}

			function deRegisterListener() {
				aclModel.removeAcquiredContentRefreshListener();
			}

			function init() {
				aclModel.init(MDS, SDP, signOnSuccessCallback);
				aclView.init();

				$('#getPurchasedAssets').click(getPurchasedAssets);
				$('#refreshPurchasedAssets').click(refreshPurchasedAssets);
				$('#registerListener').click(registerListener);
				$('#deRegisterListener').click(deRegisterListener);
			}
			return {
				init: init
			};
		}());
		return $N.app.aclController;
	}
);

/*global require*/
window.$N = {};
require.config({
	baseUrl: '',
	paths: {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(['jsfw/services/sdp/AcquiredContent'],
	function (ACL) {
		if ($N.services.sdp.MetadataService) {
			require(['aclController'], function (Controller) {
				Controller.init();
			});
		}
	}
);