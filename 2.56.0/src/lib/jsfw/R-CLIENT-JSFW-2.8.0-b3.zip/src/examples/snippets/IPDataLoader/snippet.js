/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/platform/btv/EPG',
	 'jsfw/services/sdp/IPDataLoader',
	 'jsfw/services/sdp/BaseService',
	 'jsfw/services/sdp/MetadataService',
	 'jsfw/services/sdp/Signon',
	 'jsfw/services/sdp/EPG'
	],
	function(PlatformEPG, IPDataLoader, BaseService, MetadataService, Signon, SDPEPG) {

		function channelsLoaded() {
		  PlatformEPG.refresh();

		  // Update channel list
		  var channels = PlatformEPG.getAllChannels();
		  channels.forEach(function(c) {
		    $('#channel-list').append('<li>' + c.serviceId + '</li>');
		  });
		}

		function epgLoaded() {
		  PlatformEPG.refresh();
		  // Channels and EPG data have been loaded
		  // Remove loader and add onClick handlers to fetch specific event information
		  $('.spinner').remove();
		  $('#channel-list').children().each(function(index) {
		    // Output next event information for channel
		    $(this).click(function() {
		    var nextEvent = PlatformEPG.getNextEventForService($(this).text());
		      if(nextEvent !== null) {
		        $('#next-event').text("Next event is: " + nextEvent.title + " at " + new Date(nextEvent.startTime));
		      } else {
		        $('#next-event').text("No next event found for selected channel");
		      }
		    });
		  });;
		}

		// Once signed in, let IPDataLoader fetch all service/EPG data
		function loadIPData() {
		  IPDataLoader.init({
		    locale: "en_gb",
		    refreshInterval: 12,
		    maxDays: 7,
		    fetchDuration: 2,
		    forceRAMCache: true
		  });

		  IPDataLoader.setChannelsLoadedCallback(channelsLoaded);
		  IPDataLoader.registerListener(epgLoaded);
		  IPDataLoader.loadIPData();
		}

		// Initialise base services
		var url = 'ott.nagra.com/stable';
		BaseService.initialise(url, null, null, null, '/qsp/gateway/http/js/');
		MetadataService.initialise(url, '', '/metadata/delivery', 'B1', undefined, 'en_GB');
		PlatformEPG.initialise({
		  dataSources: [PlatformEPG.DATA_SOURCES.SDP],
		  cacheType: PlatformEPG.CACHE_TYPES.RAM,
		  cacheExpiryTime: 10000
		});
		SDPEPG.initialise();

		PlatformEPG.refresh();

		// Signon and then load the IP data
		Signon.init();
		Signon.registerListener(loadIPData);
		Signon.signonByUser("nmp@nagra.com", "nmp");
});
