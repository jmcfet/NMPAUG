/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('epgView',
	[],
	function () {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgView = (function () {

			var channels = $("#channels"),
				eventList = $("#events "),
				eventInfo = $("#eventObj"),
				savedEvents = {},
				channelLookup = {},
				prop;

			function showChannels() {
				$("#channelList").css("visibility", "visible");
				$("#selectChannelText").css("visibility", "visible");
				$("#fetchCurrentEventButton").prop('disabled', false);
				$("#fetchNextEventButton").prop('disabled', false);
				$("#fetchEventsByWindow").prop('disabled', false);
				$("#fetchCUEventsByWindow").prop('disabled', false);
				$("#fetchAllEventsByWindow").prop('disabled', false);
				$("#search").prop('disabled', false);
			}

			function clearEvents() {
				eventList.html();
				$("#events").empty();
				$("#eventObj").empty();
				$("#eventImage").hide();
			}

			function clearAll() {
				$("#fetchCurrentEventButton").prop('disabled', true);
				$("#fetchNextEventButton").prop('disabled', true);
				$("#fetchEventsByWindow").prop('disabled', true);
				$("#fetchCUEventsByWindow").prop('disabled', true);
				$("#fetchAllEventsByWindow").prop('disabled', true);
				$("#search").prop('disabled', false);
				$("#channelList").css("visibility", "hidden");
				$("#selectChannelText").css("visibility", "hidden");
				clearEvents();
			}

			function populateChannelList(allChannels) {
				var channels,
					optionName,
					channelText,
					targetLength,
					i,
					channelsHtml = "";
				var channelOptions = $("#channelList")[0];

				clearEvents();

				channels = allChannels;
				for (i = 0; i < channels.length; i++) {
					channelsHtml += "<p id='" + channels[i].serviceId + "'>" + channels[i].logicalChannelNum + ": " + channels[i].serviceName + "</p>\n";
					channelLookup[channels[i].serviceId] =  channels[i];
				}
				if ($("#order_asc").attr("checked")) {
					for (i = 0; i < channels.length; i++) {
						//add channels to drop down list
						channelText = channels[i].serviceName + " (" + channels[i].serviceId + ")";
						optionName = new Option(channelText, channels[i].serviceId);
						targetLength = channelOptions.length;
						channelOptions.options[targetLength] = optionName;
					}
				} else if ($("#order_desc").attr("checked")) {
					for (i = channels.length - 1; i > -1; i--) {
						//add channels to drop down list
						channelText = channels[i].serviceName + " (" + channels[i].serviceId + ")";
						optionName = new Option(channelText, channels[i].serviceId);
						targetLength = channelOptions.length;
						channelOptions.options[targetLength] = optionName;
					}
				}
			}

			function populateEventList(returnedEvents) {
				var i,
					eventsHtml = "<p>Number of events: " + returnedEvents.length + "</p>",
					date;

				eventList.html();
				savedEvents = {};

				for (i = 0; i < returnedEvents.length; i++) {
					savedEvents[returnedEvents[i].eventId] = returnedEvents[i];
					date = new Date(returnedEvents[i].startTime);
					eventsHtml += "<p id='" + returnedEvents[i].eventId + "'>" + returnedEvents[i].serviceId + " "  + returnedEvents[i].title  + " - " + returnedEvents[i].eventId + " @ " + date.getDate() + "/" + (date.getMonth() + 1) + " " + date.getHours() + ":" + date.getMinutes() + "</p>\n";
				}
				eventList.html(eventsHtml);

				$("#events p").click(function () {
					var returnedEvent = savedEvents[this.id],
						eventInfoHTML = "";
					if (returnedEvent) {
						for (prop in returnedEvent) {
							eventInfoHTML += prop + ": " + ((prop === 'startTime' || prop === 'endTime') ? new Date(returnedEvent[prop]) : returnedEvent[prop]) + "<br/>";
						}
						eventInfo.html(eventInfoHTML);
						var imageResult = returnedEvent.promoImage;
						if (typeof imageResult === 'function') {
							imageResult(function (url) {
								console.log("Image was fetched......");
								$("#eventImage").show();
								$("#eventImage").attr("src", url);
							});
						} else {
							console.log("Image was cached......");
							try {
								$("#eventImage").show();
								$("#eventImage").attr("src", imageResult);
							} catch (ex) {
							}
						}
						var yearResult = returnedEvent.year;
						if (typeof yearResult === 'function') {
							yearResult(function (year) {
								console.log("Year: " + year);
							});
						} else {
							console.log("Year: " + yearResult);
						}
					}
				});
			}

			function getChannelArray() {
				var i,
					channelOptions = $("#channelList")[0],
					channelArray = [];

				for (i = 0; i < channelOptions.options.length; i++) {
					if (channelOptions.options[i].selected === true) {
						channelArray.push(channelOptions.options[i].value);
					}
				}
				return channelArray;
			}

			function getSelectedChannelId() {
				return $("#channelList")[0].options[$("#channelList")[0].selectedIndex].value;
			}

			function getSelectedChannel() {
				return channelLookup[getSelectedChannelId()];
			}

			function setEventListText(text) {
				eventList.html("<p>" + text + "</p>");
			}

			function getStartTime() {
				var	tempDate = new Date(),
					fromHourOptions = $("#fromHourList")[0],
					fromMinuteOptions = $("#fromMinuteList")[0],
					fromDate = $("#fromdatepicker").datepicker('getDate'),
					fromHr = fromHourOptions.options[fromHourOptions.selectedIndex].value,
					fromMin = fromMinuteOptions.options[fromMinuteOptions.selectedIndex].value,
					startTime;

				if (fromDate) {
					tempDate.setDate(fromDate.getDate());
					tempDate.setMonth(fromDate.getMonth());
					tempDate.setFullYear(fromDate.getFullYear());
				}
				tempDate.setHours(fromHr);
				tempDate.setMinutes(fromMin);
				tempDate.setSeconds(0, 0);
				return tempDate.getTime();
			}

			function getEndTime() {
				var	tempDate = new Date(),
					toHourOptions = $("#toHourList")[0],
					toMinuteOptions = $("#toMinuteList")[0],
					toHr = toHourOptions.options[toHourOptions.selectedIndex].value,
					toMin = toMinuteOptions.options[toMinuteOptions.selectedIndex].value,
					toDate = $("#todatepicker").datepicker('getDate'),
					endTime;

				if (toDate) {
					tempDate.setDate(toDate.getDate());
					tempDate.setMonth(toDate.getMonth());
					tempDate.setFullYear(toDate.getFullYear());
				}
				tempDate.setHours(toHr);
				tempDate.setMinutes(toMin);
				tempDate.setSeconds(0, 0);
				return tempDate.getTime();
			}

			function populateTimePicker() {
			    var i,
					optionName,
					targetLength,
					fromHourOptions = $("#fromHourList")[0],
					fromMinuteOptions = $("#fromMinuteList")[0],
					toHourOptions = $("#toHourList")[0],
					toMinuteOptions = $("#toMinuteList")[0];

			    for (i = 0; i < 24; i++) {
					//add hours to drop down list
					optionName = new Option(i, i);
					targetLength = fromHourOptions.length;
					fromHourOptions.options[targetLength] = optionName;
					optionName = new Option(i, i);
					toHourOptions.options[targetLength] = optionName;
				}

				for (i = 0; i < 60; i++) {
					//add minutes to drop down list
					optionName = new Option(i, i);
					targetLength = fromMinuteOptions.length;
					fromMinuteOptions.options[targetLength] = optionName;
					optionName = new Option(i, i);
					toMinuteOptions.options[targetLength] = optionName;
				}
			}

			function showPlay() {
				$('#playButton').show();
			}

			function hidePlay() {
				$('#playButton').hide();
			}

			function getSearchText() {
				return $("#searchQuery").val();
			}

			/*
			 * Public API
			 */
			return {
				showChannels: showChannels,
				clearAll: clearAll,
				clearEvents: clearEvents,
				populateChannelList: populateChannelList,
				populateEventList: populateEventList,
				getChannelArray:  getChannelArray,
				populateTimePicker: populateTimePicker,
				getSelectedChannel: getSelectedChannel,
				getSelectedChannelId: getSelectedChannelId,
				setEventListText: setEventListText,
				getStartTime: getStartTime,
				getEndTime: getEndTime,
				showPlay: showPlay,
				hidePlay: hidePlay,
				getSearchText: getSearchText
			};
		}());
		return $N.app.epgView;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('epgModel',
	[
		'jsfw/Config',
		'jsfw/apps/core/Log',
		'jsfw/platform/btv/EPGCache',
		'jsfw/platform/btv/PersistentCache',
		'jsfw/platform/btv/EPG',
		'jsfw/services/sdp/IPDataLoader',
		'jsfw/services/sdp/EPG',
		'jsfw/services/sdp/Signon',
		'jsfw/platform/output/PlayoutManager',
		'jsfw/services/sdp/ServiceFactory',
		'jsfw/services/sdp/BTVSearch'
	],
	function (Config, Log, EPGCache, PersistentCache, BTVEPG, IPDataLoader, SDPEPG, SignOn, PlayoutManager, ServiceFactory, BTVSearch) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgModel = (function () {

			var MDS = {},
				SDP = {},
				userId,
				password,
				locale,
				player,
				videoPath,
				btvRefreshCallback,
				playerCallback,
				ipDataLoader = {
					forceRamCache: true,
					cacheEvents: true,
					refreshInterval: 12,
					maxDays: 2,
					fetchDuration: 6
				};

			function initialise() {

				$N.apps.core.Log.Config.configure({
					defaultValues: 1,
					classLogging: {
						EPG: 1,
						SDP: 1
					}
				});

				$N.platform.btv.EPG.initialise({
					cacheEvents: true,
					dataSources: [$N.platform.btv.EPG.DATA_SOURCES.SDP], //[$N.platform.btv.EPG.DATA_SOURCES.SDP] add in for dynamic EPG
					cacheType: ipDataLoader.forceRamCache ? $N.platform.btv.EPG.CACHE_TYPES.RAM : $N.platform.btv.EPG.CACHE_TYPES.Persistent,
					cacheExpiryTime: 60 * 60 * 10000
					//checkForExpiredEventsTime: 3000
				});

				$N.platform.btv.PersistentCache.init();
				$N.services.sdp.EPG.initialise();

				$N.platform.btv.EPG.registerRefreshCallback(function () {
					btvRefreshCallback();
				}, this);
				playerCallback(player);
			}

/*
 * SIGN ON AND INITIALISE BY NMP
 */
			function initialiseAndSignon() {
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.init();
				initialise();
				$N.services.sdp.Signon.signonByMACAddress(SDP.MAC_ADDRESS);
			}

			function setPlayoutManager(callback, signOn) {
				if (player) {
					if (signOn) {
						initialiseAndSignon();
					}
					callback();
				} else {
					playerCallback = callback;
					player = new $N.platform.output.PlayoutManager({parent: document.getElementById("epgPlayout"), videoLoadedCallback: signOn ? initialiseAndSignon : initialise, forceHTML: false, attributes: {width: 320, height: 180, controls: true, autoPlay: true } });
					if (videoPath) {
						player.setVideoPath(videoPath);
					}
				}
			}

			function init(mds, sdp, VIDEO_PATH, signOnFailureCallback, refreshCallback) {
				MDS = mds;
				SDP = sdp;
				videoPath = VIDEO_PATH;
				btvRefreshCallback = refreshCallback;
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, null, MDS.LOCALE);
				$N.services.sdp.Signon.setSignonFailedCallback(signOnFailureCallback);
			}

			function loadIpData(iPDataLoader_Listener_Fired) {
				console.log("load ip data init");
				$N.services.sdp.IPDataLoader.init({
					locale: SDP.LOCALE,
					refreshInterval: ipDataLoader.refreshInterval,
					maxDays: ipDataLoader.maxDays,
					cacheEvents: ipDataLoader.cacheEvents,
					fetchDuration: ipDataLoader.fetchDuration,
					forceRAMCache: ipDataLoader.forceRamCache
				});
				$N.services.sdp.IPDataLoader.registerListener(iPDataLoader_Listener_Fired, this);
				$N.services.sdp.IPDataLoader.loadIPData();
			}

			function fetchCurrentEventForService(channel, successCallback) {
				$N.platform.btv.EPG.fetchCurrentEventForService(channel, successCallback);
			}

			function fetchNextEventForService(channel, successCallback) {
				$N.platform.btv.EPG.fetchNextEventForService(channel, successCallback);
			}

			function fetchEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback) {
				$N.platform.btv.EPG.fetchEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback);
			}

			function fetchCatchUpEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback) {
				$N.services.sdp.EPG.fetchCatchUpEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback);
			}

			function fetchWatchableEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback) {
				$N.services.sdp.EPG.fetchWatchableEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback);
			}

			function clearCache() {
				$N.platform.btv.EPGCache.clearCache();
				$N.platform.btv.PersistentCache.clearCache();
			}

			function refresh(listener) {
				$N.services.sdp.IPDataLoader.unregisterListener(listener);
				$N.platform.btv.EPG.refresh();
			}

			function getAllChannels() {
				return $N.platform.btv.EPG.getAllChannelsOrderedByChannelNumber();
			}

			function searchByTitle(title, successCallback, failureCallback) {
				$N.services.sdp.BTVSearch.getNonExpiredEventsByTitle(title, successCallback, failureCallback);
			}

			function playContent(content) {
				player.playContent(content);
			}

			return {
				init: init,
				initialise: initialise,
				setPlayoutManager: setPlayoutManager,
				loadIpData: loadIpData,
				fetchCurrentEventForService: fetchCurrentEventForService,
				fetchNextEventForService: fetchNextEventForService,
				fetchEventsByWindow: fetchEventsByWindow,
				fetchCatchUpEventsByWindow: fetchCatchUpEventsByWindow,
				fetchWatchableEventsByWindow: fetchWatchableEventsByWindow,
				getAllChannels: getAllChannels,
				refresh: refresh,
				clearCache: clearCache,
				searchByTitle: searchByTitle,
				playContent: playContent
			};
		}());
		return $N.app.epgModel;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('epgController',
	[
		'epgView',
		'epgModel'
	],
	function (EPGView, EPGModel) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgController = (function () {

			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					MAC_ADDRESS: '28-BE-9B-DE-AD-14'
				},
				DEFAULT_DEVICE = "PC",
				VIDEO_PATH = "http://ott.nagra.com/stable/videopath/",
				hasSignedOn = false;

		/*
		 * BTV EPG CALLBACKS
		 */
			function btv_EPG_Refresh_Fired() {
				console.log("****************************************************************************");
				console.log("********************************************* btv epg refresh fired");
				console.log("****************************************************************************");
				EPGView.populateChannelList(EPGModel.getAllChannels());
				EPGView.showPlay();
			}

			function iPDataLoader_Listener_Fired() {
				console.log("****************************************************************************");
				console.log("********************************************* ip data loader listener fired");
				console.log("****************************************************************************");
				EPGView.showChannels();
				EPGModel.refresh(iPDataLoader_Listener_Fired);
			}

		/*
		 * SIGN ON
		 */
			function playerCallback(player) {
				hasSignedOn = true;
			}

			function signOn() {
				EPGModel.setPlayoutManager(playerCallback, true);
			}

			function signOnFailureCallback(error) {
				alert("SIGN ON FAILED!!! " + error.response.status || error.response);
				hasSignedOn = false;
			}

			function initialise() {
				EPGModel.init(MDS, SDP, VIDEO_PATH, signOnFailureCallback, btv_EPG_Refresh_Fired);
			}

			function getEventsByWindowParameters() {
				var parameters = {};
				parameters.serviceArray = EPGView.getChannelArray();
				if (parameters.serviceArray.length === 0) {
					return null;
				}
				parameters.startTime = EPGView.getStartTime();
				parameters.endTime = EPGView.getEndTime();
				return parameters;
			}

			function search() {
				EPGModel.searchByTitle(EPGView.getSearchText(), function (response) {
					if (response) {
						EPGView.clearEvents();
						EPGView.populateEventList(response.events);
					} else {
						alert("no events returned");
					}
				}, function () {});
			}

			function playStream() {
				EPGModel.playContent(EPGView.getSelectedChannel());
			}

			function init() {

				var eventsByWindowParms = {},
					eventsByWindowSuccessCallback = function (nextEvents) {
						if (nextEvents && nextEvents.length > 0) {
							EPGView.populateEventList(nextEvents);
						} else {
							EPGView.setEventListText("No events returned for time window for channel(s)");
						}
					},
					eventsByWindowFailureCallback = function () {
						EPGView.setEventListText("Error in retrieving data");
					};

				initialise();

				$('#signOn').click(signOn);

				EPGView.populateTimePicker();

				$("#search").css("visibility", "visible");
				$("#searchQuery").css("visibility", "visible");

				$("#loadChannelsButton").click(function () {
					console.log("click load ip data");
					EPGView.clearAll();
					EPGView.hidePlay();
					$("#channelList")[0].options.length = 0;
					if (!hasSignedOn) {
						var callback = function () {
							EPGModel.loadIpData(iPDataLoader_Listener_Fired);
						};
						EPGModel.setPlayoutManager(callback, false);
					} else {
						EPGModel.loadIpData(iPDataLoader_Listener_Fired);
					}
				});

				$('#playButton').click(playStream);

				$("#clearCacheButton").click(function () {
					EPGModel.clearCache();
				});

				$("#fetchCurrentEventButton").click(function () {

					var successCallback = function (currentEvent) {
							var eventArray = [];
							if (currentEvent) {
								eventArray.push(currentEvent);
								EPGView.populateEventList(eventArray);
							} else {
								EPGView.setEventListText("No current event returned for channel");
							}
						},
						failureCallback = function () {
							EPGView.setEventListText("Error in retrieving data");
						};
					//EPGView.hidePlay();
					EPGView.clearEvents();
					if (EPGView.getChannelArray().length === 1) {
						EPGModel.fetchCurrentEventForService(EPGView.getSelectedChannelId(), successCallback);
					} else {
						if (EPGView.getChannelArray().length === 0) {
							alert("Please select a channel");
						} else {
							alert("Please select only one channel");
						}
					}
				});

				$("#fetchNextEventButton").click(function () {
					var successCallback = function (nextEvent) {
							var eventArray = [];
							eventArray.push(nextEvent);
							if (nextEvent) {
								EPGView.populateEventList(eventArray);
							} else {
								EPGView.setEventListText("No next event returned for channel");
							}
						},
						failureCallback = function () {
							EPGView.setEventListText("Error in retrieving data");
						};

					EPGView.clearEvents();
					if (EPGView.getChannelArray().length === 1) {
						EPGModel.fetchNextEventForService(EPGView.getSelectedChannelId(), successCallback);
					} else {
						if (EPGView.getChannelArray().length === 0) {
							alert("Please select a channel");
						} else {
							alert("Please select only one channel");
						}
					}
				});

				$("#fetchEventsByWindow").click(function () {
					eventsByWindowParms = getEventsByWindowParameters();
					if (eventsByWindowParms) {
						EPGModel.fetchEventsByWindow(eventsByWindowParms.serviceArray,
														eventsByWindowParms.startTime,
														eventsByWindowParms.endTime,
														eventsByWindowSuccessCallback,
														eventsByWindowFailureCallback);
					} else {
						alert("Please select one or more channels");
					}
				});
				$("#fetchCUEventsByWindow").click(function () {
					eventsByWindowParms = getEventsByWindowParameters();
					if (eventsByWindowParms) {
						EPGModel.fetchCatchUpEventsByWindow(eventsByWindowParms.serviceArray,
														eventsByWindowParms.startTime,
														eventsByWindowParms.endTime,
														eventsByWindowSuccessCallback,
														eventsByWindowFailureCallback);
					} else {
						alert("Please select one or more channels");
					}
				});
				$("#fetchAllEventsByWindow").click(function () {
					eventsByWindowParms = getEventsByWindowParameters();
					if (eventsByWindowParms) {
						EPGModel.fetchWatchableEventsByWindow(eventsByWindowParms.serviceArray,
														eventsByWindowParms.startTime,
														eventsByWindowParms.endTime,
														eventsByWindowSuccessCallback,
														eventsByWindowFailureCallback);
					} else {
						alert("Please select one or more channels");
					}
				});
				$("#search").click(function () {
					search();
				});

				$(function () {
			    	$("#fromdatepicker").datepicker({ dateFormat: 'dd-mm-yy' }).val();
			  	});
			  	$(function () {
			    	$("#todatepicker").datepicker({ dateFormat: 'dd-mm-yy' }).val();
				});

			}

			return {
				init: init
			};
		}());
		return $N.app.epgController;
	}
);
/*global require*/
window.$N = {};
require.config({
    baseUrl : '',
    paths : {
        'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform': '../../src/platform/html5'
    }
});
require(
	['jsfw/services/sdp/EPG'],
	function (EPG) {
		require(['epgController'], function (Controller) {
			Controller.init();
		});
	}
);