var pageXML = '<?xml version="1.0" encoding="UTF-8" ?> \
<view xmlns="http://www.example.org/nagra"> \
	<label id="title" x="100" y="100" cssStyle="font-size:25" text="Example Button Bar" /> \
	<buttonBar id="myButtonBar" x="200" y="200" width="420" height="280" /> \
</view>';

var view = {};

var keyHandler = function (key) {
    var keys = $N.apps.core.KeyInterceptor.getKeyMap();
    var handled = view.myButtonBar.keyHandler(key);
    if (!handled) {
        switch (key) {
            case keys.KEY_ONE:
                view.myButtonBar.enable();
                break;
            case keys.KEY_TWO:
                view.myButtonBar.disable();
                break;
        }
    }
    return handled;
};

$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);
$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
    keyHandler(key);
});

// create some button configurations
var buttonA = {
    width: 100,
    height: 100,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    labelCssClass: "buttonLabel",
    disabledCssClass: "buttonDisabled",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 10,
    label: "Hello",
    labelTop: 85,
    image: "resources/images/user_48.png",
    imageLeft: 26,
    imageTop: 16
};

var buttonB = {
    width: 310,
    height: 100,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    labelCssClass: "buttonLabel",
    disabledCssClass: "buttonDisabled",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 10,
    label: "Goodbye"
};

var buttonC = {
    width: 30,
    height: 30,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    labelCssClass: "buttonLabel",
    disabledCssClass: "buttonDisabled",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 5,
    image: "resources/images/help_16.png",
    imageTop: 7,
    imageLeft: 7
};

var buttonD = {
    width: 65,
    height: 30,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    labelCssClass: "buttonLabel",
    disabledCssClass: "buttonDisabled",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 5
};

var buttonE = {
    width: 30,
    height: 65,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    disabledCssClass: "buttonDisabled",
    labelCssClass: "buttonLabel",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 5
};

var buttonF = {
    width: 100,
    height: 30,
    cssClass: "button",
    highlightCssClass: "buttonHighlight",
    labelCssClass: "buttonLabel",
    disabledCssClass: "buttonDisabled",
    labelHighlightCssClass: "buttonLabelHighlight",
    labelDisabledCssClass: "buttonLabelDisabled",
    rounding: 5,
    label: "Help",
    labelLeft: 32,
    image: "resources/images/help_16.png",
    imageLeft: 8,
    imageTop: 8
};

// configure button bar
view.myButtonBar.setPadding(5);
view.myButtonBar.setCssClass("buttonBar");
view.myButtonBar.setDisabledButtonStandardCssClass("disabledButtonStandard");
view.myButtonBar.setDisabledButtonHighlightCssClass("disabledButtonHighlight");
view.myButtonBar.setDisabledButtonDisabledCssClass("disabledButtonDisabled");
view.myButtonBar.setAlignmentEmphasis($N.gui.ButtonBar.VERTICAL_ALIGNMENT);

view.myButtonBar.setSelectedCallback(function (result) {
    switch (result) {
        case "b22":
            view.myButtonBar.enableButton("b14");
            view.myButtonBar.enableButton("b17");
            view.myButtonBar.enableButton("b21");
            view.myButtonBar.disableButton("b22");
            view.myButtonBar.enableButton("b23");
            break;
        case "b23":
            view.myButtonBar.disableButton("b14");
            view.myButtonBar.disableButton("b17");
            view.myButtonBar.disableButton("b21");
            view.myButtonBar.enableButton("b22");
            view.myButtonBar.disableButton("b23");
            break;
    }
});

view.myButtonBar.setHighlightedCallback(function (result) {
    console.log("myButtonBar highlighted", result);
});

view.myButtonBar.createButton("b1", buttonA);
view.myButtonBar.createButton("b2", buttonD);
view.myButtonBar.createButton("b3", buttonC);
view.myButtonBar.createButton("b4", buttonC);
view.myButtonBar.createSpacer(30, 30);
view.myButtonBar.createButton("b6", buttonC);
view.myButtonBar.createButton("b7", buttonC);
view.myButtonBar.createButton("b8", buttonE);
view.myButtonBar.createButton("b9", buttonC);
view.myButtonBar.createSpacer(30, 65);
view.myButtonBar.createButton("b11", buttonE);
view.myButtonBar.createButton("b12", buttonC);
view.myButtonBar.createButton("b13", buttonB);
view.myButtonBar.createButton("b14", buttonA, "User A", false);
view.myButtonBar.createButton("b15", buttonF);
view.myButtonBar.createButton("b16", buttonF);
view.myButtonBar.createButton("b17", buttonA, "User B", false);
view.myButtonBar.createButton("b18", buttonE, "1");
view.myButtonBar.createButton("b19", buttonE, "2");
view.myButtonBar.createButton("b20", buttonE, "3");
view.myButtonBar.createButton("b21", buttonA, "User C", false);
view.myButtonBar.createButton("b22", buttonF, "Enable");
view.myButtonBar.createButton("b23", buttonF, "Disable", false);
view.myButtonBar.enable();