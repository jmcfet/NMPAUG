window.$N = {};
require.config({
  baseUrl: '',
  paths: {
    'jsfw' : '../../src',
    'jsfw/services/sdp' : '../../src/services/sdp34mds',
    'jsfw/platform': '../../src/platform/html5'
  }
});

define('Config',
	[],
	function () {
		window.$N = $N || {};
		$N.minui = $N.app || {};

		$N.minui.Config = {
			SDP_URL: "ott.nagra.com/stable",
			QSP_PATH: "/qsp/gateway/http/js",
			MDS_URL: "ott.nagra.com/stable",
			MDS_PATH: "/metadata/delivery",
			SERVICE_PROVIDER_ID: "B1",
			FUTURE_EVENT_TIME_WINDOW: 12,
			PAST_EVENT_TIME_WINDOW: 12,
			VOD_VIDEO_PATH: "http://ott.nagra.com/stable/videopath/",
			FEATURE_NAME: null
		}
		return $N.minui.Config;
	}
);

/*global  $, $N, require, console */
require(
	[
		'jsfw/services/sdp/BaseService',
	    'jsfw/services/sdp/Signon',
	    'jsfw/services/sdp/ServiceFactory',
	    'jsfw/services/sdp/AcquiredContent',
	    'jsfw/services/sdp/VOD',
	    'jsfw/platform/output/PlayoutManager',
	    'jsfw/services/sdp/MetadataService',
	    'jsfw/platform/btv/EPG',
	    'jsfw/services/sdp/EPG',
	    'jsfw/services/sdp/IPDataLoader',
	    'Config',
	    'jsfw/platform/btv/EPGCache'
	],
	function (
		BaseService,
	    Signon,
	    ServiceFactory,
	    AcquiredContent,
	    VOD,
	    PlayoutManager,
	    MetaDataService,
	    PlatformEPG,
	    SDPEPG,
	    IPDataLoader,
	    Config,
	    EPGCache
	) {
		$N = window.$N || {};
		$N.minui = $N.minui || {};
		var MinUI = (function () {

			var signonMethods = {
					signonForNMP: signonForNMP,
					signonByMAC: signonByMAC,
					signonByCASN: signonByCASN,
					signonBySC: signonBySC
				},
				userUid,
				accountUid,
				locale,
				catalogueLookup = {},
				eventLookup = {},
				player,
				purchaseSuccessCallback = function () {},
				purchaseFailureCallback = function () {},
				PLAYER_STATES = {
					STOPPED: "STOPPED",
					PLAYING: "PLAYING",
					LOADING: "LOADING",
					PAUSED: "PAUSED"
				},
				CONTENT_TYPES = {
					1: "BTV",
					2: "VOD"
				},
				playerState = PLAYER_STATES.STOPPED,
				currentMetadata = null,
				signonError = null,
				currentBTVServiceProviderId = Config.SERVICE_PROVIDER_ID,
				mdsServiceProviderId = Config.SERVICE_PROVIDER_ID,
				signonFailureCallback = function () {};

			function signonForNMP() {
				//Signon.signonAndInitialiseForNMP("nmp@nagra.com", "nmp");
				Signon.signonAndInitialiseForNMP($("#user").val(), $("#password").val());
			}

			function signonByMAC() {
				Signon.signonByMACAddress($("#mac").val());
			}

			function signonByCASN() {
				Signon.signonByCASN($("#casn").val());
			}

			function signonBySC() {
				Signon.signonBySmartcardID($("#smartcard").val());
			}

			function signonFail(response) {
				var error = response && response.response ? response.response : response;
				signonError = error;
				signonFailureCallback(error);
			}

			function cacheChannels(callback) {
				IPDataLoader.init({
					locale: locale,
					forceRAMCache: true,
					cacheEvents: false
				});
				IPDataLoader.setChannelsLoadedCallback(function () {
					PlatformEPG.refresh(function () {
						callback();
					});
				});
				currentBTVServiceProviderId = mdsServiceProviderId;
				IPDataLoader.loadIPData();
			}

			function btvInit() {
				PlatformEPG.init({
					dataSources: [PlatformEPG.DATA_SOURCES.SDP],
					cacheType: PlatformEPG.CACHE_TYPES.RAM,
					cacheEvents: false
				});
				SDPEPG.init(accountUid, locale);
				cacheChannels(function () {
					$("#browse").show();
				});
			}

			function vodInit() {
				VOD.initialise(accountUid, userUid, null, true, locale, Config.FEATURE_NAME);
				AcquiredContent.initialise(accountUid, locale);
			}

			function getMDSLocale(locale) {
				var underScorePosition,
					convertedLocale = '';
				if (locale) {
					underScorePosition = locale.indexOf('_');
					convertedLocale = locale.substr(0, underScorePosition + 1) + locale.substr(underScorePosition + 1).toUpperCase();
				}
				return convertedLocale;
			}

			function doBootstrap() {
				ServiceFactory.get("ContextService").getCurrentContext(this, function (context) {
					userUid = context.userUid;
					accountUid = context.accountUid;
					locale = context.locale;
					MetaDataService.initialise(Config.MDS_URL, '', Config.MDS_PATH, Config.SERVICE_PROVIDER_ID, undefined, getMDSLocale(locale));
					btvInit();
					vodInit();
					$("#signon").hide();
				}, function () {});
			}

			function signonChange() {
				var i = 0,
					optionsLength = $("input[name='signon']").length;
				for (i = 0; i < optionsLength; i++) {
					$("#param" + i).addClass("hide");
				}
				$("#param" + $("input[name='signon']:checked").val()).removeClass("hide");
			}

			function doSignon() {
				signonMethods[$("#signon" + ($("input[name='signon']:checked").val())).val()]();
			}

			function initialiseSignOn() {
				Signon.init();
				Signon.registerListener(doBootstrap, this);
				Signon.setSignonFailedCallback(signonFail);
			}

			function videoLoaded() {
				initialiseSignOn();
				$("#content").show();
			}

			function getChildCatalogues(catId) {
				var i = 0,
					unorderedList;
				VOD.getDetailedCatalogues(
					function (catalogues) {
						for (i = 0; i < catalogues.length; i++) {
							$("#ul" + catId).append('<li id="' + catalogues[i].id + '">' + catalogues[i].Title + '<ul id="ul' + catalogues[i].id + '"></ul></li>');
							catalogueLookup[catalogues[i].id] = catalogues[i];
						}
					},
					null,
					function (result) { console.log("FAIL"); },
					catId
				);
			}

			function getAssets(catId) {
				var i = 0;
				$("#assets").append("<ul id='ulassets'></ul>");
				VOD.getAssets(catId, function (assets) {
					for (i = 0; i < assets.length; i++) {
						$("#ulassets").append('<li id="' + assets[i].id + '">' + assets[i].Title + '</li>');
					}
				});
			}

			function getRootCataloguesSuccess(catalogues) {
				var i,
					cataloguesHtml = "<ul>";
				for (i = 0; i < catalogues.length; i++) {
					cataloguesHtml += "<li id='" + catalogues[i].id + "'>" + catalogues[i].Title + "<ul id='ul" + catalogues[i].id + "'></ul></li>";
					catalogueLookup[catalogues[i].id] = catalogues[i];
				}
				cataloguesHtml += "</ul>";
				$("#catalogues").html(cataloguesHtml);
				$("#assets").html("");
				$("#vod_metadata").html("");
			}

			function showChannels() {
				$("#btv").show();
				channels = PlatformEPG.getAllChannelsOrderedByChannelNumber();
				channelsHTML = "<ul>";
				for (i = 0; i < channels.length; i++) {
					channelsHTML += "<li id='" + channels[i].serviceId + "'>" + channels[i].serviceName + "</li>";
				}
				$("#channels").html(channelsHTML + "</li>");
			}

			function browseChange() {
				var channels,
					i,
					channelsHTML;
				currentMetadata = null;
				$("#vod").hide();
				$("#btv").hide();
				$("#channels").html("");
				$("#events").html("");
				$("#btv_metadata").html("");
				switch ($("input[name='browse']:checked").val()) {
				case "vod":
					VOD.getRootCatalogues(getRootCataloguesSuccess, null, function () {});
					$("#vod").show();
					break;
				case "btv":
					if (currentBTVServiceProviderId === mdsServiceProviderId) {
						showChannels();
					} else {
						EPGCache.clearCache();
						cacheChannels(showChannels);
					}
					break;
				}
			}

			function displayCatalogueMetaData(catalogue) {
				currentMetadata = catalogue;
				$("#vod_metadata").html("<pre id='catalogue_metadata'>" + JSON.stringify(catalogue, null, 2) + "</pre>");
				$("#vod_metadata").append("<b>Catalogue Name:</b> " + catalogue.Title);
			}

			function onCatalogueClick(event) {
				currentMetadata = null;
				eventLookup = {};
				$("#ul" + this.id).html("");
				displayCatalogueMetaData(catalogueLookup[this.id]);
				getChildCatalogues(this.id);
				$("#assets").html("");
				getAssets(this.id);
				event.stopPropagation();
			}

			function updateAssetMetaData(asset) {
				var	h,
					i,
					product,
					technical,
					htmlString = "";
				currentMetadata = asset;
				$("#vod_metadata").html("");

				for (h = 0; h < asset.technicals.length; h++) {
					technical = asset.technicals[h];
					$("#vod_metadata").append("<div class='technical' id='" + technical.id + "'><b>Technical ID:</b> " + technical.id + "<br/>");
					if (AcquiredContent.isAssetPurchasedOrSubscribed(asset.technicals[h].id)) {
						$("#" + technical.id).append("<b>Purchased/Subscribed:</b> true<br/>");
					} else {
						$("#" + technical.id).append("<b>Purchased/Subscribed:</b> false<br/>");
					}
					for (i = 0; i < asset.technicals[h].products.length; i++) {
						product = asset.technicals[h].products[i];
						$("#" + technical.id).append("<div class='product'><b>Product ID:</b> " + product.id + "<p class='productPrice'><b>Price:</b> " + product.price.currency + " "
										+ product.price.value + "<button id='" + product.id + "' class='productBuy'>BUY</button></p></div>");
						$("#" + product.id).click(function (evt) {
							purchaseAsset(asset, this.id);
						});
					}
					$("#" + technical.id).append("<button id='" +  asset.technicals[h].id + "' class='technicalPlay'>PLAY</button><br/></div>");
				}
				$("#vod_metadata").append("<pre id='asset_metadata'>" + JSON.stringify(asset, null, 2) + "</pre>");
			}

			function purchaseAsset(asset, productId) {
				VOD.subscribeToPolicyGroup(productId, this, function () {
					AcquiredContent.registerAclChangeCallBack(function () {
						updateAssetMetaData(asset);
					});
					purchaseSuccessCallback();
					AcquiredContent.refresh();
				}, function (error) {
					purchaseFailureCallback(error);
				});
			}

			function onAssetClick(event) {
				currentMetadata = null;
				$("#vod_metadata").html("");
				VOD.getDetailedAssetByUid(this.id, function (asset) {
					updateAssetMetaData(asset);
				}, function () {
					console.log("FAILED TO GET ASSET FOR UID: " + this.id);
				});
			}

			function getEvents(serviceId) {
				var now = new Date().getTime(),
					i,
					eventsHTML;
				SDPEPG.fetchEventsByWindow([serviceId], now - (Config.PAST_EVENT_TIME_WINDOW * 3600000), now + (Config.FUTURE_EVENT_TIME_WINDOW * 3600000), function (events) {
					if (events.length === 0) {
						$("#events").html("No events available");
					} else {
						eventsHTML = "<ul>";
						for (i = 0; i < events.length; i++) {
							eventsHTML += '<li id="' + events[i].eventId + '">' + events[i].title + '</li>';
							eventLookup[events[i].eventId] = events[i];
						}
						$("#events").html(eventsHTML + "<ul>");
					}
				}, function () {
					$("#events").html("Failed to retrieve events");
				});
			}

			function onEventClick() {
				var event = eventLookup[this.id];
				currentMetadata = event._data;
				$("#btv_metadata").html("<button id='play_" + this.id + "'>PLAY EVENT</button><br/>");
				$("#play_" + this.id).click(function (evt) {
					player.playContent(event);
				});
				$("#btv_metadata").append("<pre id='event_metadata'>" + JSON.stringify(event._data, null, 2) + "</pre>");
			}

			function onChannelClick() {
				var channel = PlatformEPG.getChannelByServiceId(this.id);
				currentMetadata = channel._data;
				$("#btv_metadata").html("<button id='play_" + this.id + "'>PLAY CHANNEL</button><br/>");
				$("#play_" + this.id).click(function (evt) {
					player.playContent(channel);
				});
				$("#btv_metadata").append("<pre id='channel_metadata'>" + JSON.stringify(channel._data, null, 2) + "</pre>");
				$("#events").html("");
				getEvents(this.id);
			}

			function onPlayAssetClick() {
				var i = 0,
					technicalId = this.id;
				VOD.getDetailedAssetByTechnicalId(technicalId, function (asset) {
					for (i = 0; i < asset.technicals.length; i++) {
						if (asset.technicals[i].id = technicalId) {
							player.playContent(asset.technicals[i]);
							break;
						}
					}
				}, function () {console.log("FAILED TO RETRIEVE ASSET")});
			}

			function onPlayerError() {
				playerState = PLAYER_STATES.STOPPED;
			}

			function onPlayerEnded() {
				playerState = PLAYER_STATES.STOPPED;
			}

			function onPlayerPlay() {
				playerState = PLAYER_STATES.PLAYING;
			}

			function onPlayerPause() {
				playerState = PLAYER_STATES.PAUSED;
			}

			$N.minui = {
				Config: Config,
				getPlayerState: function () {
					if (!player.paused) {
						return PLAYER_STATES.PLAYING;
					} else {
						return playerState;
					}
				},
				getPlayer: function () {
					return player;
				},
				getPlayingContentObject: function () {
					if (player._playingContentMapper) {
						return player._playingContentMapper.getContent();
					}
					return null;
				},
				getPlayingContentType: function () {
					var type = player.getContentType();
					if (type) {
						return CONTENT_TYPES[player.getContentType()];
					}
					return null;
				},
				setSignonSuccessCallback: function (callback) {
					Signon.registerListener(callback, this);
				},
				setSignonFailedCallback: function (callback) {
					signonFailureCallback = callback
				},
				setPurchaseSuccessCallback: function (callback) {
					purchaseSuccessCallback = callback;
				},
				setPurchaseFailedCallback: function (callback) {
					purchaseFailureCallback = callback;
				},
				getClickedMetadata: function () {
					return currentMetadata;
				},
				getLastSignonError: function () {
					return signonError;
				},
				setServiceProviderId: function (serviceProviderId) {
					mdsServiceProviderId = serviceProviderId;
					MetaDataService.setServiceProviderId(serviceProviderId);
				}
			};

			return {
				init: function () {
					BaseService.initialise(Config.SDP_URL, null, null, null, Config.QSP_PATH);
					player = new PlayoutManager({parent: document.getElementById("vid"), videoLoadedCallback: videoLoaded, forceHTML: false, attributes: {width: 320, height: 240, controls: false, autoPlay: true } });
					player.setVideoPath(Config.VOD_VIDEO_PATH);
					$("input[name='signon']").change(signonChange);
					$("#signon_button").click(doSignon);
					$("input[name='browse']").click(browseChange);
					$("#catalogues").on("click", "li", onCatalogueClick);
					$("#assets").on("click", "li", onAssetClick);
					$("#channels").on("click", "li", onChannelClick);
					$("#events").on("click", "li", onEventClick);
					$("#vod_metadata").on("click", ".technicalPlay", onPlayAssetClick);
				}
			};
		}());
		$(document).ready(function () {
			MinUI.init();
		});
	}
);
