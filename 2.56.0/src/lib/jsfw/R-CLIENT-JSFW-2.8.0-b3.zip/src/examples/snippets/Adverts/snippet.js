window.$N = {};
require.config({
	baseUrl: '',
	paths: {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	[
		'jsfw/apps/core/Log',
		'jsfw/platform/output/PlayoutManager'
	],
	function (Log, PlayoutManager) {
			var	videoPlayer,
				log = new Log('app', 'adverts'),
				MP4_URL = "http://media.w3.org/2010/05/sintel/trailer.mp4",
				TEST_DATA = [
					{type: 0, uid: 1, originId: "", originKey: "", url: MP4_URL, durationInMillis: 51000, fileName: "testfilename", title: 'Content with 2 pre-roll ads'},
					{type: 0, uid: 2, originId: "", originKey: "", url: MP4_URL, durationInMillis: 51000, fileName: "testfilename", title: 'Content with 2 post-roll ads'},
					{type: 0, uid: 3, originId: "", originKey: "", url: MP4_URL, durationInMillis: 51000, fileName: "testfilename", title: 'Content with 2 mid-roll ads'},
					{type: 0, uid: 4, originId: "", originKey: "", url: MP4_URL, durationInMillis: 51000, fileName: "testfilename", title: 'Content with pre-, mid-, and post-roll ad'}
				],
				$testData;

			function populateData() {
				var testDataHTML = '<option>Select the content here</option>';
				$("#videoControl").hide();
				$.each(TEST_DATA, function (index, item) {
					testDataHTML += '<option value="' + item.uid + '">' + item.title + '</option>';
				});
				$testData.html(testDataHTML);
			}

			function getAsset(uid) {
				var asset = null;
				$.each(TEST_DATA, function (index, item) {
					log('getAsset', 'item uid: ' + item.uid);
					if (item.uid === parseInt(uid, 10)) {
						asset = item;
						log('getAsset', 'got asset, exiting now');
						return false;
					}
				});
				return asset;
			}
			function skipCallback() {
				log('skipCallback', "allow skip fw");
				$("#skip").show();
			}

			function advertStartedCallback(evt) {
				log('advertStartedCallback', "********************************************************************* advert Started");
				$("#skip").hide();
			}

			function advertEndedCallback(evt) {
				log('advertEndedCallback', "********************************************************************* advert ended");
			}

			function videoEndedCallback() {
				log('videoEndedCallback', "video Ended");
				$("#skip").hide();
			}

			function playListStartedCallback(evt) {
				log('playListStartedCallback', "playlist started");
				$("#skip").hide();
			}

			function playListEndedCallback(evt) {
				log('playListEndedCallback', "playlist Ended");
				$("#skip").hide();
			}

			function contentPlaybackStartedCallback(evt) {
				log('contentPlaybackStartedCallback', 'content playing now');
				$("#skip").hide();
			}

			function contentPlaybackStoppedCallback(evt) {
				log('contentPlaybackStoppedCallback', 'content playback ended now');
			}

			function videoLoaded() {
				videoPlayer.addEventListener("canSkipAdvert", skipCallback);
				videoPlayer.addEventListener("ended", videoEndedCallback);
				videoPlayer.addEventListener("playListStarted", playListStartedCallback);
				videoPlayer.addEventListener("playListEnded", playListEndedCallback);
				videoPlayer.addEventListener("advertStarted", advertStartedCallback);
				videoPlayer.addEventListener("advertEnded", advertEndedCallback);
				videoPlayer.addEventListener("contentPlaybackStarted", contentPlaybackStartedCallback);
				videoPlayer.addEventListener("contentPlaybackStopped", contentPlaybackStoppedCallback);
			}

			function skip() {
				videoPlayer.skip();
				$("#skip").hide();
			}

			$("#skip").click(skip);
			$testData = $("#data");
			populateData();

			videoPlayer = new PlayoutManager({parent: document.getElementById("videoContainer"), adverts: true, videoLoadedCallback: videoLoaded, forceHTML: true, attributes: {width: 640, height: 500, controls: true}});

			$testData.change(function () {
				var uid = $(this).val();
				$("#videoControl").show();
				videoPlayer.playContent(getAsset(uid));
			});

			//stub out ad service until one is available

			window.AdService = (function () {
				var sdp1Json = {
					"requestId": 245207082,
					"result": {
						"adverts": [{
							"adInteractivity": {
								"adInteractivityType": "INTERACTIVE"
							},
							"adSkipPolicy": {
								"adSkipPolicyType": "SKIP_AFTER_SEC",
								"value":"5"
							},
							"adServer": {
								"type": "INTERNAL",
								"uri": "./resources/stubs/adverts/VAST-iab-example1.xml"
							},
							"advert": {
								"advertRollType": "PRE_ROLL",
								"type": "",
								"value": ""
							}
						}]
					},
					"resultCode": "0",
					"token": null
				},
				sdp2Json = {
					"requestId": 245207082,
					"result": {
						"adverts": [{
							"adInteractivity": {
								"adInteractivityType": "INTERACTIVE"
							},
							"adSkipPolicy": {
								"adSkipPolicyType": "SKIP_AFTER_SEC",
								"value":"5"
							},
							"adServer": {
								"type": "INTERNAL",
								"uri": "./resources/stubs/adverts/VAST-iab-example2.xml"
							},
							"advert": {
								"advertRollType": "POST_ROLL",
								"type": "",
								"value": ""
							}
						}]
					},
					"resultCode": "0",
					"token": null
				},
				sdp3Json = {
					"requestId": 245207082,
					"result": {
						"adverts": [{
							"adInteractivity": {
								"adInteractivitytYPE": "INTERACTIVE"
							},
							"adSkipPolicy": {
								"adSkipPolicyType": "SKIP_AFTER_SEC",
								"value":"7"
							},
							"adServer": {
								"type": "INTERNAL",
								"uri": "./resources/stubs/adverts/VAST-iab-example2.xml"
							},
							"advert": {
								"advertRollType": "MID_ROLL",
								"type": "AFTER_SEC",
								"value": "20"
							}
						}]
					},
					"resultCode": "0",
					"token": null
				},
			sdp4Json = {
				"requestId": 245207082,
				"result": {
					"adverts": [{
						"adInteractivity": {
							"adInteractivityType": "INTERACTIVE"
						},
						"adSkipPolicy": {
							"adSkipPolicyType": "NO_SKIP",
							"value":""
						},
						"adServer": {
							"type": "INTERNAL",
							"uri": "./resources/stubs/adverts/VAST-iab-example2.xml"
						},
						"advert": {
							"advertRollType": "PRE_ROLL",
							"type": "",
							"value": ""
						}
					}, {
						"adInteractivity": {
							"adInteractivityType": "INTERACTIVE"
						},
						"adSkipPolicy": {
							"adSkipPolicyType": "SKIP_AFTER_SEC",
							"value":"10"
						},
						"adServer": {
							"type": "INTERNAL",
							"uri": "./resources/stubs/adverts/VAST-iab-example1.xml"
						},
						"advert": {
							"advertRollType": "MID_ROLL",
							"type": "AFTER_SEC",
							"value": "30"
						}
					}, {
						"adInteractivity": {
							"adInteractivityType": "INTERACTIVE"
						},
						"adSkipPolicy": {
							"adSkipPolicyType": "SKIP_AFTER_SEC",
							"value":"5"
						},
						"adServer": {
							"type": "INTERNAL",
							"uri": "./resources/stubs/adverts/VAST-iab-example2.xml"
						},
						"advert": {
							"advertRollType": "POST_ROLL",
							"type": "",
							"value": ""
						}
					}]
				},
				"resultCode": "0",
				"token": null
			};

			return {
				getPreAdvertisements: function (context, callback, failcallback, assetuid) {
					var urlMap = {1: sdp1Json, 2: sdp2Json, 3: sdp3Json, 4: sdp4Json};
					if (urlMap[assetuid]) {
						if (callback) {
							callback(urlMap[assetuid]);
						}
					} else {
						if (callback) {
							callback();
						}
					}
				}
			};
		}());


	}
);
