var viewXML =
    '<?xml version="1.0" encoding="UTF-8" ?> \
    <view xmlns="http://www.example.org/nagra"> \
        <label id="title" x="100" y="100" text="Example Progress Bar" cssStyle="font-size:25px" /> \
        <group id="bars" x="100" y="200"> \
             <progressBar id="progress1" width="200" height="10" outerCssClass="outer" innerCssClass="inner" y="0"  /> \
             <progressBar id="progress2" width="200" height="10" outerCssClass="outer" innerCssClass="inner" y="20"  /> \
                <progressBar id="progress3" width="10" height="200" outerCssClass="outer" innerCssClass="inner" y="40" orientation="vertical" /> \
                <progressBar id="progress4" width="10" height="200" outerCssClass="outer" innerCssClass="inner" x="20" y="40" orientation="vertical" /> \
	        </group> \
	</view>';

var view = {};
$N.gui.FrameworkCore.loadGUIFromXML(viewXML, document.getElementById("content"), view);

view.bars.progress1.initialise(0, 100);
view.bars.progress2.initialise(0, 100);
view.bars.progress3.initialise(0, 100);
view.bars.progress4.initialise(0, 100);
view.bars.progress1.setProgress(50);
view.bars.progress2.setProgress(50, 25);
view.bars.progress3.setProgress(75, 50);
view.bars.progress4.setProgress(100, 50);