function bodyLoaded() {
	var view = {};
	var pageXML = '<?xml version="1.0" encoding="UTF-8" ?> \
	<view xmlns="http://www.example.org/nagra"> \
		<group id="componentArea"> \
			<mosaicMenu id="mosaic" itemsWide="3" x="100" y="100" wrapAround="f" /> \
			<label id="shortDesc" x="100" y="450"/> \
		</group> \
	</view>';

	var imagePath = "./resources/images/",
		componentArea,
		shortDesc,
	    mosaicMenu = {},
		view = {};

	var createComponents = function () {
		addTile("yast", null, [], imagePath + "yast.PNG", "YAST - Tetris, but on your TV. What will your high score be?");
		addTile("invaders", null, [], imagePath + "invaders.png", "Invaders - Classic gaming with Space Invaders");
		addTile("picasa", null, [], imagePath + "picasa.JPG", "Picasa - Fast and easy photo sharing from Google. Share with friends and family, or explore public photos.");
		addTile("weather", null, [], imagePath + "weather.PNG", "Weather - National text forecasts for up to a day ahead, with maps of temperature, precipitation and wind.");
	    addTile("vodafone", null, [], imagePath + "vodafone.PNG", "Vodafone - Visit Vodafone for the latest mobile phones and discover more on mobile internet, mobile broadband, mobile email, music and much more.");
		addTile("exit", null, [], imagePath + "tv.PNG", "Exit application");
	};

	var addTile = function (title, context, contextArgs, url, description) {
	    var tileData = {'context': context, 'contextArgs': contextArgs, 'description': description};
		var tile = new $N.gui.AnimatedMosaicTile(document, tileData, "", null);
		//var tile = new $N.gui.MosaicTile(document, tileData, "", null); //use for non animated menu
		tile.setTitle(title);
		tile.setUrl(url);
		tile.setScaleFactor(1.2);
		mosaicMenu.addNewMenuItem(tile);
	};

	var keyHandler = function(key){
	    return mosaicMenu.keyHandler(key);
	};

	$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);
	$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), keyHandler, null, null);

	mosaicMenu = view.componentArea.mosaic;
	createComponents(); //creates test data
	mosaicMenu.getSelectedItem().highLight();
	mosaicMenu.itemSelectedCallback();
	mosaicMenu.itemSelectedCallback = function () {
		view.componentArea.shortDesc.setText(mosaicMenu.getSelectedItem().getDataObj().description);
	};
}
