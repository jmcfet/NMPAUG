function loaded(){
	var viewXML =
		'<?xml version="1.0" encoding="UTF-8" ?> \
		<view xmlns="http://www.example.org/nagra"> \
			<label id="title" x="100" y="100" cssStyle="font-size:25px" text="Example Pivot List" /> \
			<group id="container" x="100" y="200" width="300" height="150"> \
				<clippedGroup id="group" width="300" height="150"> \
					<pivotList id="list" x="10" y="10" itemTemplate="TextItem" focusAtTop="false" wrapAround="true"> \
						<itemConfig movementPositions="0,-50;0,-25;0,0;0,25;0,50;0,75;0,100" \
							opacityValues="0,0.2,0.5,1,0.5,0.2,0" /> \
					</pivotList> \
				</clippedGroup> \
			</group> \
	    </view>';

	var view = {};
	$N.gui.FrameworkCore.loadGUIFromXML(viewXML, document.getElementById("content"), view);
	$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
					list.keyHandler(key);
				});

	// create some test data
	var data = [{"title": "January"}, {"title": "February"}, {"title": "March"}, {"title": "April"}, {"title": "May"}, {"title": "June"},
	            {"title": "July"}, {"title": "August"}, {"title": "September"}, {"title": "October"}, {"title": "November"}, {"title": "December"}];

	// create a data mapper between our test data and BasicListItem
	var dataMapper = {
	    getText: function (item) {
	        return item.title;
	    }
	};

	// initialise the pivot list
	var list = view.container.group.list;

	list.setDataMapper(dataMapper);

	list.setFocusPosition(3);

	list.initialise();
	list.setData(data);
	list.displayData();
}
