/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/services/sdp/ServiceFactory',
	 'jsfw/platform/output/PlayoutManager',
	 'jsfw/services/sdp/BaseService',
	 'jsfw/services/sdp/MetadataService',
	 'jsfw/services/sdp/Bookmark',
	 'jsfw/services/sdp/Signon'
	], 
	function(ServiceFactory, PlayoutManager, BaseService, MetadataService, Bookmark, Signon) {
		var playoutManager,
			bookmark,
			userUid,
			accountUid,
			locale,
			asset = {
				media : {
					AV_PlaylistName : {
						fileName : "http://ott.nagra.com/stable/videopath/big-buck-bunny-sample_B1_100ASSETS_CONT_3_20131024_144716/index.m3u8"
					}
				},
				CONTENT_TYPE: "AST",
				ID : "B1_100ASSETS_034"
			};
		
		// Checks for a bookmark and then resumes playback from the bookmarked position
		function checkForBookmark() {
			Bookmark.init(accountUid);
			Bookmark.getBookmarkForContent(asset.ID, asset.CONTENT_TYPE, function (position) {
				if (position > 0) {
					$("#status").html("Resuming playback from bookmark position: " + position + " seconds");
					playoutManager.playContent(asset, position);
				} else {
					$("#status").html("Playing content from the start");
					playoutManager.playContent(asset);
				}
			});
		}
		
		// Get user details once signed on, then check for bookmarks
		function signonSuccessCallback() {
			ServiceFactory.get("ContextService").getCurrentContext(this, function (context) {
				userUid = context.userUid;
				accountUid = context.accountUid;
				locale = context.locale;
				checkForBookmark();
			}, function () {});
		}
		
		// Perform initialisation and sign on once video has loaded
		function videoLoadedCallback() {
			BaseService.initialise("ott.nagra.com/stable", null, null, null, "/qsp/gateway/http/js", false);
			MetadataService.initialise("ott.nagra.com/stable", "", "/metadata/delivery", "CMS4X", "en_GB");
			Signon.init();
			Signon.registerListener(signonSuccessCallback, this);
			Signon.signonAndInitialiseForNMP("nmp@nagra.com", "nmp");
		}
		
		// Sets a bookmark at the current playback position
		function bookmarkPosition() {
			var currentTime = Math.round(playoutManager.currentTime),
				duration = playoutManager.duration;
			$("#status").html("Bookmarked content at position: " + currentTime + " seconds");
			Bookmark.deleteOrBookmarkCurrentPositionForContent(currentTime, duration, asset.ID, asset.CONTENT_TYPE);
		}
		
		// Initialise a playout manager instance
		playoutManager = new $N.platform.output.PlayoutManager({
			parent : document.getElementById("player"),
			videoLoadedCallback : videoLoadedCallback,
			forceHTML : false,
			attributes : {
				width : 535,
				height : 300,
				controls : false,
				autoPlay : true
			}
		});
		
		// Register handlers
		$("#bookmarkPosition").click(function () {
			bookmarkPosition();
		});
});
