var pageXML='<?xml version="1.0" encoding="UTF-8" ?> \
<view xmlns="http://www.example.org/nagra"> \
	<label id="title" x="100" y="100" cssStyle="font-size:25" text="Example GUI Component Alignment"/> \
	<container id="myContainer" x="100" y="200" width="300" height="300" cssClass="outer"> \
		<label id="label" x="10" y="10" text="non dynamic label" /> \
		<button id="oldButton" width="50" height="50" x="10" y="30" cssClass="inner" /> \
		<label id="centerLabel" x="center" y="middle" text="Center" cssStyle="text-anchor:middle" /> \
		<button id="myButton1" width="50" height="50" x="right" y="middle" cssClass="inner" /> \
		<button id="myButton2" width="50" height="50" x="left" y="middle" cssClass="inner" /> \
		<button id="myButton3" width="50" height="50" x="center" y="bottom" cssClass="inner" /> \
	</container> \
</view>';


var keyHandler = function (key) {
    var keys = $N.apps.core.KeyInterceptor.getKeyMap();

    switch (key) {
        case keys.KEY_ONE:
            view.myContainer.setWidth(200);
            break;
        case keys.KEY_TWO:
            view.myContainer.setWidth(500);
            break;
        case keys.KEY_THREE:
            view.myContainer.setWidth(800);
            break;
        case keys.KEY_FOUR:
            view.myContainer.setHeight(200);
            break;
        case keys.KEY_FIVE:
            view.myContainer.setHeight(500);
            break;
        case keys.KEY_SIX:
            view.myContainer.setHeight(800);
            break;
        case keys.KEY_SEVEN:
            view.myContainer.centerLabel.setText("OK");
            break;
        case keys.KEY_EIGHT:
            view.myContainer.centerLabel.setText("A Larger String!");
            break;
    }
};

var view = {};

$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);
$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
    keyHandler(key);
});