/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/platform/output/NMPPluginHelper'], 
	function(NMPPluginHelper) {
		// Initialisation response
		function upgradeCallback(data) {
			var div = document.getElementById('target');
			div.innerHTML = div.innerHTML + '<strong>Status : </strong>' + data.status + '<br><strong>Version : </strong>' + data.version;
		}
		
		// Initialise NMP plugin helper
		function init() {
			NMPPluginHelper.init("player", "nmpPlayer", "1365178457P17-prm.Win32.671da6ce8485cc24a581be91d35bbf5b8ca703dbca0973f4b4b3f4a4baa4e96d", false, upgradeCallback);
		}
		
		// Play video using the loaded plugin
		function play() {
			var videoPlayer = document.getElementById("nmpPlayer");
			videoPlayer.videoElement.src = "http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8";
			videoPlayer.videoElement.load();
			videoPlayer.videoElement.play();
		}
		
		// Register handlers
		$("#checkForUpgrade").click(function () {
			init();
		});
		
		$("#pluginPlay").click(function () {
			play();
		});
});	
