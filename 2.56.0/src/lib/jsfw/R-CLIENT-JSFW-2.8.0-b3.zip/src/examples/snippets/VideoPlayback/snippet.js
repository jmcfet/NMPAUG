/*global require*/
window.$N = {};
require.config({
	baseUrl: '',
	paths: {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/platform/output/PlayoutManager'],
	function (PlayoutManager) {
    var myPlayer,
      	videoLoaded = function () {
 			myPlayer.src = 'http://peach.themazzone.com/durian/movies/sintel-1024-surround.mp4';
 			myPlayer.play();
 		};
		myPlayer = new $N.platform.output.PlayoutManager({parent: document.getElementById("content"), videoLoadedCallback: videoLoaded, forceHTML: true, attributes: {width: 640, height: 480, controls: true, autoPlay: true } });
    }
);