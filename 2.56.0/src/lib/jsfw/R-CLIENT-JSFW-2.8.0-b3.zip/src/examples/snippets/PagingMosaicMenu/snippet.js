function pageLoaded(){
	var pageXML =
	'<?xml version="1.0" encoding="UTF-8" ?> \
	    <view xmlns="http://www.example.org/nagra"> \
	    <group id="componentArea"> \
	         <pagingMosaicMenu id="mosaic" rows="2" x="100" y="100" wrapAround="true" columns="3" itemTemplate="GeneralMosaicTile"> \
	         <itemConfig width="195" height="130" /> \
	      </pagingMosaicMenu> \
	     <label id="shortDesc" x="100" y="450"/> \
	   </group> \
	</view>';

	var imagePath = "./resources//images/",
		componentArea,
		shortDesc,
		mosaicMenu = {},
		view = {},
		mosaicData = [];

	var addTile = function (title, url, description) {
		mosaicData.push({title: title, url: url, description: description});
	};

	var keyHandler = function(key){
	    return mosaicMenu.keyHandler(key);
	};

	var createComponents = function(){
	    addTile("yast", imagePath + "yast.PNG", "YAST - Tetris, but on your TV. What will your high score be?");
		addTile("invaders", imagePath + "invaders.png", "Invaders - Classic gaming with Space Invaders");
		addTile("picasa", imagePath + "picasa.JPG", "Picasa - Fast and easy photo sharing from Google. Share with friends and family, or explore public photos.");
		addTile("weather", imagePath + "weather.PNG", "Weather - National text forecasts for up to a day ahead, with maps of temperature, precipitation and wind.");
		addTile("vodafone", imagePath + "vodafone.PNG", "Vodafone - Visit Vodafone for the latest mobile phones and discover more on mobile internet, mobile broadband, mobile email, music and much more.");
		addTile("exit", imagePath + "tv.PNG", "Exit application");
		addTile("vodafone", imagePath + "vodafone.PNG", "Vodafone - Visit Vodafone for the latest mobile phones and discover more on mobile internet, mobile broadband, mobile email, music and much more.");
		addTile("invaders", imagePath + "invaders.png", "Invaders - Classic gaming with Space Invaders");
		addTile("picasa", imagePath + "picasa.JPG", "Picasa - Fast and easy photo sharing from Google. Share with friends and family, or explore public photos.");
		addTile("yast", imagePath + "yast.PNG", "YAST - Tetris, but on your TV. What will your high score be?");
		addTile("weather", imagePath + "weather.PNG", "Weather - National text forecasts for up to a day ahead, with maps of temperature, precipitation and wind.");
		addTile("exit", imagePath + "tv.PNG", "Exit application");
		addTile("yast", imagePath + "yast.PNG", "YAST - Tetris, but on your TV. What will your high score be?");
		addTile("weather", imagePath + "weather.PNG", "Weather - National text forecasts for up to a day ahead, with maps of temperature, precipitation and wind.");
		addTile("invaders", imagePath + "invaders.png", "Invaders - Classic gaming with Space Invaders");
		addTile("vodafone", imagePath + "vodafone.PNG", "Vodafone - Visit Vodafone for the latest mobile phones and discover more on mobile internet, mobile broadband, mobile email, music and much more.");
		addTile("exit", imagePath + "tv.PNG", "Exit application");
		addTile("picasa", imagePath + "picasa.JPG", "Picasa - Fast and easy photo sharing from Google. Share with friends and family, or explore public photos.");
	};

	$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);
	$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), keyHandler, null, null);

	mosaicMenu = view.componentArea.mosaic;
	mosaicMenu.setDataMapper({
		getTitle: function (data) {return "";},
		getSubtitle: function (data) {return "";},
		getImageUrl: function (data) {return data.url;},
	});
	mosaicMenu.setItemHighlightedCallback(function () {
		view.componentArea.shortDesc.setText(mosaicMenu.getSelectedItem().description);
	});

    createComponents();

    mosaicMenu.setOrientation($N.gui.AbstractCustomisableList.consts.ORIENTAION_HORIZONTAL);
    mosaicMenu.initialise();

    mosaicMenu.itemSelectedCallback = function () {
		view.componentArea.shortDesc.setText(mosaicMenu.getSelectedItem().description);
	};

    mosaicMenu.setData(mosaicData);
	mosaicMenu.displayData();
	mosaicMenu.itemSelectedCallback();
}
