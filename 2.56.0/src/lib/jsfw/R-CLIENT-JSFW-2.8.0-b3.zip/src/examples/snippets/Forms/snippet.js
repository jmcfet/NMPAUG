var pageXML = '<?xml version="1.0" encoding="UTF-8" ?> \
    <view xmlns="http://www.example.org/nagra"> \
        <label id="title" x="100" y="100" cssStyle="font-size:25" text="Example Form" /> \
        <form id="myForm" x="200" y="200" wrapAround="false" > \
            <button id="myButton1" x="0" y="0" width="100" height="50" rounding="5" label="1" cssClass="button" highlightCssClass="buttonHighlight" /> \
            <button id="myButton2" x="120" y="0" width="100" height="50" rounding="5" label="2" cssClass="button" highlightCssClass="buttonHighlight" /> \
            <button id="myButton3" x="240" y="0" width="100" height="50" rounding="5" label="3" cssClass="button" highlightCssClass="buttonHighlight" /> \
        </form> \
    </view>';

var view = {};

var keyHandler = function (key) {
	var keys = $N.apps.core.KeyInterceptor.getKeyMap();
	view.myForm.keyHandler(key);
};

$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);

$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
	keyHandler(key);
});

var button = new $N.gui.Button(document, view.myForm);

button.configure({
	id: "myButton4", x: 360, y: 0, width: 100, height: 50, rounding: 8, label: "4",
	cssClass: "button", highlightCssClass: "buttonHighlight"
});
			
view.myForm.addControl(button);
view.myForm.setDefaultTabDirection($N.gui.Form.HORIZONTAL);
view.myForm.highlight();