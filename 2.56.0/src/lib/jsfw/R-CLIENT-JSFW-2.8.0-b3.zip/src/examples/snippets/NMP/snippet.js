/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/platform/output/PlayoutManager'],
	function(PlayoutManager) {
		var playoutManager;

		function videoLoadedCallback() {
			playoutManager.src = "http://ott.nagra.com/stable/videopath/big-buck-bunny-sample_B1_100ASSETS_CONT_3_20131024_144716/index.m3u8";
		}

		function videoUpgradeCallback(response) {
			if (response.status === "PLAYER_INSTALLING") {
				alert("The NMPC Browser Plugin is required to run this example.");
			}
		}

		// Initialise a playout manager instance
		playoutManager = new PlayoutManager({
			parent : document.getElementById("player"),
			videoLoadedCallback : videoLoadedCallback,
			forceHTML : false,
			upgrade: {
				applicationData: "player",
				callback: videoUpgradeCallback
			},
			attributes : {
				width : 535,
				height : 300,
				controls : false,
				autoPlay : false
			}
		});
	});