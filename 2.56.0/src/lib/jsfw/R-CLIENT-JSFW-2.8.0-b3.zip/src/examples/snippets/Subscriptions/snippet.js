/*global require*/
window.$N = {};
require.config({
	baseUrl : '',
	paths : {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(
	['jsfw/services/sdp/Subscriptions',
	 'jsfw/services/sdp/Signon',
	 'jsfw/services/sdp/BaseService',
	 'jsfw/services/sdp/MetadataService',
	 'jsfw/services/sdp/EPG'
	],
	function(Subscriptions, Signon, BaseService, MetadataService, EPG) {
		function subscriptionsChanged() {
			console.log("Subscriptions changed");
		}

		function showAll() {
			var i,
				cssClass;
			$('#title').html("All Channels");
			$('#channelList').html("");
			EPG.fetchAllChannels(function (channels) {
				channels.forEach(function(c) {
					cssClass = c.isSubscribed ? "subscribed" : "unsubscribed";
					$('#channelList').append('<li class="' + cssClass + '">' + c.serviceId + '</li>');
				});
			});

		}

		// Get the subscribed channels and print the result
		function getSubscriptions() {
			var channels = Subscriptions.getSubscribedChannels();
			$('#title').html("Subscribed Channels");
			$('#channelList').html("");
			channels.forEach(function(c) {
				$('#channelList').append('<li class="subscribed">' + c.serviceId + '</li>');
			});
		}

		// Refresh subscriptions
		function signonSuccessCallback() {
			Subscriptions.refreshSubscriptions(function () {
				$("#showAll").show();
				$("#showSubscribed").show();
			});
			Subscriptions.addEventListener("subscriptionsChanged", subscriptionsChanged);
		}

		$("#showAll").click(showAll);
		$("#showSubscribed").click(getSubscriptions);

		// Initialisation
		BaseService.init("ott.nagra.com/stable", null, null, null, "/qsp/gateway/http/js", false);
		MetadataService.init("ott.nagra.com/stable", "", "/metadata/delivery", "B1", "en_GB");
		Signon.init();
		Signon.registerListener(signonSuccessCallback, this);
		Signon.signonByUser("basic", "nmp");
		EPG.init();
});