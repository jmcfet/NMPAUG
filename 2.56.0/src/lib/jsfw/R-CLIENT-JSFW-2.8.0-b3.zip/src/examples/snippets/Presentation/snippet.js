var viewXML = '<?xml version="1.0" encoding="UTF-8" ?> \
    <view xmlns="http://www.example.org/nagra"> \
	    <label id="label_title" /> \
	    <button id="button_style_a" /> \
	    <button id="button_style_b" /> \
	    <button id="button_style_c" /> \
    </view>';

var view = {},
presentationCallback = function () {
    $N.gui.PresentationManager.configure(view.label_title);
    $N.gui.PresentationManager.configure(view.button_style_a);
    $N.gui.PresentationManager.configure(view.button_style_b);
    $N.gui.PresentationManager.configure(view.button_style_c);
};

var keyHandler = function (key) {
    var keys = $N.apps.core.KeyInterceptor.getKeyMap();

    var handled = false;

    switch (key) {
        case keys.KEY_ONE:
            $N.gui.PresentationManager.setLocale("en_gb");
            $N.gui.PresentationManager.refreshPresentationPacks();
            handled = true;
            break;
        case keys.KEY_TWO:
            $N.gui.PresentationManager.setLocale("en_us");
            $N.gui.PresentationManager.refreshPresentationPacks();
            handled = true;
            break;
        case keys.KEY_THREE:
            $N.gui.PresentationManager.setLocale("es_es");
            $N.gui.PresentationManager.refreshPresentationPacks();
            handled = true;
            break;
    };

    return handled;
};

$N.gui.FrameworkCore.loadGUIFromXML(viewXML, document.getElementById("content"), view);

$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
    keyHandler(key);
});

view.label_title.setText("This is an example of using the PresentationManager");

$N.gui.PresentationManager.setLocale("en_gb");
$N.gui.PresentationManager.loadPresentationPack(presentationCallback, "resources/", "PresentationPack.js", presentationCallback);