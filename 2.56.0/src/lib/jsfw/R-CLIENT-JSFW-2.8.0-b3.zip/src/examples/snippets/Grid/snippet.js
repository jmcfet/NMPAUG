var pageXML = '<?xml version="1.0" encoding="UTF-8" ?> \
<view xmlns="http://www.example.org/nagra"> \
<label id="title" x="100" y="100" cssStyle="font-size:25" text="Example Grid Guide" /> \
<timedEventGridControlWithChannels id="grid" x="300" y="200" width="800" height="300" numOfRows="5" numOfHours="2" channelListWidth="200" selectedItemTimeOutMS="600" /> \
</view>';

var view = {},
	/*
	SDP_URL = "ott.nagra.com/stable",
	SDP_PATH = "/qsp/gateway/http/js",
	*/
	SDP_URL = "nmp.nagra.com",
	SDP_PATH = "/qsp/gateway/http/js",
	MAC_ADDRESS = "00-05-9E-00-00-18",
	MDS = {
		LOCALE: "en_GB",
		URL: "ott.nagra.com/stable",
		PATH: "/metadata/delivery",
		PORT: "",
		SERVICE_PROVIDER: "B1"
	},
	locale = "en_gb",
	gridControlChannelDataMapper = {
		getServiceId: function (obj) {
			return obj.serviceId + "";
		},
		getChannelNumber: function (obj) {
			return obj.logicalChannelNum > 0 ? obj.logicalChannelNum : " ";
		},
		getTitle: function (obj) {
			return obj.serviceName;
		},
		isBlocked: function () {
			return false;
		},
		getIcon: function () {
			return "";
		},
		isSubscribed: function () {
			return true;
		}
	},
	gridControlEventDataMapper = {

		getServiceId: function (obj) {
			return obj.serviceId + "";
		},
		getStartTime: function (obj) {
			return obj.startTime;
		},
		getEndTime: function (obj) {
			return obj.endTime;
		},
		getTitle: function (obj, chan) {
			return obj.title;
		},
		getIcon: function (obj, chan) {
			return "";
		}
	};

function loadIpData() {
$N.services.sdp.IPDataLoader.init({
	locale: locale,
	refreshInterval: 12,
	maxDays: 7,
	fetchDuration: 2
	}, $N.platform.btv.EPGCache);
	$N.platform.btv.EPG.refresh();
	$N.services.sdp.IPDataLoader.loadIPData();
}

function doBootstrap() {
	$N.services.sdp.BootStrap.startBootStrapByMac(MAC_ADDRESS, function (result) {
		if (result) {
			locale = result.defaultLocale;
		}
		loadIpData();
	});
}

function doSignon() {
	$N.services.sdp.Signon.registerListener(loadIpData, this);
	$N.services.sdp.Signon.setSignonFailedCallback(function () {
		$N.services.sdp.Signon.unregisterListener(doBootstrap);
	});
	$N.services.sdp.Signon.signonByMACAddress(MAC_ADDRESS);
}

function keyHandler(key) {
	var keys = $N.apps.core.KeyInterceptor.getKeyMap();
	view.grid.keyHandler(key);
}

$N.gui.FrameworkCore.loadGUIFromXML(pageXML, document.getElementById("content"), view);

$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
	keyHandler(key);
});

$N.services.sdp.BaseService.initialise(SDP_URL, null, null, null, SDP_PATH);
//$N.services.sdp.MetadataService.initialise(SDP_URL, '', '/metadata/delivery', 'B1', 'en_GB');
$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, null, MDS.LOCALE);

$N.platform.btv.EPG.initialise();
$N.services.sdp.EPG.initialise();
$N.services.sdp.Signon.init();

doSignon();

setTimeout(function () {
	view.grid.initialise();
	view.grid.setChannelListData($N.platform.btv.EPG.getAllChannels());
	view.grid.setEventDataMapper(gridControlEventDataMapper);
	view.grid.setChannelDataMapper(gridControlChannelDataMapper);
	view.grid.activate();
}, 3000);

