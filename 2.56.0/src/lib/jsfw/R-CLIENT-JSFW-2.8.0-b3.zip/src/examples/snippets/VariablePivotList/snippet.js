/**
 * VariableListItem
 *
 * Data Mapper Requirements;
 *    {String} getTitle
 *
 * @constructor
 * @param {Object} docRef (DOM document)
 */

var $N = $N || window.parent.$N;

function VariableListItem(docRef) {
	VariableListItem.superConstructor.call(this, docRef);

	this._container = new $N.gui.Container(docRef);
	this._title = new $N.gui.Label(docRef, this._container);

	this._container.configure({
		x: 10,
		y: 3,
		cssClass: "variableListItemContainer"
	});

	this._title.configure({
		x: 10,
		y: 20,
		cssClass: "variableListItemText"
	});

	this._rootSVGRef = this._container.getRootSVGRef();

	this.addMoveAnimation(docRef);
	this.addFadeAnimation(docRef);
	this.addScaleAnimation(docRef);
}

$N.apps.util.Util.extend(VariableListItem, $N.gui.AbstractListItem);

/**
 * Highlights the item .
 * @method highlight
 *
 */

VariableListItem.prototype.highlight = function () {
};

/**
 * Unhighlights the item .
 * @method unHighlight
 *
 */
VariableListItem.prototype.unHighlight = function () {
	this._moveAnim.setAnimationEndCallback(null);
};

/**
 * Sets the item width.
 * @method setWidth
 * @param  width
 *
 */
VariableListItem.prototype.setWidth = function (width) {
	this._width = width;
	this._container.setWidth(width);
};

/**
 * Gets the item width.
 * @method getWidth
 *
 */
VariableListItem.prototype.getWidth = function () {
	return this._width;
};

/**
 * Enable item.
 * @method enable
 */
VariableListItem.prototype.enable = function () {
	this._title.setCssClass("variableListItemText");

};

/**
 * Disable item.
 * @method disable
 */
VariableListItem.prototype.disable = function () {
	this._title.setCssClass("variableListItemTextDisable");
};

/**
 * Updates item
 * @method update
 * @param  data
 *
 */
VariableListItem.prototype.update = function (data) {
	var title;
	if (data) {
		title = this._dataMapper.getTitle(data);
		this._title.setText(title);
		this._id = title;
		this.setWidth(this._title.getTrueTextLength() + this._title.getFontSize());
	}
};

function loaded(){
	var viewXML =
	    '<?xml version="1.0" encoding="UTF-8" ?> \
	    <view xmlns="http://www.example.org/nagra"> \
	        <label id="title" x="100" y="100" cssStyle="font-size:25px" text="Example Variable Pivot List" /> \
	            <group id="container" x="100" y="150" width="800" height="160" cssClass="variableListContainer"> \
	                <clippedGroup id="group" x="0" y="10" width="800" height="290"> \
	                    <variablePivotList id="list" x="10" y="10" itemTemplate="VariableListItem" orientation="vertical" padding="20"> \
	                        <itemConfig movementPositions="-200,0;0,0;100,0;100,0;100,0;100,0;100,0;100,0;100,0;800,0" opacityValues="0,1,1,1,1,1,1,1,1,0" /> \
	                    </variablePivotList> \
	                </clippedGroup> \
	            </group> \
	    </view>';

	var view = {};

	$N.gui.FrameworkCore.loadGUIFromXML(viewXML, document.getElementById("content"), view);
	$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), function (key) {
					list.keyHandler(key);
	});


	var data = [{"title": "Moon River"}, {"title": "Wider than a mile"}, {"title": "I'm"}, {"title": "crossing"},
	            {"title": "you in style"}, {"title": "some day"}, {"title": "0, dream maker, you heart breaker"},
	            {"title": "Wherever you're goin', I'm goin' your way"}, {"title": "Two drifters"},
	            {"title": "off to see the world"}, {"title": "There's such a lot of world to see"},
	            {"title": "We're after"}, {"title": "the same rainbow's end, waitin' round the bend"},
	            {"title": "My huckleberry friend"}, {"title": "Moon River"}, {"title": "and me"}];


	var dataMapper = {
		getTitle: function (item) {
			return item.title;
		}
	};

	var list = view.container.group.list;
	list.setDataMapper(dataMapper);

	list.initialise();
	list.setData(data);

	list.displayData();
}