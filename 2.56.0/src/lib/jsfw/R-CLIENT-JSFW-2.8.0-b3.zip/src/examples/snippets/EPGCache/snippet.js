/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('cacheView',
	[],
	function () {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.cacheView = (function () {

			var channels = $("#channels"),
				eventList = $("#events "),
				eventInfo = $("#eventObj"),
				savedEvents = {},
				prop,
				process = {
					SIGN_ON_SUCCESSFUL:		'This page demonstrates the use of caching of EPG data using the Nagra MediaLive Client Framework. ' + "</br>"
											+ 'Channel (or services) data is retrieved from the server can be cached in memory (RAM cache) or in a database (Persistent Cache). ' + "</br>"
											+ 'Optionally events can be cached as well.' + "</br>"
											+ 'Within the browser, data is persisted within a WebSQL database.' + "</br>"
											+ 'If persistent cache is to be used, Please ensure that the PERSISTENT_CACHE boolean is set to true within Config.js. ' + "</br>"
											+ 'Otherwise RAM cache wil be used. ' + "</br>"
											+ 'Press Load Channels to retrieve data from the server and cache.' + "</br>"
											+ 'Server requests are viewable in a chrome browser under Tools / Javascript Console / Network / XHR',
					LOADING: 				'Loading server data into local cache. Please wait. ' + "</br>"
											+ 'Server requests viewable in a chrome browser under Tools / Javascript Console / Network / XHR',
					LOAD_INTO_RAM: 			'Data loaded into RAM cache. Data will not persist after browser session is closed. ' + "</br>"
											+ 'Press Get Channels to get data.',
					LOAD_INTO_PERSISTENT: 	'Data loaded into Persistent cache (WebSQL database). Data will persist after browser session is closed. ' + "</br>"
											+ 'Persisted data is viewable within a chrome browser under Tools / Jaavscript Console / Resources / Web SQL / EPG' + "</br>"
											+ 'Press Get Channels to get data.',
					GET_CACHED_DATA: 		'Get data from cache. No server requests are made.',
					CLEAR_CACHED_DATA: 		'Clear data from cache.',
					EVENTS_REQUESTED: 		'Loading event data. Please wait.',
					NO_CHANNEL_SELECTED: 	'Please select one or more channels from the list and then press the fetch events by window button.',
					EVENTS_RETRIEVED:		'Events retrieved for the selected channels within the selected time window.' + "</br>"
											+ 'If Cache Events was set to selected and cached events exist for the selected time window' + "</br>"
											+ 'then the events are retrieved from cached data. ' + "</br>"
											+ 'Otherwise events are retrieved from the server.' + "</br>"
											+ 'Server requests are viewable in a chrome browser under Tools / Javascript Console / Network / XHR ' + "</br>"
											+ 'Click on event to display details of that event.'
				};

			function showChannels() {
				$("#channelList").css("visibility", "visible");
				$("#selectChannelText").css("visibility", "visible");
				$("#fetchEventsByWindow").prop('disabled', false);
			}

			function clearEvents() {
				eventList.html();
				$("#events").empty();
				$("#eventObj").empty();
				$("#eventImage").hide();
			}

			function clearAll() {
				$("#fetchEventsByWindow").prop('disabled', true);
				$("#channelList").css("visibility", "hidden");
				$("#selectChannelText").css("visibility", "hidden");
				clearEvents();
			}

			function clearChannelList() {
				$("#channelList").empty();
			}

			function populateChannelList(allChannels) {
				var channels,
					optionName,
					channelText,
					targetLength,
					i,
					channelOptions,
					channelsHtml = "";

				clearChannelList();
				channelOptions = $("#channelList")[0];
				clearEvents();

				channels = allChannels;
				for (i = 0; i < channels.length; i++) {
					channelsHtml += "<p id='" + channels[i].serviceId + "'>" + channels[i].logicalChannelNum + ": " + channels[i].serviceName + "</p>\n";
				}
				for (i = 0; i < channels.length; i++) {
					//add channels to drop down list
					channelText = channels[i].serviceName + " (" + channels[i].serviceId + ")";
					optionName = new Option(channelText, channels[i].serviceId);
					targetLength = channelOptions.length;
					channelOptions.options[targetLength] = optionName;
				}
			}

			function clearEventList() {
				$("#events").empty();
			}

			function populateEventList(returnedEvents) {
				var i,
					eventsHtml = "<p>Number of events: " + returnedEvents.length + "</p>",
					date;

				eventList.html();
				savedEvents = {};

				for (i = 0; i < returnedEvents.length; i++) {
					savedEvents[returnedEvents[i].eventId] = returnedEvents[i];
					date = new Date(returnedEvents[i].startTime);
					eventsHtml += "<p id='" + returnedEvents[i].eventId + "'>" + returnedEvents[i].serviceId + " "  + returnedEvents[i].title  + " - " + returnedEvents[i].eventId + " @ " + date.getDate() + "/" + (date.getMonth() + 1) + " " + date.getHours() + ":" + date.getMinutes() + "</p>\n";
				}
				eventList.html(eventsHtml);

				$("#events p").click(function () {
					var returnedEvent = savedEvents[this.id],
						eventInfoHTML = "";
					if (returnedEvent) {
						for (prop in returnedEvent) {
							eventInfoHTML += prop + ": " + ((prop === 'startTime' || prop === 'endTime') ? new Date(returnedEvent[prop]) : returnedEvent[prop]) + "<br/>";
						}
						eventInfo.html(eventInfoHTML);
						var imageResult = returnedEvent.promoImage;
						if (typeof imageResult === 'function') {
							imageResult(function (url) {
								console.log("Image was fetched......");
								$("#eventImage").show();
								$("#eventImage").attr("src", url);
							});
						} else {
							console.log("Image was cached......");
							try {
								$("#eventImage").show();
								$("#eventImage").attr("src", imageResult);
							} catch (ex) {
							}
						}
						var yearResult = returnedEvent.year;
						if (typeof yearResult === 'function') {
							yearResult(function (year) {
								console.log("Year: " + year);
							});
						} else {
							console.log("Year: " + yearResult);
						}
					}
				});
			}

			function getChannelArray() {
				var i,
					channelOptions = $("#channelList")[0],
					channelArray = [];

				for (i = 0; i < channelOptions.options.length; i++) {
					if (channelOptions.options[i].selected === true) {
						channelArray.push(channelOptions.options[i].value);
					}
				}
				return channelArray;
			}

			function getSelectedChannel() {
				return $("#channelList")[0].options[$("#channelList")[0].selectedIndex].value;
			}

			function setEventListText(text) {
				eventList.html("<p>" + text + "</p>");
			}

			function getStartTime() {
				var	tempDate = new Date(),
					fromHourOptions = $("#fromHourList")[0],
					fromMinuteOptions = $("#fromMinuteList")[0],
					fromDate = $("#fromdatepicker").datepicker('getDate'),
					fromHr = fromHourOptions.options[fromHourOptions.selectedIndex].value,
					fromMin = fromMinuteOptions.options[fromMinuteOptions.selectedIndex].value,
					startTime;

				if (fromDate) {
					tempDate.setDate(fromDate.getDate());
					tempDate.setMonth(fromDate.getMonth());
					tempDate.setFullYear(fromDate.getFullYear());
				}
				tempDate.setHours(fromHr);
				tempDate.setMinutes(fromMin);
				tempDate.setSeconds(0, 0);
				return tempDate.getTime();
			}

			function getEndTime() {
				var	tempDate = new Date(),
					toHourOptions = $("#toHourList")[0],
					toMinuteOptions = $("#toMinuteList")[0],
					toHr = toHourOptions.options[toHourOptions.selectedIndex].value,
					toMin = toMinuteOptions.options[toMinuteOptions.selectedIndex].value,
					toDate = $("#todatepicker").datepicker('getDate'),
					endTime;

				if (toDate) {
					tempDate.setDate(toDate.getDate());
					tempDate.setMonth(toDate.getMonth());
					tempDate.setFullYear(toDate.getFullYear());
				}
				tempDate.setHours(toHr);
				tempDate.setMinutes(toMin);
				tempDate.setSeconds(0, 0);
				return tempDate.getTime();
			}

			function populateTimePicker() {
			    var i,
					optionName,
					targetLength,
					fromHourOptions = $("#fromHourList")[0],
					fromMinuteOptions = $("#fromMinuteList")[0],
					toHourOptions = $("#toHourList")[0],
					toMinuteOptions = $("#toMinuteList")[0];

			    for (i = 0; i < 24; i++) {
					//add hours to drop down list
					optionName = new Option(i, i);
					targetLength = fromHourOptions.length;
					fromHourOptions.options[targetLength] = optionName;
					optionName = new Option(i, i);
					toHourOptions.options[targetLength] = optionName;
				}

				for (i = 0; i < 60; i++) {
					//add minutes to drop down list
					optionName = new Option(i, i);
					targetLength = fromMinuteOptions.length;
					fromMinuteOptions.options[targetLength] = optionName;
					optionName = new Option(i, i);
					toMinuteOptions.options[targetLength] = optionName;
				}
			}

			function isCacheTypeRAM() {
				if ($("#cacheTypePC").attr("checked")) {
					return false;
				}
				return true;
			}

			function isCacheEvents() {
				if ($("#cacheEventsNo").attr("checked")) {
					return false;
				}
				return true;
			}

			function setHelpText(message) {
				$("#helpText").html('<p>' + message + '</p>').show();
			}

			/*
			 * Public API
			 */
			return {
				showChannels: showChannels,
				clearAll: clearAll,
				clearEvents: clearEvents,
				populateChannelList: populateChannelList,
				populateEventList: populateEventList,
				clearChannelList: clearChannelList,
				clearEventList: clearEventList,
				getChannelArray:  getChannelArray,
				populateTimePicker: populateTimePicker,
				getSelectedChannel: getSelectedChannel,
				setEventListText: setEventListText,
				getStartTime: getStartTime,
				getEndTime: getEndTime,
				isCacheTypeRAM: isCacheTypeRAM,
				isCacheEvents: isCacheEvents,
				setHelpText: setHelpText,
				PROCESS: process
			};

		}());
		return $N.app.cacheView;
	}
);
/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('cacheModel',
	[
		'jsfw/Config',
		'jsfw/apps/core/Log',
		'jsfw/platform/btv/EPGCache',
		'jsfw/platform/btv/PersistentCache',
		'jsfw/platform/btv/EPG',
		'jsfw/services/sdp/Signon',
		'jsfw/services/sdp/IPDataLoader',
		'jsfw/services/sdp/EPG'
	],
	function (Config, Log, EPGCache, PersistentCache, BTVEPG, Signon, IPDataLoader, SDPEPG) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.cacheModel = (function () {

			var	SDP = {
					LOCALE: "en_gb"
				},
				ipDataLoader = {
					refreshInterval: 12,
					maxDays: 2,
					fetchDuration: 6
				},
				cacheType;

			function init(MDS, SDP, signOnSuccessCallback, refreshCallback) {
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, null, MDS.LOCALE);
				$N.apps.core.Log.Config.configure({
					defaultValues: 1,
					classLogging: {
						EPG: 1,
						SDP: 1
					}
				});
				$N.platform.btv.PersistentCache.init();
				$N.services.sdp.EPG.initialise();
				$N.platform.btv.EPG.registerRefreshCallback(function () {
					refreshCallback();
				}, this);
				$N.services.sdp.Signon.init();
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.registerListener(signOnSuccessCallback, this);
				$N.services.sdp.Signon.signonByUser(SDP.USER, SDP.PASSWORD);
			}

			function setChannelsLoadedCallback(callback) {
				$N.services.sdp.IPDataLoader.setChannelsLoadedCallback(callback);
			}

			function loadIpData(iPDataLoader_Listener_Fired, isCacheTypeRAM, isCacheEvents) {

				cacheType = isCacheTypeRAM ? $N.platform.btv.EPG.CACHE_TYPES.RAM : $N.platform.btv.EPG.CACHE_TYPES.Persistent;

				$N.services.sdp.IPDataLoader.init({
					locale: SDP.LOCALE,
					refreshInterval: ipDataLoader.refreshInterval,
					maxDays: ipDataLoader.maxDays,
					forceRAMCache: isCacheTypeRAM,
					cacheEvents: isCacheEvents,
					fetchDuration: ipDataLoader.fetchDuration
				});

				$N.platform.btv.EPG.initialise({
					cacheEvents: isCacheEvents,
					dataSources: [$N.platform.btv.EPG.DATA_SOURCES.SDP], //[$N.platform.btv.EPG.DATA_SOURCES.SDP] add in for dynamic EPG
					cacheType: cacheType,
					cacheExpiryTime: 60 * 60 * 10000
				});
				$N.services.sdp.IPDataLoader.registerListener(iPDataLoader_Listener_Fired, this);
				$N.services.sdp.IPDataLoader.loadIPData();
			}

			function fetchEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback) {
				$N.platform.btv.EPG.fetchEventsByWindow(serviceArray, startTime, endTime, successCallback, failureCallback);
			}

			function clearCache() {
				$N.platform.btv.EPGCache.clearCache();
				$N.platform.btv.PersistentCache.clearCache();
			}

			function refresh(listener) {
				$N.services.sdp.IPDataLoader.unregisterListener(listener);
				$N.platform.btv.EPG.refresh();
			}

			function fetchAllChannels(successCallback) {
				if (cacheType === $N.platform.btv.EPG.CACHE_TYPES.RAM) {
					successCallback($N.platform.btv.EPGCache.getServices());
				} else {
					$N.platform.btv.PersistentCache.fetchServices(successCallback);
				}
			}

			return {
				init: init,
				setChannelsLoadedCallback: setChannelsLoadedCallback,
				loadIpData: loadIpData,
				fetchEventsByWindow: fetchEventsByWindow,
				fetchAllChannels: fetchAllChannels,
				clearCache: clearCache,
				refresh: refresh
			};
		}());
		return $N.app.cacheModel;
	}
);
/*global require,Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('cacheController',
	[
		'cacheView',
		'cacheModel'
	],
	function (cacheView, cacheModel) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.cacheController = (function () {

			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp'
				};

			// BTV EPG callbacks
			function btv_EPG_Refresh_Fired() {
				console.log("****************************************************************************");
				console.log("********************************************* btv epg refresh fired");
				console.log("****************************************************************************");
			}

			function iPDataLoader_Listener_Fired() {
				console.log("****************************************************************************");
				console.log("********************************************* ip data loader listener fired");
				console.log("****************************************************************************");
				//cacheModel.refresh(iPDataLoader_Listener_Fired);
			}

			function channelsLoadedCallback() {
				console.log("****************************************************************************");
				console.log("********************************************* channels loaded callback fired");
				console.log("****************************************************************************");
				if (cacheView.isCacheTypeRAM()) {
					cacheView.setHelpText(cacheView.PROCESS.LOAD_INTO_RAM);
				} else {
					cacheView.setHelpText(cacheView.PROCESS.LOAD_INTO_PERSISTENT);
				}
				cacheView.showChannels();
			}

			function signOnSuccessCallback() {
				console.log("****************************************************************************");
				console.log("********************************************* sign on success callback fired");
				console.log("****************************************************************************");
				cacheView.setHelpText(cacheView.PROCESS.SIGN_ON_SUCCESSFUL);
			}

			function getEventsByWindowParameters() {
				var parameters = {};
				parameters.serviceArray = cacheView.getChannelArray();
				if (parameters.serviceArray.length === 0) {
					return null;
				}
				parameters.startTime = cacheView.getStartTime();
				parameters.endTime = cacheView.getEndTime();
				return parameters;
			}

			function init() {
				var fetchChannelsCallback = function(channels) {
						cacheView.populateChannelList(channels);
					},
					eventsByWindowParms = {},
					eventsByWindowSuccessCallback = function (nextEvents) {
						if (nextEvents && nextEvents.length > 0) {
							cacheView.setHelpText(cacheView.PROCESS.EVENTS_RETRIEVED);
							cacheView.populateEventList(nextEvents);
						} else {
							cacheView.setEventListText("No events returned for time window for channel(s)");
						}
					},
					eventsByWindowFailureCallback = function () {
						cacheView.setEventListText("Error in retrieving data");
					};

				cacheView.populateTimePicker();
				cacheModel.init(MDS, SDP, signOnSuccessCallback, btv_EPG_Refresh_Fired);

				$("#loadChannelsButton").click(function () {
					cacheView.clearAll();
					$("#channelList")[0].options.length = 0;
					cacheView.setHelpText(cacheView.PROCESS.LOADING);
					cacheModel.setChannelsLoadedCallback(channelsLoadedCallback);
					cacheModel.loadIpData(iPDataLoader_Listener_Fired, cacheView.isCacheTypeRAM(), cacheView.isCacheEvents());
				});

				$("#getChannelsButton").click(function () {
					cacheModel.refresh(true, function() {});
					cacheView.clearChannelList();
					cacheModel.fetchAllChannels(fetchChannelsCallback);
					cacheView.setHelpText(cacheView.PROCESS.GET_CACHED_DATA);
				});

				$("#clearCacheButton").click(function () {
					cacheModel.clearCache();
					cacheView.setHelpText(cacheView.PROCESS.CLEAR_CACHED_DATA);
				});

				$("#fetchEventsByWindow").click(function () {
					eventsByWindowParms = getEventsByWindowParameters();
					cacheView.clearEventList();
					if (eventsByWindowParms) {
						cacheView.setHelpText(cacheView.PROCESS.EVENTS_REQUESTED);
						cacheModel.fetchEventsByWindow(eventsByWindowParms.serviceArray,
														eventsByWindowParms.startTime,
														eventsByWindowParms.endTime,
														eventsByWindowSuccessCallback,
														eventsByWindowFailureCallback);

					} else {
						cacheView.setHelpText(cacheView.PROCESS.NO_CHANNEL_SELECTED);
					}
				});
			}
			return {
				init: init
			};
		}());
		return $N.app.cacheController;
	}
);
$(function() {
	$( "#fromdatepicker" ).datepicker({ dateFormat: 'dd-mm-yy' }).val();
});
$(function() {
	$( "#todatepicker" ).datepicker({ dateFormat: 'dd-mm-yy' }).val();
});

/*global require*/
window.$N = {};
require.config({
	baseUrl: '',
	paths: {
		'jsfw' : '../../src',
        'jsfw/services/sdp' : '../../src/services/sdp34mds',
        'jsfw/platform' : '../../src/platform/html5'
	}
});
require(['jsfw/services/sdp/MetadataService'],
	function (MetadataService) {
		if ($N.services.sdp.MetadataService) {
			require(['cacheController'], function (Controller) {
				Controller.init();
			});
		}
	}
);