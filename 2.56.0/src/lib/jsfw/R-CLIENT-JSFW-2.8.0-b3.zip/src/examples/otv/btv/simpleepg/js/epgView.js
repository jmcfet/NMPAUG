/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('js/epgView',
	[
		'jsfw/gui/GUIObjects/Components/Video',
		'jsfw/gui/GUIObjects/Components/ClippedGroup',
		'jsfw/gui/GUIObjects/Components/Group',
		'jsfw/gui/GUIObjects/Components/Label',
		'jsfw/gui/GUIObjects/Components/TextArea',
		'jsfw/gui/GUIObjects/Controls/List/customisable/PivotList',
		'jsfw/gui/GUIObjects/Controls/List/customisable/TextItem',
		'jsfw/apps/util/JSON'
	],
	function (Video, ClippedGroup, Group, Label, TextArea, PivotList, TextItem, JSON) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgView = (function () {

			var channels,
				channelsContainer,
				events,
				eventsContainer,
				isChannelList = true,
				view = {},
				keys,
				channelDataMapper = {
					getText: function (item) {
						return item.serviceName;
					},
					getServiceId: function (item) {
						return item.serviceId;
					}
				},
				eventDataMapper = {
					getText: function (item) {
						return item.title;
					},
					getEventId: function (item) {
						return item.eventId;
					}
				};

/*
 * SET VIEW
 */
			function init(inView, inKeyMap) {
				view = inView;
				channels = view.container.group.channelList;
				channels.setDataMapper(channelDataMapper);
				channels.setFocusPosition(2);
				channels.setWrapAround(false);
				channels.init();
				events = view.eventContainer.eventGroup.eventList;
				events.setDataMapper(eventDataMapper);
				events.setFocusPosition(2);
				events.setWrapAround(false);
				events.init();
				keys = inKeyMap;
			}

/*
 * GETTER METHODS
 */
			function getContentElement() {
				return document.getElementById("content");
			}

			function getSelectedChannel() {
				return channelDataMapper.getServiceId(channels.getSelectedItem());
			}

			function getSelectedEvent() {
				return events.getSelectedItem();
			}

/*
 * DISPLAY CHANNELS
 */
			function showChannels(data) {
				channels.setData(data);
				channels.displayData();
			}


			function showEvents(data) {
				events.setData(data);
				events.displayData();
			}

			function showEvent(event) {
				view.output.setVisible(true);
				view.output.setText($N.apps.util.JSON.stringify(event));
			}

			function isChannelListSelected() {
				return isChannelList;
			}

/*
 * KEY HANDLER
 */
			function showEventContainer(isVisible) {
				view.eventContainer.setVisible(isVisible);

			}

			function keyHandler(key) {
				view.output.setVisible(false);
				switch (key) {
				case keys.KEY_RIGHT:
					if (isChannelList && view.eventContainer.isVisible()) {
						isChannelList = false;
						view.container.setCssClass("unHighlightedList");
						view.eventContainer.setCssClass("highlightedList");
					}
					break;
				case keys.KEY_LEFT:
					if (!isChannelList) {
						isChannelList = true;
						showEventContainer(false);
						view.container.setCssClass("highlightedList");
						view.eventContainer.setCssClass("unHighlightedList");
					}
					break;
				default:
					if (isChannelList) {
						channels.keyHandler(key);
					} else {
						events.keyHandler(key);
					}
				}
			}

			/*
			 * Public API
			 */
			return {
				init: init,
				getContentElement: getContentElement,
				getSelectedChannel: getSelectedChannel,
				getSelectedEvent: getSelectedEvent,
				showChannels: showChannels,
				showEventContainer: showEventContainer,
				showEvents: showEvents,
				showEvent: showEvent,
				keyHandler: keyHandler,
				isChannelListSelected: isChannelListSelected
			};
		}());
		return $N.app.epgView;
	}
);
