/*global require*/
window.$N = {};
window.jQuery = null;
require.config({
    baseUrl : '',
    paths : {
        'jsfw' : '../../../jsfw/src',
        'jsfw/services/sdp' : '../../../jsfw/src/services/sdp34mds',
        'jsfw/platform': '../../../jsfw/src/platform/html5'
    }
});
require(
	[
		'js/epgController'
	],
	function (Controller) {
		Controller.load('html5/xml/epg.xml');
	}
);