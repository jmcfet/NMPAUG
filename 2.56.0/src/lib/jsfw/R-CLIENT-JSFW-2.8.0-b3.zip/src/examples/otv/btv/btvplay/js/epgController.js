/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('js/epgController',
	[

		'js/epgView',
		'js/epgModel'
	],
	function (EPGView, EPGModel) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgController = (function () {

			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp',
					DEVICE_ID: 14975,
					USE_CLEAR_CONTENT: false
				},
				view = {},
				userId,
				password,
				locale,
				channelLookup = {},
				player,
				videoPlayer,
				videoPath,
				playerCallback,
				DEFAULT_DEVICE = "PC";

/*
 * CALLBACKS
 */
			function dataRefreshListener() {
				var i,
					channels,
					channel = {},
					data = [];

				channels = EPGModel.getAllChannels();

				for (i = 0; i < channels.length; i++) {
					data.push({"title": channels[i].serviceName});
					channelLookup[channels[i].serviceName] = channels[i];
				}
				EPGView.showChannels(data);
			}

			function signonFailureCallback(error) {
				alert("SIGN ON FAILED!!! " + error.response.status || error.response);
			}

			function dataLoadedCallback() {
				EPGModel.refresh();
			}

			function signonSuccessListener() {
				EPGModel.loadIPData(dataLoadedCallback);
			}
/*
 * SIGN ON
 */
			function signon() {
				EPGModel.signon(signonFailureCallback);
			}

			function playoutManagerCallback() {
				EPGModel.initialiseHeadEnd();
				signon();
			}

/*
 * PLAY
 */
			function play(item) {
				EPGModel.playContent(channelLookup[item.title]);
			}

			function setPlayoutManager() {
				EPGModel.setPlayoutManager(EPGView.getPlayer(), playoutManagerCallback);
			}

/*
 * KEY HANDLER
 */
			function keyHandler(key) {
				var keys = EPGModel.getKeyMap();
				switch (key) {
				case keys.KEY_OK:
				case keys.KEY_ONE:
					play(EPGView.getSelectedItem());
					break;
				default:
					EPGView.keyHandler(key);
				}
			}

			function load(xml) {
				EPGModel.initialise(MDS, SDP);
				EPGModel.registerListeners(signonSuccessListener, dataRefreshListener);
				EPGModel.loadGUI(xml, EPGView.getContentElement(), view);
				EPGView.setView(view);
				EPGModel.setKeyInterceptor(function (key) {
					keyHandler(key);
				});
				setPlayoutManager();
			}

			return {
				load: load,
				keyHandler: keyHandler
			};
		}());
		return $N.app.epgController;
	}
);
