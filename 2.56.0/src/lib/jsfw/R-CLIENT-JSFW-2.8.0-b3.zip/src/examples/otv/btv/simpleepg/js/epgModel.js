/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('js/epgModel',
	[
		'jsfw/gui/FrameworkCore',
		'jsfw/apps/core/Log',
		'jsfw/platform/input/BaseKeyMap',
		'jsfw/platform/output/PlayoutManager',
		'jsfw/platform/output/VideoPlayer',
		'jsfw/platform/btv/EPGCache',
		'jsfw/platform/btv/PersistentCache',
		'jsfw/platform/btv/EPG',
		'jsfw/services/sdp/BaseService',
		'jsfw/services/sdp/IPDataLoader',
		'jsfw/services/sdp/EPG',
		'jsfw/services/sdp/MetadataService',
		'jsfw/services/sdp/Signon',
		'jsfw/platform/system/Device'
	],
	function (FrameworkCore, Log, BaseKeyMap, PlayoutManager, VideoPlayer, EPGCache, PersistentCache, BTVEPG, BaseService, IPDataLoader, SDPEPG, MetadataService, Signon, Device) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgModel = (function () {

			var MDS,
				SDP,
				nagraPlayer,
				epgRefreshCallback,
				playerCallback,
				signOnFailedCallback,
				ipDataLoader = {
					forceRamCache: true,
					cacheEvents: false,
					refreshInterval: 12,
					maxDays: 2,
					fetchDuration: 6
				};

/*
 * INITIALISE
 */
			function init(mds, sdp) {

				MDS = mds;
				SDP = sdp;

				$N.apps.core.Log.Config.configure({
					defaultValues: 1,
					moduleLogging: {
						app: 0,
						apps: 1,
						context: 0,
						btv: 1,
						gui: 1,
						sdp: 1
					},
					classLogging: {
						EPG: 1,
						SDP: 1
					}
				});

				$N.platform.btv.EPG.init({
					cacheEvents: ipDataLoader.cacheEvents,
					dataSources: [$N.platform.btv.EPG.DATA_SOURCES.SDP], //[$N.platform.btv.EPG.DATA_SOURCES.SDP] add in for dynamic EPG
					cacheType: ipDataLoader.forceRamCache ? $N.platform.btv.EPG.CACHE_TYPES.RAM : $N.platform.btv.EPG.CACHE_TYPES.Persistent,
					cacheExpiryTime: 60 * 60 * 10000
				});

				$N.platform.btv.PersistentCache.init();
				$N.services.sdp.EPG.init();
			}

			function initialiseHeadEnd() {
				$N.services.sdp.MetadataService.initialise(MDS.URL, MDS.PORT, MDS.PATH, MDS.SERVICE_PROVIDER, MDS.LOCALE);
			}

			function registerListeners(signonSuccessListener, dataRefreshListener) {
				$N.services.sdp.Signon.registerListener(function () {
					signonSuccessListener();
				}, this);

				$N.platform.btv.EPG.registerRefreshCallback(function () {
					dataRefreshListener();
				}, this);
			}

			function loadGUI(xml, content, view) {
				$N.gui.FrameworkCore.loadGUIFromXML(xml, content, view);
			}

			function setKeyInterceptor(callback) {
				$N.apps.core.KeyInterceptor.init(new $N.platform.input.BaseKeyMap(), callback, $N.platform.system.Device.getManufacturer(), $N.platform.system.Device.getModel(), 10);
			}
/*
 * SIGN ON
 */
			function signon(signonFailureCallback) {
				var manufacturer = $N.platform.system.Device.getManufacturer();
				$N.services.sdp.BaseService.initialise(SDP.URL, null, null, null, SDP.PATH, false);
				$N.services.sdp.Signon.init();
				$N.services.sdp.Signon.setSignonFailedCallback(signonFailureCallback);
				if (!manufacturer) { // browser
					//if (SDP.USE_CLEAR_CONTENT) {
						$N.services.sdp.Signon.signonByUserAndDevice(SDP.USER, SDP.PASSWORD, SDP.DEVICE_ID);
					//} else {
					//	$N.services.sdp.Signon.signonAndInitialiseForNMP(SDP.USER, SDP.PASSWORD);
					//}
				} else if (manufacturer === "OpenTV Ref-OS") { //emulator
					$N.services.sdp.Signon.signonByUserAndDevice(SDP.USER, SDP.PASSWORD, SDP.DEVICE_ID);
				} else { //STB
					$N.services.sdp.Signon.signonByUserAndDevice(SDP.USER, SDP.PASSWORD, SDP.DEVICE_ID);
				}
			}

/*
 * GET KEY MAP
 */
			function getKeyMap() {
				return $N.apps.core.KeyInterceptor.getKeyMap();
			}

/*
 * LOAD IP DATA
 */
			function loadIPData(dataLoadedCallback) {
				$N.services.sdp.IPDataLoader.init({
					locale: SDP.LOCALE,
					refreshInterval: ipDataLoader.refreshInterval,
					maxDays: ipDataLoader.maxDays,
					cacheEvents: ipDataLoader.cacheEvents,
					fetchDuration: ipDataLoader.fetchDuration,
					forceRAMCache: ipDataLoader.forceRamCache
				});
				$N.services.sdp.IPDataLoader.setChannelsLoadedCallback(function () {
					setTimeout(function () {  dataLoadedCallback(); }, 1); //wait for refresh to complete
				});
				$N.services.sdp.IPDataLoader.loadIPData();
			}

			function refresh() {
				$N.platform.btv.EPG.refresh();
			}

/*
 * GET ALL CHANNELS
 */
			function getAllChannels() {
				return $N.platform.btv.EPG.getAllChannelsOrderedByChannelNumber();
			}
/*
 * GET EVENTS
 */
			function fetchEventsByWindow(serviceId, startTime, endTime, successCallback) {
				$N.platform.btv.EPG.fetchEventsByWindow([serviceId], startTime, endTime, successCallback);
			}

			function getEventById(eventId) {
				$N.platform.btv.EPG.getEventById(eventId);
			}
/*
 * Public API
 */
			return {
				init: init,
				initialiseHeadEnd: initialiseHeadEnd,
				registerListeners: registerListeners,
				loadGUI: loadGUI,
				setKeyInterceptor: setKeyInterceptor,
				signon: signon,
				getKeyMap: getKeyMap,
				loadIPData: loadIPData,
				getAllChannels: getAllChannels,
				fetchEventsByWindow: fetchEventsByWindow,
				getEventById: getEventById,
				refresh: refresh
			};
		}());
		return $N.app.epgModel;
	}
);