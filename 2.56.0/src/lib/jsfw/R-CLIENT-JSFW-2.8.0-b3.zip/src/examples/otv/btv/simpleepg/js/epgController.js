/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('js/epgController',
	[
		'js/epgView',
		'js/epgModel',
		'js/ChannelItem',
		'js/EventItem'
	],
	function (EPGView, EPGModel, ChannelItem, EventItem) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgController = (function () {

			var	MDS = {
					LOCALE: "en_GB",
					URL: "ott.nagra.com/stable",
					PATH: "/metadata/delivery",
					PORT: "",
					SERVICE_PROVIDER: "B1"
				},
				SDP = {
					LOCALE: "en_gb",
					URL: "ott.nagra.com/stable",
					PATH: '/qsp/gateway/http/js',
					USER: 'nmp@nagra.com',
					PASSWORD: 'nmp',
					DEVICE_ID: "14975"
				},
				view = {},
				keys,
				userId,
				password,
				locale,
				channelLookup = {},
				player,
				videoPlayer,
				videoPath,
				btvRefreshCallback,
				playerCallback,
				DEFAULT_DEVICE = "PC";

/*
 * CALLBACKS
 */
			function dataRefreshListener() {
				EPGView.showChannels(EPGModel.getAllChannels());
			}

			function signonFailureCallback(error) {
				alert("SIGN ON FAILED!!! " + error.response.status || error.response);
			}

			function dataLoadedCallback() {
				EPGModel.refresh();
			}

			function signonSuccessListener() {
				EPGModel.loadIPData(dataLoadedCallback);
			}
/*
 * SIGN ON
 */
			function signon() {
				EPGModel.signon(signonFailureCallback);
			}
/*
 * SHOW EVENTS
 */
			function showEvents(serviceId) {
				var startDate = new Date(),
					endDate = new Date(startDate),
					startTime = new Date(startDate.getTime()),
					endHours = startTime.getHours() + 12,
					endTime = new Date(endDate.setHours(startTime.getHours() + 12)),
					callback = function (events) {
						EPGView.showEvents(events);
					};

				EPGModel.fetchEventsByWindow(serviceId, startTime.getTime(), endTime.getTime(), callback);
			}

			function showEvent(event) {
				if (event) {
					EPGView.showEvent({"eventId": event.eventId, "serviceId": event.serviceId, "title": event.title, "description": event.longDesc});
				} else {
					EPGView.showEvent({result: "No event found"});
				}
			}

/*
 * KEY HANDLER
 */
			function keyHandler(key) {
				switch (key) {
				case keys.KEY_OK:
				case keys.KEY_ONE:
					if (EPGView.isChannelListSelected()) {
						EPGView.showEventContainer(true);
						showEvents(EPGView.getSelectedChannel());
					} else {
						showEvent(EPGView.getSelectedEvent());
					}
					break;
				default:
					EPGView.keyHandler(key);
				}
			}

			function load(xml) {
				EPGModel.init(MDS, SDP);
				EPGModel.loadGUI(xml, EPGView.getContentElement(), view);
				EPGModel.initialiseHeadEnd();
				EPGModel.registerListeners(signonSuccessListener, dataRefreshListener);
				EPGModel.setKeyInterceptor(function (key) {
					keyHandler(key);
				});
				keys = EPGModel.getKeyMap();
				EPGView.init(view, keys);
				signon();
			}

			return {
				load: load,
				keyHandler: keyHandler
			};
		}());
		return $N.app.epgController;
	}
);
