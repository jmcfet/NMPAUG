/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('js/epgView',
	[
		'jsfw/gui/GUIObjects/Components/Video',
		'jsfw/gui/GUIObjects/Components/ClippedGroup',
		'jsfw/gui/GUIObjects/Components/Group',
		'jsfw/gui/GUIObjects/Components/Label',
		'jsfw/gui/GUIObjects/Controls/List/customisable/PivotList',
		'jsfw/gui/GUIObjects/Controls/List/customisable/TextItem'
	],
	function (Video, ClippedGroup, Group, Label, PivotList, TextItem) {

		window.$N = $N || {};
		$N.app = $N.app || {};
		$N.app.epgView = (function () {

			var view = {},
				list = null;

/*
 * SET VIEW
 */
			function setView(inView) {
				view = inView;
			}

/*
 * GETTER METHODS
 */
			function getContentElement() {
				return document.getElementById("content");
			}

			function getPlayer() {
				return document.getElementById("player");
			}

			function getSelectedItem() {
				return list.getSelectedItem();
			}

/*
 * DISPLAY CHANNELS
 */
			function showChannels(data) {
				var dataMapper = {
					getText: function (item) {
						return item.title;
					}
				};
				list = view.container.group.list;
				list.setDataMapper(dataMapper);
				list.setFocusPosition(2);
				list.setWrapAround(false);
				list.init();
				list.setData(data);
				list.displayData();
			}

/*
 * KEY HANDLER
 */
			function keyHandler(key) {
				list.keyHandler(key);
			}

			/*
			 * Public API
			 */
			return {
				setView: setView,
				getContentElement: getContentElement,
				getPlayer: getPlayer,
				getSelectedItem: getSelectedItem,
				showChannels: showChannels,
				keyHandler: keyHandler
			};
		}());
		return $N.app.epgView;
	}
);
