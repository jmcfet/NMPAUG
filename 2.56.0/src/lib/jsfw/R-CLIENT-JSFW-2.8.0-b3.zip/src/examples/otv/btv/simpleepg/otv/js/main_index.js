/*global require*/
window.$N = {};
//window.jQuery = null;
require.config({
    baseUrl : '',
    paths : {
        'jsfw' : '../../jsfw/src',
        'jsfw/services/sdp' : '../../jsfw/src/services/sdp34mds',
        'jsfw/platform': '../../jsfw/src/platform/otv50'
    }
});
require([
	'js/epgController'
	],
	function (Controller) {
		Controller.load('otv/xml/epg.xml');
	}
);