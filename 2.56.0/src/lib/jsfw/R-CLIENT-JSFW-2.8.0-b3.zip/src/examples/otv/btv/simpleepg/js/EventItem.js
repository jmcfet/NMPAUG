/**
 * EventItem is a concrete implementation of AbstractListItem and
 * represents a list item object containing a graphic and text
 * stacked in vertical formation.
 * @constructor
 * @param {Object} docRef (DOM document)
 */
define('js/EventItem',
	[
		'jsfw/gui/helpers/Util',
		'jsfw/gui/GUIObjects/Controls/List/customisable/AbstractListItem',
		'jsfw/gui/GUIObjects/Components/Group',
		'jsfw/gui/GUIObjects/Components/Label'
	],
	function (Util, AbstractListItem, Group, Label) {
		function EventItem(docRef) {
			var me = this;

			EventItem.superConstructor.call(this, docRef);

			this._container = new Group(docRef);
			this._title = new Label(docRef, this._container);

			this._isEnabled = true;
			this._container.configure({
				height: 25,
				width: 120
			});
			this._title.configure({
				y: 2,
				x: 10,
				width: 120
			});
			this._rootSVGRef = this._container.getRootSVGRef();
			this.addMoveAnimation();
		}

		Util.extend(EventItem, AbstractListItem);

		EventItem.prototype.highlight = function () {
			this._container.setCssClass("highlightedContainer");
		};

		EventItem.prototype.unHighlight = function () {
			this._container.setCssClass("unHighlightedContainer");
		};

		/**
		 *
		 * @param {Object} data
		 */
		EventItem.prototype.update = function (data) {
			var me = this;
			//this._container.setCssClass("unHighlightedContainer");
			if (data) {
				this._title.setText(this._dataMapper.getText(data));
			}
		};
		window.$N = $N || {};
		$N.gui = $N.gui || {};
		$N.gui.EventItem = EventItem;
		return $N.gui.EventItem;
	}
);
