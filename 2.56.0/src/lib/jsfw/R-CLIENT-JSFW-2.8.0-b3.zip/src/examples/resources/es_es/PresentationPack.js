function PresentationPack() {

	this.button_style_a = {
		x: 410,
		y: 200,
		width: 200,
		height: 210,
		cssClass: "buttonEs",
		highlightCssClass: "buttonEsHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 20,
		image: "resources/images/announce_32.png",
		imageTop: 84,
		imageLeft: 84
	};

	this.button_style_b = {
		x: 200,
		y: 310,
		width: 200,
		height: 100,
		cssClass: "buttonEs",
		highlightCssClass: "buttonEsHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 20,
		label: "Hola Espana"
	};

	this.button_style_c = {
		x: 200,
		y: 200,
		width: 200,
		height: 100,
		cssClass: "buttonEs",
		highlightCssClass: "buttonUkHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 20,
		label: "Usuario Espanol",
		labelTop: 85,
		image: "resources/images/user_48.png",
		imageLeft: 84,
		imageTop: 16
	};

	this.label_title = {
		x: 200,
		y: 100,
		fontSize: 35,
		alignment: "left"
	};

}
