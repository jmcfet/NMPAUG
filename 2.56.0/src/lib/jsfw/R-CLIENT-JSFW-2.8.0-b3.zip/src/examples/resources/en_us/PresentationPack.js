function PresentationPack() {

	this.button_style_a = {
		x: 310,
		y: 200,
		width: 100,
		height: 100,
		cssClass: "buttonUs",
		highlightCssClass: "buttonUsHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 5,
		image: "resources/images/search_32.png",
		imageTop: 34,
		imageLeft: 34
	};

	this.button_style_b = {
		x: 200,
		y: 310,
		width: 210,
		height: 100,
		cssClass: "buttonUs",
		highlightCssClass: "buttonUsHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 5,
		label: "Hello USA"
	};

	this.button_style_c = {
		x: 200,
		y: 200,
		width: 100,
		height: 100,
		cssClass: "buttonUs",
		highlightCssClass: "buttonUsHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 5,
		label: "USA User",
		labelTop: 85,
		image: "resources/images/user_48.png",
		imageLeft: 26,
		imageTop: 16
	};

	this.label_title = {
		x: 200,
		y: 100,
		fontSize: 20,
		alignment: "left"
	};

}
