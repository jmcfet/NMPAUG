function PresentationPack() {

	this.button_style_a = {
		x: 620,
		y: 200,
		width: 100,
		height: 100,
		cssClass: "buttonUk",
		highlightCssClass: "buttonUkHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 10,
		image: "resources/images/home_32.png",
		imageTop: 34,
		imageLeft: 34
	};

	this.button_style_b = {
		x: 310,
		y: 200,
		width: 300,
		height: 100,
		cssClass: "buttonUk",
		highlightCssClass: "buttonUkHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 10,
		label: "Hello UK"
	};

	this.button_style_c = {
		x: 200,
		y: 200,
		width: 100,
		height: 100,
		cssClass: "buttonUk",
		highlightCssClass: "buttonUkHighlight",
		labelCssClass: "buttonLabel",
		labelHighlightCssClass: "buttonLabelHighlight",
		rounding: 10,
		label: "UK User",
		labelTop: 85,
		image: "resources/images/user_48.png",
		imageLeft: 26,
		imageTop: 16
	};

	this.label_title = {
		x: 200,
		y: 100,
		fontSize: 30,
		alignment: "left"
	};

}
