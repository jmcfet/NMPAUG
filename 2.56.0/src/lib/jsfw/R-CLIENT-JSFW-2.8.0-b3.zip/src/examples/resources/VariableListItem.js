/**
 * VariableListItem
 *
 * Data Mapper Requirements;
 *    {String} getTitle
 *
 * @constructor
 * @param {Object} docRef (DOM document)
 */

var $N = $N || window.parent.$N;

function VariableListItem(docRef) {
	VariableListItem.superConstructor.call(this, docRef);

	this._container = new $N.gui.Container(docRef);
	this._title = new $N.gui.Label(docRef, this._container);

	this._container.configure({
		x: 10,
		y: 3,
		cssClass: "variableListItemContainer"
	});

	this._title.configure({
		x: 10,
		y: 20,
		cssClass: "variableListItemText"
	});

	this._rootSVGRef = this._container.getRootSVGRef();

	this.addMoveAnimation(docRef);
	this.addFadeAnimation(docRef);
	this.addScaleAnimation(docRef);
}

$N.apps.util.Util.extend(VariableListItem, $N.gui.AbstractListItem);

/**
 * Highlights the item .
 * @method highlight
 *
 */

VariableListItem.prototype.highlight = function () {
};

/**
 * Unhighlights the item .
 * @method unHighlight
 *
 */
VariableListItem.prototype.unHighlight = function () {
	this._moveAnim.setAnimationEndCallback(null);
};

/**
 * Sets the item width.
 * @method setWidth
 * @param  width
 *
 */
VariableListItem.prototype.setWidth = function (width) {
	this._width = width;
	this._container.setWidth(width);
};

/**
 * Gets the item width.
 * @method getWidth
 *
 */
VariableListItem.prototype.getWidth = function () {
	return this._width;
};

/**
 * Enable item.
 * @method enable
 */
VariableListItem.prototype.enable = function () {
	this._title.setCssClass("variableListItemText");

};

/**
 * Disable item.
 * @method disable
 */
VariableListItem.prototype.disable = function () {
	this._title.setCssClass("variableListItemTextDisable");
};

/**
 * Updates item
 * @method update
 * @param  data
 *
 */
VariableListItem.prototype.update = function (data) {
	var title;
	if (data) {
		title = this._dataMapper.getTitle(data);
		this._title.setText(title);
		this._id = title;
		this.setWidth(this._title.getTrueTextLength() + this._title.getFontSize());
	}
};