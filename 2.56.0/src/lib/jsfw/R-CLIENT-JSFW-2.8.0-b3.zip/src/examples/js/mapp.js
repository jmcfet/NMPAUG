var MAPP = {
	editors: {}
};

function _getQueryParameter(variable)
{
	var query = window.location.search.substring(1),
	    vars = query.split("&");
	for (var i=0;i<vars.length;i++) {
		var pair = vars[i].split("=");
		if(pair[0] == variable) {
			return pair[1];
		}
	}
	return false;
}

function initialiseCodeMirror() {
	// Initialise CodeMirror on each of the textareas
	$('textarea').each(function() {
		var mode = $(this).attr('lang');
		MAPP.editors[mode] = CodeMirror.fromTextArea(this, {
			theme: 'monokai',
			mode: mode,
			onChange: function() {
				updateTextAreas();
			}
		});
	});
}

function getContents(url) {
	return $.ajax({url: url, dataType: 'text'});
}

initialiseCodeMirror();

if(_getQueryParameter('snippet')) {
	var snippetId = _getQueryParameter('snippet');
	$.when(getContents("snippets/" + snippetId + '/snippet.js'),
	       getContents("snippets/" + snippetId + '/snippet.css'),
	       getContents("snippets/" + snippetId + '/snippet.html')).then(function(js, css, html) {
		MAPP.editors.javascript.setValue(js[0]);
		MAPP.editors.css.setValue(css[0]);
		MAPP.editors.htmlmixed.setValue(html[0]);
		updateTextAreas();
		insertHtml();
	}, function(err) {
		console.log(err);
	});
}

// Copy the editors into the hidden textareas
function updateTextAreas() {
	MAPP.editors.htmlmixed.save();
	MAPP.editors.javascript.save();
	MAPP.editors.css.save();
}

// A really handy plugin by Michael Mahemoff
// http://mini.softwareas.com/jquery-iframe-inject-mini-plugin
$.fn.inject = function(content) {
	return $(this).filter("iframe").each(function() {
		var doc = this.contentDocument || this.document || this.contentWindow.document;
		doc.open();
		doc.writeln(content);
		doc.close();
	});
};

// Combine the HTML, CSS and JS into a single file
// to display in the output frame


function insertHtml() {
	var outputHtml = MAPP.editors.htmlmixed.getTextArea().value,
		outputCss = MAPP.editors.css.getTextArea().value,
		outputScript = MAPP.editors.javascript.getTextArea().value,
		outputFrame = $('#output iframe');

	$('#output').append(outputFrame);

	outputFrame.inject(outputHtml.replace('</body>', '<script>' + outputScript + '</script></body>'));
	MAPP.contents = outputFrame.contents();

	MAPP.styleTag = $('<style/>').attr('id', 'our_css').appendTo(MAPP.contents.find('head'));
	MAPP.styleTag.text(MAPP.editors.css.getTextArea().value);
}

// Initialise the page.
(function() {
	updateTextAreas();
})();

// Toggle visibility of the HTML/CSS tabs.
$('#show-other').on('click', function(e) {
	e.preventDefault();
	$('body').toggleClass('show-other');
});

// Switch between full and compact (tabbed) mode
$(window).on('resize', function() {
	if($(window).width() >= 1010) {
		$('.code-tab').show();
	} else {
		$('.code-tab').hide();
		$('#output').show();
	}
});

// Show/hide tabs when we're in compact mode
$('#single-panel a').on('click', function(e) {
	e.preventDefault();
	target = $(this).attr('href');
	$('.code-tab').hide();
	$(target).show();
	if((target === "#css") || (target === "#html")) {
		$('#other').show();
	}
});

$('#run-button').on('click', function(e) {
	e.preventDefault();
	insertHtml();
});
