/**
 * This class has been deprecated. Please use $N.apps.core.Log.Config
 *
 * @class $N.apps.core.LogConfig
 * @deprecated use $N.apps.core.Log.Config
 * @author gstacey
 * @singleton
 */

define('jsfw/apps/core/LogConfig',
	[],
	function () {}
);
