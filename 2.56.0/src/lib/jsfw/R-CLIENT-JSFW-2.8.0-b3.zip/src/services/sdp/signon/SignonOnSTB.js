/*global define, $N, window */

define('jsfw/services/services/sdp/SignonOnSTB',
	[
		'jsfw/apps/core/Log'
	],
	function (Log) {

		function SignonOnSTB(signonService, initialInterval, maximumRetries, backoffValue) {
			this._log = new $N.apps.core.Log("sdp.signon", "SignonOnSTB");
			SignonOnSTB.superConstructor.call(this, signonService, initialInterval, maximumRetries, backoffValue);
		}

		$N.apps.util.Util.extend(SignonOnSTB, $N.services.sdp.signon.AbstractSignon);

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.SignonOnSTB = SignonOnSTB;
		return SignonOnSTB;
	});