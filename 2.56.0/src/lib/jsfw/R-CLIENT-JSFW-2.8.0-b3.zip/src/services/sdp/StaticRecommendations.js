/**
 * StaticRecommendations class is used to offer an API to return static and dynamic recommendation
 * results
 * @class $N.services.sdp.StaticRecommendations
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.MetadataService
 * @singleton
 */
/* global define */

define('jsfw/services/sdp/StaticRecommendations',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/MetadataService'
	],
	function (Log, MetadataService) {
		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};

		$N.services.sdp.StaticRecommendations = (function () {
			var EPG_EVENTS_URI = $N.services.sdp.MetadataService.RequestType.Events,
				VOD_EDITORIALS_URI = $N.services.sdp.MetadataService.RequestType.Assets,

				log = new $N.apps.core.Log("sdp", "StaticRecommendations"),

				_sortArrayByRank = function(a,b) {
					return (a.rank > b.rank) ? -1 : (a.rank < b.rank) ? 1 : 0;
				},
				_stripRank = function (assetList) {
					var n,s,l,i,rank,rankList=[], rankObj;
					if (!assetList) { return; }
					l = assetList.length;
					for (i = 0; i<l; i++) {
						rankObj= {};
					    s = assetList[i];
					    n = s.indexOf('/');
					    rank = s.substring(n+1, s.length);
					    assetList[i] = s.substring(0, n != -1 ? n : s.length);
					    rankObj["id"] = assetList[i];
					    rankObj["rank"] = parseInt(rank,10);
					    rankList.push(rankObj);
					}
					return rankList;
				},

				/**
				 * Returns static recommendations from a Media item
				 * @method getStaticRecommendations
				 * @param {Object} 	content - the Media item object: Asset if VOD, Event if BTV
				 * @param {String} 	type (of content) - VOD or BTVEVENT
				 * @param {Array} 	filter - string array of name-value pairs in ["key1: value1", "key2: value2"] format
				 * @param {Object} 	fieldList - Fields to return, passed to MDS getData
				 * @param {Object} 	successCallback
				 * @param {Object} 	failureCallback
				 * @private
				 */
				getStaticRecommendations =  function (content, type, filter, fieldList, successCallback, failureCallback) {
					var results = {}, CDGconfig = {},

						vodSuccessCallback = function (data) {
							var i, sortedEditorials = [], tempObj, found,
								findEditorial = function (id) {
									var len,i,j,k,l,productLength,technicalLength,vodItemLength;
									len = data.editorials.length;
									for (i=0; i<len;i++) {
										technicalLength = (data.editorials[i].technicals) ? data.editorials[i].technicals.length : 0;
										for (j = 0; j< technicalLength; j++) {
											productLength = (data.editorials[i].technicals[j].products) ? data.editorials[i].technicals[j].products.length : 0;
											for (k = 0; k< productLength; k++) {
												vodItemLength = (data.editorials[i].technicals[j].products[k].voditems) ? data.editorials[i].technicals[j].products[k].voditems.length : 0;
												for (l = 0; l< vodItemLength; l++) {
													if (id === data.editorials[i].technicals[j].products[k].voditems[l].id) {
														return i; //found it
													}
												}
											}
										}
									}
								};

							// Sort Recommendations from Editorial loaded in media card by rank
							// If that recommendation is found in the editorials we have from MDS, add it to the new array with it's ranking

							if (!data) {return -1;}
							if (!data.editorials) {return -1;}
							if (data.editorials.length === 0) {return -1;} //i.e. Bad data recommendations on asset returned no hits from MDS

							CDGconfig.editorialsRanking.sort(_sortArrayByRank); //Higher the rank - the more recommended. Put the highest at the front.

							for (i = 0; i < CDGconfig.editorialsCount; i++) {
								found = findEditorial(CDGconfig.editorialsRanking[i].id);
								if (found >= 0) {
									tempObj = {};
									tempObj.rank = CDGconfig.editorialsRanking[i].rank;
									tempObj.dataObject = data.editorials.splice(found,1)[0];
									sortedEditorials.push(tempObj);
								}
							}
							results.editorials = sortedEditorials;

							if (successCallback) {
								return (successCallback(results));
							}
						},

						btvSuccessCallback = function (data) {
							var findProgramme = function (id) {
									var len,i,j,k,l;

									len = data.length;

									for (i=0; i<len;i++) {
										if (id === data[i].id) {
											return i; //found it
										}
									}
								}, sortedProgrammes = [], tempObj, found;

							if (data) {
								if (data.length > 0) { //i.e. MDS actually returned data from the recommendations we gave it. (read:could be bad data)
									CDGconfig.programmeRanking.sort(_sortArrayByRank);

									for (i = 0; i < CDGconfig.programmeCount; i++) {
										found = findProgramme(CDGconfig.programmeRanking[i].id);
										if (found >= 0) {
											tempObj = {};
											tempObj.rank = CDGconfig.programmeRanking[i].rank;
											tempObj.dataObject = data.splice(found,1)[0];
											sortedProgrammes.push(tempObj);
										}
									}
									results.programmes = sortedProgrammes;
								}
							}

							if (CDGconfig.editorialsFilter) {
								$N.services.sdp.MetadataService.getData (
									this,
									vodSuccessCallback.bind(this),
									failCallback.bind(this),
									VOD_EDITORIALS_URI,
									CDGconfig.editorialsFilter, [], fieldList, CDGconfig.editorialsCount, 0);
							} else {
								if (successCallback) {
									return (successCallback(results));
								}
							}
						},

						failCallback = function (data) {
							if (failureCallback) {
								return (failureCallback(data));
							}
						},

						_getStaticVODRecommendations = function (asset) {
							var recommendations = {}, ids;
							if (asset.technicals && asset.technicals[0]) {
								if (asset.technicals[0].products && asset.technicals[0].products[0]) {
									if (asset.technicals[0].products[0].voditems && asset.technicals[0].products[0].voditems[0] ) {
										if (asset.technicals[0].products[0].voditems[0].RecommendedVodItemIds) {
											//as we're chopping up the strings in the array, lets work on a clone so the cached original values are preserved - reentering media card causes issues
											ids = asset.technicals[0].products[0].voditems[0].RecommendedVodItemIds.slice(0);
											recommendations.editorialsRanking = _stripRank(ids);
											recommendations.editorialsFilter = (filter !== null && typeof filter === 'object') ? filter : {}; //this should = filter or empty object {}
											recommendations.editorialsFilter["voditem.id"] =  {"$in" : ids}; //augment or add new property
											recommendations.editorialsCount = ids.length;
											return recommendations;
										}
									}
								}
							}
							return false;
						},

						_getStaticBTVRecommendations = function (asset) {
							var recommendations = {}, vodids, btvids;
							if (asset && asset._data) {
								if (asset._data.RecommendedProgrammeIds) {
									btvids = asset._data.RecommendedProgrammeIds.slice(0);
									recommendations.programmeRanking = _stripRank(btvids);
									recommendations.programmeFilter = (filter !== null && typeof filter === 'object') ? JSON.parse(JSON.stringify(filter)) : {};
									recommendations.programmeFilter["id"] = {"$in" : btvids};
									recommendations.programmeCount = btvids.length;
								}
								if (asset._data.RecommendedVodItemIds) {
									vodids = asset._data.RecommendedVodItemIds.slice(0);
									recommendations.editorialsRanking = _stripRank(vodids);
									recommendations.editorialsFilter = (filter !== null && typeof filter === 'object') ? JSON.parse(JSON.stringify(filter)) : {};
									recommendations.editorialsFilter["voditem.id"] =  {"$in" : vodids};
									recommendations.editorialsCount = vodids.length;
								}
								if (recommendations.editorialsCount || recommendations.programmeCount) {
									return recommendations;
								}
							}
							return false;
						}, servicesArray, key;

					// Get recommendations

					if (type.name === 'VOD') {
						CDGconfig = _getStaticVODRecommendations(content);
						if (!CDGconfig) { return (failCallback()); }

						$N.services.sdp.MetadataService.getData (this,
							vodSuccessCallback.bind(this),
							failCallback.bind(this),
							VOD_EDITORIALS_URI,
							CDGconfig.editorialsFilter, [], fieldList, CDGconfig.editorialsCount, 0
						);
					} else {
						CDGconfig = _getStaticBTVRecommendations(content);
						if (!CDGconfig) { return (failCallback()); }
						
						$N.services.sdp.MetadataService.getEPGData(this, function (response) {
							if (response && response.programmes) {
								btvSuccessCallback(response.programmes);
							} else {
								btvSuccessCallback(null);
							}
						}, 
						failCallback.bind(this),
						$N.services.sdp.MetadataService.RequestType.Events, CDGconfig.programmeFilter,
						[],
						fieldList,
						CDGconfig.programmeCount,
						0);
					}
				};

			return {
				 getStaticRecommendations : getStaticRecommendations
			};
		}());
		return $N.services.sdp.StaticRecommendations;
	});