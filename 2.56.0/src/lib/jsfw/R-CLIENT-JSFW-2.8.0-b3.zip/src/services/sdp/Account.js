/*global require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
define('jsfw/services/sdp/Account',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/ServiceFactory'
	],
	function (Log, ServiceFactory) {

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.Account = (function () {

			var contextDetails,
			 _refreshAccountDetails = function(callback) {
				var me = this,
					successCallback = function (context) {
						contextDetails = context;
						if (callback) {
							callback(contextDetails);
						}
					},
					failureCallback = function (failure) {
						contextDetails = {error: failure};
						if (callback) {
							callback(contextDetails);
						}
					};
				$N.services.sdp.ServiceFactory.get("ContextService").getCurrentContext(this, successCallback, failureCallback);
			};

			function refreshAccountDetails() {
				_refreshAccountDetails();
			}

			function getAccountDetails() {
				return contextDetails;
			}

			function fetchAccountDetails(callback) {
				_refreshAccountDetails(callback);
			}

			function getAccountNumber() {
				return contextDetails.accountNumber;
			}

			function getUserUid() {
				return contextDetails.userUid;
			}



			/*
			 * Public API
			 */
			return {
				refreshAccountDetails: refreshAccountDetails,
				getAccountDetails: getAccountDetails,
				getUserUid: getUserUid,
				fetchAccountDetails: fetchAccountDetails,
				getAccountNumber: getAccountNumber
			};
	}());
	return $N.services.sdp.Account;
});

