/*global define, $N, window, drmAgent */
/**
 * Abstract sign on class that is inherited by SignonOnBrowser and SignonOnHandheld
 * Contains common NMP-specific signon functions
 * @class $N.services.sdp.signon.AbstractSignonOnNMP
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.signon.AbstractSignon
 */
define('jsfw/services/sdp/signon/AbstractSignonOnNMP',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/signon/AbstractSignon',
		'jsfw/services/multidrm/UpgradeManager'
	],
	function (Log, AbstractSignOn, UpgradeManager) {

		function AbstractSignonOnNMP(initialInterval, maximumRetries, backoffValue) {
			this._log = new $N.apps.core.Log("sdp.signon", "AbstractSignonOnNMP");
			this.platform = null;
			this.deviceinitializedResponse = null;
			this.signonProperties = {};
			this.upgradeManagerService = null;
			this.upgradeManager = null;
			this.upgradeRecommended = false;
			this.upgradeData = {};
			this.serverPrivateData = null;
			AbstractSignonOnNMP.superConstructor.call(this, initialInterval, maximumRetries, backoffValue);
		}

		$N.apps.util.Util.extend(AbstractSignonOnNMP, $N.services.sdp.signon.AbstractSignon);

		AbstractSignonOnNMP.prototype.setPlayerUpgradeRecommended = function (data) {
			this.upgradeRecommended = true;
			this.upgradeData = data;
		};

		AbstractSignonOnNMP.prototype.setDeviceId = function (deviceId) {
			this.signonProperties.deviceId = deviceId;
			$N.env.deviceId = deviceId;
		};

		AbstractSignonOnNMP.prototype.setDeviceName = function (successCallback, failureCallback) {
			$N.services.sdp.Signon.setDeviceNameForNMPId(this.signonProperties.deviceId, this.signonProperties.deviceName,
				successCallback, failureCallback);
		};

		AbstractSignonOnNMP.prototype.setSignonSuccess = function (token) {
			this._log("setSignonSuccess", "Enter");
			this.setToken(token);
			this.state = $N.services.sdp.Signon.STATE_SIGNED_ON;
			this._log("setSignonSuccess", "Enter");
		};

		AbstractSignonOnNMP.prototype.setSignonProperties = function (signonProperties) {
			this._log("setSignonProperties", "Enter " + JSON.stringify(signonProperties));
			this.signonProperties = signonProperties;
		};

		AbstractSignonOnNMP.prototype.setUpgradeManagerService = function (upgradeManagerService) {
			this._log("setUpgradeManagerService", "Enter ");
			this.upgradeManagerService = upgradeManagerService;
			this.upgradeManager = new $N.services.multidrm.UpgradeManager(upgradeManagerService);
		};

		AbstractSignonOnNMP.prototype.getDrmAgentState = function () {
			return this.signonProperties.state;
		};

		AbstractSignonOnNMP.prototype.getDeviceName = function () {
			return this.signonProperties.deviceName;
		};

		AbstractSignonOnNMP.prototype.signonOrInitializationForNMPFailure = function (failType, result) {
			this._log("signonOrInitializationForNMPFailure", "Signed In Failed: " + result, "warn");
			switch (failType) {
			case $N.services.sdp.Signon.UPGRADE_MANGER_SERVICE_NOT_PROVIDED:
				this.authToken = null;
				break;
			case $N.services.sdp.Signon.ERROR.SIGNON_BY_USER:
			case $N.services.sdp.Signon.ERROR.SIGNON_BY_USER_DEVICE_ID:
			case $N.services.sdp.Signon.ERROR.MAXIMUM_DEVICES_REACHED:
			case $N.services.sdp.Signon.ERROR.DEVICE_LIMIT_REACHED:
			case $N.services.sdp.Signon.ERROR.DEVICE_CLASS_LIMIT_REACHED:
			case $N.services.sdp.Signon.ERROR.DEVICE_ACTIVATION_LIMIT_REACHED:
				this.authToken = null;
				// if the reason for failure is invalid UID / Password combo then don't retry
				if (typeof result === "String" && result.indexOf("code=23017") === -1) {
					this.setFailedSignonToPending($N.services.sdp.Signon.signonByUserAndDevice, this.signonParameters);
				} else {
					this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
				}
			}
			if (this.signonFailedCallback) {
				this.signonFailedCallback({
					response: result,
					failure: failType
				});
			}
			this._log("signonOrInitializationForNMPFailure", "Exit");
		};

		AbstractSignonOnNMP.prototype.applyListeners = function () {
			this._log("applyListeners", "Enter");
			var param = [];
			if (this.upgradeRecommended) {
				param.push({upgradeRecommended: true, upgradeData : this.upgradeData});
			}
			$N.services.sdp.signon.AbstractSignon.prototype.applyListeners.call(this, param);
			this._log("applyListeners", "Exit");
		};

		AbstractSignonOnNMP.prototype.setDeviceNamedFailedCallback = function(result) {
			this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.SET_DEVICE_NAME, result);
		};

		AbstractSignonOnNMP.prototype.signedOnByUserAndDeviceFailedCallback = function(result) {
			if (this.isConnectionError(result)) {
				this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.SERVER_CONNECTION, result);
			} else {
				this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.SIGNON_BY_USER_DEVICE_ID, result);
			}
		};

		AbstractSignonOnNMP.prototype.signedOnByUserFailedCallback = function(result) {
			this._log("signedOnByUserFailedCallback", "Signed In Failed: " + result, "warn");
			if (this.isConnectionError(result)) {
				this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.SERVER_CONNECTION, result);
			} else {
				this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.SIGNON_BY_USER, result);
			}
		};

		AbstractSignonOnNMP.prototype.reportFailureStatus = function(data) {
			this._log("reportFailureStatus", "Initialization Failed: ");
			if (data) {
				switch (data.status) {
				case "MAXIMUM_DEVICE_PER_ACCOUNT_REACHED":
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.MAXIMUM_DEVICES_REACHED, data);
					break;
				case "PLAYER_UPGRADE_REQUIRED":
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.PLAYER_UPGRADE_REQUIRED, data);
					break;
				case "DEVICE_LIMIT_REACHED":
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.DEVICE_LIMIT_REACHED, data);
					break;
				case "DEVICE_CLASS_LIMIT_REACHED":
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.DEVICE_CLASS_LIMIT_REACHED, data);
					break;
				case "DEVICE_ACTIVATION_LIMIT_REACHED":
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.DEVICE_ACTIVATION_LIMIT_REACHED, data);
					break;
				default:
					this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.INITIALIZE_DEVICE, data);
				}
			} else {
				this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.UPGRADE_MANGER_SERVICE_NOT_PROVIDED, "Failed to call upgrade manager");
			}
		};

		AbstractSignonOnNMP.prototype.signonByUserAndDevice = function (userID, password, successCallback, failureCallback) {
			this._log("signonByUserAndDevice", "Enter - device id: " + $N.env.deviceId);
			if (userID && password && $N.env.deviceId) {
				if (this.state !== $N.services.sdp.Signon.STATE_SIGNING_ON) {
					this._log("signonByUserAndDevice", "userID: " + userID);
					this.signonParameters = [];
					this.signonParameters[0] = userID;
					this.signonParameters[1] = password;
					this.signonParameters[2] = $N.env.deviceId;
					this.state = $N.services.sdp.Signon.STATE_SIGNING_ON;
					this.signonService.signonByMpDeviceIdAndUser(this, successCallback, failureCallback,
																$N.env.deviceId, userID, password);
				} else {
					this._log("signonByUserAndDevice", "signon request ignored - already attempting signon.");
				}
			} else {
				this._log("signonByUserAndDevice", "No user id, password or device id.", "error");
			}
			this._log("signonByUserAndDevice", "Exit");
		};

		AbstractSignonOnNMP.prototype.silentInitialize = function () {
			this._log("silentInitialize", "Enter");
			drmAgent.silentInitialize(this.signonProperties.directModeURL, this.getToken(), this.signonProperties.serverPrivateData || "");
		};

		AbstractSignonOnNMP.prototype.initialiseDRMAgent = function (data) {
			this._log("initialiseDRMAgent", "Enter ");
			this.deviceInitialisedResponse = data;
			drmAgent.initialize(this.deviceInitialisedResponse.response);
			this._log("initialiseDRMAgent", "Exit");
		};

		AbstractSignonOnNMP.prototype.initializeFailureCallback = function (result) {
			this._log("initializeFailureCallback", "Enter");
			this.signonOrInitializationForNMPFailure($N.services.sdp.Signon.ERROR.INITIALIZE_DEVICE, result);
			this._log("initializeFailureCallback", "Exit");
		};

		AbstractSignonOnNMP.prototype.initialize = function (successCallback, failureCallback) {
			this._log("initialize", "Enter " + this.signonProperties.initializationPayload);
			$N.services.sdp.ServiceFactory.get("NmpExtendedService").initializeDevice(this, successCallback,
						failureCallback,  $N.env.playerVersion, $N.env.playerType, this.signonProperties.initializationPayload);
			this._log("initialize", "Exit");
		};

		AbstractSignonOnNMP.prototype.isWhiteboxCryptoError = function () {
			this._log("isWhiteboxCryptoError", "Enter");
			if (this.signonProperties.lastCommunicationStatus === this.TDRM_LAST_COMMUNICATION_STATUS.WHITEBOX_CRYPTO_ERROR ||
				this.signonProperties.lastCommunicationStatus === this.TDRM_LAST_COMMUNICATION_STATUS.UNDEFINED_DEVICE) {
				return true;
			} else {
				return false;
			}
		};

		AbstractSignonOnNMP.prototype.doSignonByUserAndDevice = function (successCallback, failureCallback) {
			this._log("doSignonByUserAndDevice", "Enter");
			this.signonByUserAndDevice(this.signonProperties.username, this.signonProperties.password, successCallback, failureCallback);
			this._log("doSignonByUserAndDevice", "Exit");
		};

		AbstractSignonOnNMP.prototype.doSignonByUser = function (successCallback, failureCallback) {
			this._log("doSignonByUser", "Enter");
			this.signonByUser(this.signonProperties.username, this.signonProperties.password, successCallback, failureCallback);
			this._log("doSignonByUser", "Exit");
		};

		AbstractSignonOnNMP.prototype.checkForUpgrade = function (successCallback, failureCallback) {
			var response = {};
			if (this.upgradeManagerService) {
				this.upgradeManager.checkForUpgrade(successCallback, failureCallback, this.getToken());
			} else {
				response.errorCode = "-1";
				response.errorMessage = "upgradeManagerService object not provided";
				this._log("checkForUpgrade", response.errorMessage);
				response.status = "NO UPGRADE MANAGER SERVICE";
				successCallback(response);
			}
		};

		AbstractSignonOnNMP.prototype.TDRM_STATE = {
		    STATE_READY : 0,/**< Pak is ready to be used for descrambling */
		    STATE_INITIALIZING : 50,
		    STATE_INITIALIZATION_REQUIRED : 100,/**< Pak must be initialized with data from server */
		    STATE_FATAL_ERROR : 200,/**< Pak is in fatal error mode and must be released */
		    STATE_FATAL_ERROR_OPERATOR : 201/**< Pak is in error mode and must be deleted. Error comes from incoherent operator data given on construction */
		};

		AbstractSignonOnNMP.prototype.TDRM_LAST_COMMUNICATION_STATUS = {
		    OK : 0,
		    WHITEBOX_CRYPTO_ERROR : 210,
		    UNDEFINED_DEVICE : 214
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.AbstractSignonOnNMP = AbstractSignonOnNMP;
		return AbstractSignonOnNMP;
	});
