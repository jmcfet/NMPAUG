/**
 * Search class is used to offer an API to return aggregated search
 * results from MDS.
 * @class $N.services.sdp.Search
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.MetadataService
 * @requires $N.services.sdp.VOD
 * @requires $N.services.sdp.EPG
 * @author nthorne
 * @constructor
 */
/* global define */
define('jsfw/services/sdp/Search',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/MetadataService',
		'jsfw/services/sdp/VOD',
		'jsfw/services/sdp/EPG'
	],

	function (Log, MetadataService, VOD, EPG) {

		var log = new $N.apps.core.Log("sdp", "Search"),
			MAX_NON_PAGING_RESULTS = 100;

		function Search() {
			var services,
				me = this;
			this._successCallback = function () {};
			this._failureCallback = function () {};
			this._objectIds = [];
			this._eventIds = [];
			this._assetIds = [];
			this._numberOfObjectsFound = 0;
			this._highlighting = {};
			this._assets = [];
			this._servicesLookup = {};
		}

		/*
		 * PRIVATE HELPER METHODS
		 */
		Search.prototype._getMatchesById = function (id, highlighting) {
			var locale = $N.services.sdp.MetadataService.getLocale();
			return highlighting[id + "|" + locale];
		};

		Search.prototype._fetchEventsByIds = function (ids, filter, successCallback, failureCallback) {
			var me = this,
				key = "serviceId",
				i,
				len;

			if (!filter) {
				filter = {};
			}
			filter.id = {"$in": ids};
			$N.services.sdp.EPG.getAllChannels(function(services) {
				for (i = 0, len = services.length; i < len; i++) {
					me._servicesLookup[services[i][key]] = services[i];
				}

				$N.services.sdp.MetadataService.getEPGData(this, function (response) {
					if (response && response.programmes) {
						successCallback($N.services.sdp.EPGEventFactory.mapArray(response.programmes, me._servicesLookup));
					} else {
						successCallback(null);
					}
				}, function () {
					failureCallback(null);
				}, $N.services.sdp.MetadataService.RequestType.Events, filter, null, null, ids.length, null);
			} ,failureCallback);
		};

		Search.prototype._sortResults = function (assets, events) {
			var mongoLookup = {},
				sortedResponseArray = [],
				responseObject = {},
				length,
				currentResult,
				i;

			if (assets && assets.editorials) {
				for (i = 0, length = assets.editorials.length; i < length; i++) {
					mongoLookup[assets.editorials[i].id] = assets.editorials[i];
				}
			}
			if (events) {
				for (i = 0, length = events.length; i < length; i++) {
					mongoLookup[events[i].eventId] = events[i];
				}
			}
			for (i = 0, length = this._objectIds.length; i < length; i++) {
				currentResult = mongoLookup[this._objectIds[i]];
				if (currentResult) {
					sortedResponseArray.push(currentResult);
				}
			}
			responseObject.totalRecords = this._numberOfObjectsFound;
			responseObject.records = sortedResponseArray;
			responseObject.highlighting = this._highlighting || null;
			this._successCallback(responseObject);
		};

		Search.prototype._getData = function () {
			var me1 = this,
				getVODCallback = function (assets) {
					var me2 = me1,
						getEPGCallback = function (events) {
							me2._sortResults(me2._assets, events);
						};
					me1._assets = assets;
					me1._fetchEventsByIds(me1._eventIds, null, getEPGCallback, me1._failureCallback);
				};
			$N.services.sdp.VOD.getAssetsByIds(this._assetIds, getVODCallback, this._failureCallback, true);
		};

		Search.prototype._dataCallback = function (result) {
			var filter = {},
				i = 0,
				len = 0;

			this._objectIds.length = 0;
			this._eventIds.length = 0;
			this._assetIds.length = 0;
			if (result.highlighting) {
				this._highlighting = result.highlighting;
			} else {
				this._highlighting = null;
			}
			this._numberOfObjectsFound = result.numberFound;

			for (i = 0, len = result.docs.length; i < len; i++) {
				this._objectIds.push(result.docs[i].id);
				if (result.docs[i].entity === "programme") {
					// BTV
					this._eventIds.push(result.docs[i].id);
				}
				if (result.docs[i].entity === "content") {
					// VOD
					this._assetIds.push(result.docs[i].id);
				}
			}
			this._getData();
		};

		Search.prototype._doSearch = function (searchTerm, queryFields, startRow, endRow, filter, showMatches) {
			var filterQuery = [],
				highlight = false,
				limit,
				me = this,
				callback = function (result) {
					me._dataCallback(result);
				};

			if (showMatches) {
				highlight = true;
			}
			limit = (endRow || MAX_NON_PAGING_RESULTS) - (startRow || 0);
			limit = limit > MAX_NON_PAGING_RESULTS ? MAX_NON_PAGING_RESULTS : limit;

			if (filter && filter.length) {
				filterQuery = filter.slice(0);
			}
			$N.services.sdp.MetadataService.doSearch(this, callback, this._failureCallback, searchTerm, filterQuery, ['id', 'entity'], null, null, limit, startRow, queryFields, highlight);
		};

		/* Public API */

		/**
		* Performs a full text search against title, description, synopsis and actor
		* @method search
		* @param {String} keyword - keyword to search on. The keyword can be prepended or prepended and appended with
		* a wild card '*' if rows ending with or containing the supplied string are required to be retrieved.
		* @param {Number} startRow - start number for rows being retrieved (used for pagination)
		* @param {Number} endRow - end number for rows being retrieved (used for pagination)
		* @param {Array} filter - string array of name-value pairs in ["key1: value1", "key2: value2"] format
		* @param {Array} queryFields - array of MDS field names to query in ["fieldName1", "fieldName2"] format
		* @param {Boolean} showMatches - boolean true if matched fields are to be returned
		*/
		Search.prototype.search = function (keyword, startRow, endRow, filter, queryFields, showMatches) {
			this._doSearch(keyword, queryFields, startRow, endRow, filter, showMatches);
		};

		/**
		* Performs a full text search against title
		* @method searchByTitle
		* @param {String} title - title to search on. The title can be prepended or prepended and appended with
		* a wild card '*' if rows ending with or containing the supplied string are required to be retrieved.
		* @param {Number} startRow - start number for rows being retrieved (used for pagination)
		* @param {Number} endRow - end number for rows being retrieved (used for pagination)
		* @param {Array} filter - string array of name-value pairs in ["key1: value1", "key2: value2"] format
		*/
		Search.prototype.searchByTitle = function (title, startRow, endRow, filter) {
			var queryFields = "title";
			this._doSearch(title, queryFields, startRow, endRow, filter);
		};

		/**
		* Performs a full text search against actor
		* @method searchByActor
		* @param {String} actor - actor to search on. The actor can be prepended or prepended and appended with
		* a wild card '*' if rows ending with or containing the supplied string are required to be retrieved.
		* @param {Number} startRow - start number for rows being retrieved (used for pagination)
		* @param {Number} endRow - end number for rows being retrieved (used for pagination)
		* @param {Array} filter - string array of name-value pairs in ["key1: value1", "key2: value2"] format
		*/
		Search.prototype.searchByActor = function (actor, startRow, endRow, filter) {
			var queryFields = "actors";
			this._doSearch(actor, queryFields, startRow, endRow, filter);
		};

		/**
		* Performs a full text search against director
		* @method searchByDirector
		* @param {String} actor - actor to search on. The actor can be prepended or prepended and appended with
		* a wild card '*' if rows ending with or containing the supplied string are required to be retrieved.
		* @param {Number} startRow - start number for rows being retrieved (used for pagination)
		* @param {Number} endRow - end number for rows being retrieved (used for pagination)
		* @param {Array} filter - string array of name-value pairs in ["key1: value1", "key2: value2"] format
		*/
		Search.prototype.searchByDirector = function (director, startRow, endRow, filter) {
			var queryFields = "directors";
			this._doSearch(director, queryFields, startRow, endRow, filter);
		};

		/**
		* Sets the success callback to the given callback function.
		* Callback will be passed an object consisting of start, numberFound and editorials properties
		* where start is the start row index, numberFound is the total number of results found and editorials
		* is an array of found assets
		* @method setSuccessCallback
		* @chainable
		* @param {Function} callback
		*/
		Search.prototype.setSuccessCallback = function (callback) {
			this._successCallback = callback;
			return this;
		};

		/**
		* Sets the failure callback to the given callback function
		* @method setFailureCallback
		* @chainable
		* @param {Function} callback
		*/
		Search.prototype.setFailureCallback = function (callback) {
			this._failureCallback = callback;
			return this;
		};

		/**
		 * Given a number of event ids, fetches EPG event information from the MdS - Used for search functionality.
		 * @method fetchEventsByIds
		 * @async
		 * @param {Array} ids list of event ids
		 * @param {Object} filter (optional) specifies additional filter criteria
		 * @param {Object} caller the object that will be used as the context for the callback functions
		 * @param {Function} successCallback function to be called when data has been retrieved.
		 * @param {Object} successCallback.response the data that is returned
		 * @param {Function} failureCallback function to be called when data has been retrieved.
		 * @param {Object} failureCallback.error information about the error
		*/
		Search.prototype.fetchEventsByIds = function (ids, filter, successCallback, failureCallback) {
			this._fetchEventsByIds(ids, filter, successCallback, failureCallback);
		};

		/**
		* Given an id and the highlighting object returned from a SOLR call
		* returns the matches for that id.
		* @method getMatchesById
		* @param {String} id of the object returned from search
		* @param {Object} lookup table of the matched data keyed by locale and id
		* @return {Object} matched data
		*/
		Search.prototype.getMatchesById =  function (id, highlighting) {
			return this._getMatchesById(id, highlighting);
		};


		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.Search = Search;
		return Search;
	}
);
