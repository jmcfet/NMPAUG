/**
 * Interacts with the head end LockerService
 * @class $N.services.sdp.LockerService
 * @constructor
 * @param{String} baseUrl - Locker Service Base URL
 * @param{String} port - Locker Service port
 * @param{String} servicePath - Path of the required LockerService API (E.G. - api/npvrlocker/v1)
 * @param{String} securityRequired - True or false depending on whether HTTPS should be used
 * @param{String} serviceProviderId - Service Provider ID
 */
/* global define, $N, window, */
define('jsfw/services/sdp/LockerService',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/BaseService',
		'jsfw/apps/util/JSON',
		'jsfw/apps/core/XssRequest',
		'jsfw/services/sdp/Signon'
	],
	function (Log, BaseService, JSON, XssRequest, Signon) {
		var ConstructorTypes = {
				OBJ: "OBJ",
				STR: "STR",
				ARR: "ARR"
			},
			SERVER_RESPONSES = {
				CANNOT_DELETE_PROTECTED: "Cannot DELETE a protected RecordingRequest",
				COULD_NOT_LOOKUP_PROGRAM: "Could not look up Programme",
				QUOTA_EXCEEDED: "Quota exceeded",
				TOKEN: "token",
				EXPIRED: "expired",
				INVALID: "invalid"
			},
			ERROR = {
				CANNOT_DELETE_PROTECTED: "Unable to delete a protected Recording",
				UNAUTHORISED: "Unauthorised",
				INTERNAL_ERROR: "Locker Server Internal Error",
				FORBIDDEN: "Forbidden",
				COULD_NOT_LOOKUP_PROGRAM: "Could not find program to record",
				QUOTA_EXCEEDED: "The quota for the account has been exceeded",
				TOKEN_ERROR: "Error obtaining a valid session token",
				UNKNOWN: "Unknown Error"
			},
			ERROR_CODES = {
				401: ERROR.UNAUTHORISED,
				403: ERROR.FORBIDDEN,
				500: ERROR.INTERNAL_ERROR,
				DEFAULT: ERROR.UNKNOWN
			};

		/*
		 * Private helper function used to determine constructor type.
		 */
		function getConstructorType(input) {
			var stringConstructor  = "test".constructor,
				objectConstructor = {}.constructor,
				arrayConstructor = [].constructor,
				inputConstructor = input.constructor,
				constructorType;

			if (inputConstructor === stringConstructor) {
				constructorType = ConstructorTypes.STR;
			} else if (inputConstructor === objectConstructor) {
				constructorType = ConstructorTypes.OBJ;
			} else if (inputConstructor === arrayConstructor) {
				constructorType = ConstructorTypes.ARR;
			}
			return constructorType;
		}

		/*
		 * Private helper function that builds a single query string item using a given key and value
		 */
		function createQueryParam(key, value) {
			var queryParam,
				valueType;

			if (key && (value || value === 0)) {
				valueType = getConstructorType(value);
				switch (valueType) {
				case ConstructorTypes.STR:
					value = encodeURIComponent(value);
					break;
				case ConstructorTypes.OBJ:
				case ConstructorTypes.ARR:
					value = encodeURIComponent($N.apps.util.JSON.stringify(value));
					break;
				}
				if (value !== "") {
					queryParam = encodeURIComponent(key) + "=" + value;
				}
			}
			return queryParam || null;
		}

		/*
		 * Private helper function that builds a query string based on the provided parameters
		 */
		function buildQueryString(paramsArray) {
			var i,
				len,
				kvp,
				key,
				value,
				flatParamsArray = [],
				param;

			for (i = 0, len = paramsArray.length; i < len; i++) {
				kvp = paramsArray[i];
				key = kvp[0];
				value = kvp[1];
				if (key &&  (value || value === 0)) {
					param = createQueryParam(key, value);
					if (param) {
						flatParamsArray.push(param);
					}
				}
			}
			return flatParamsArray.join("&");
		}

		/*
		 * Private helper function to remove "/" characters from the start or the end of a String.
		 */
		function sanitiseUrlComponent(component) {
			if (component) {
				if (component.charAt(component.length - 1) === "/") {
					component = component.substring(0, component.length - 1);
				}
				if (component.charAt(0) === "/") {
					component = component.substring(1);
				}
			}
			return component;
		}

		/*
		 * Main LockerService Constructor
		 */
		function LockerService(baseUrl, port, servicePath, securityRequired, serviceProviderId) {
			/**
			 * Enumerates the various sort types allowed for HTTP methods. One of GET, POST, PUT, DELETE
			 * @type {Object}
			 */
			this.HttpMethods = {
				GET: "GET",
				POST: "POST",
				PUT: "PUT",
				DELETE: "DELETE"
			};

			this.protocols = {
				HTTP: "http://",
				HTTPS: "https://"
			};

			this.serviceEndpoints = {
				RECORDING_REQUESTS : "recordingrequests",
				SERIES_RECORDING_REQUESTS : "seriesrecording",
				QUOTA_USAGE : "quotausage"
			};

			this.contentTypes = {
				JSON: "application/json"
			};

			this.queryParams = {
				SERIES: "seriesLinking=true"
			};

			this.seriesDeleteMethods = {
				CANCEL_SCHEDULES : "/cancelSeriesDeleteUnrecordedEpisodes",
				DELETE_RECORDINGS : "/deleteRecordedEpisodes",
				CLEAR_ALL : "/deleteSeriesDeleteAllEpisodes"
			};

			this.reSignonAttempted = false;
			this.baseUrl = sanitiseUrlComponent(baseUrl);
			this.serviceProviderId = sanitiseUrlComponent(serviceProviderId);
			this.servicePath = sanitiseUrlComponent(servicePath);
			this.port = port;
			this.securityRequired = securityRequired;
			this._log = new $N.apps.core.Log("sdp", "LockerService");
		}

		/**
		 * Private helper method used to build a URL
		 * @param  {String} serviceType URL endpoint
		 * @param  {String} httpMethod  HTTP method to use
		 * @return {String}             Generated URL
		 * @private
		 */
		LockerService.prototype._createUrl = function (serviceType, httpMethod) {
			var protocol = (this.securityRequired || this._isSecuredMethod(serviceType, httpMethod)) ? this.protocols.HTTPS : this.protocols.HTTP,
				path = this.servicePath ? (this.servicePath + "/" + serviceType + "/" + this.serviceProviderId) : (serviceType + "/" + this.serviceProviderId);

			return protocol + this.baseUrl + (this.port ? ":" + this.port + "/" + path : "/" + path);
		};

		/**
		 * Private helper method that checks if HTTPS is required for the given endpoint and HTTP method.
		 * @param  {String}  serviceType URL endpoint for the request. Corresponds to a configuration item name.
		 * @param  {String}  httpMethod  HTTP method of the request
		 * @return {Boolean}             True or false depending on if HTTPS is required
		 * @private
		 */
		LockerService.prototype._isSecuredMethod = function (serviceType, httpMethod) {
			var httpsConfig = $N.Config.HTTPS_CONFIG.LOCKER[serviceType.toUpperCase()],
				securityRequired;

			if (httpsConfig && httpsConfig.HTTP) {
				securityRequired = httpsConfig.HTTP[httpMethod];
			}
			return securityRequired;
		};

		/**
		 * Asynchronously invokes the specified locker service method.
		 * @method _invokeMethod
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} url - URL of web service
		 * @param {String} httpMethod - HTTP method to use
		 * @param {String} httpPayload - Parameters to be appended to URL or request body depending on HTTP method
		 * @param {String} queryParams - Query params to be added to URL
		 * @private
		 */
		LockerService.prototype._invokeMethod = function (successCallback, failureCallback, url, httpMethod, httpPayload, queryParams) {
			var me = this,
				token = this._getAuthToken(),
				xssRequest,
				fullQueryString = "",
				payloadConstructor,
				args = arguments,
				constructedUrl,
				parsedPayload,
				xssRequestSuccess = function (data) {
					me.reSignonAttempted = false;
					if (successCallback) {
						successCallback(data);
					}
				},
				xssRequestFailure = function (error) {
					var tokenError,
						expired,
						invalid,
						responseText;

					if (error && error.httpStatus) {
						responseText = error.responseText ? error.responseText.toLowerCase() : null;
						switch (error.httpStatus) {
						case 500:
							if (responseText && responseText.indexOf(SERVER_RESPONSES.COULD_NOT_LOOKUP_PROGRAM.toLowerCase()) !== -1) {
								failureCallback(ERROR.COULD_NOT_LOOKUP_PROGRAM);
							} else {
								failureCallback(ERROR_CODES[error.httpStatus]);
							}
							break;
						case 403:
							if (responseText && responseText.indexOf(SERVER_RESPONSES.CANNOT_DELETE_PROTECTED.toLowerCase()) !== -1) {
								failureCallback(ERROR.CANNOT_DELETE_PROTECTED);
							} else {
								failureCallback(ERROR_CODES[error.httpStatus]);
							}
							break;
						case 401:
							tokenError = responseText.indexOf(SERVER_RESPONSES.TOKEN.toLowerCase()) !== -1 ? true : false;
							expired = responseText.indexOf(SERVER_RESPONSES.EXPIRED.toLowerCase()) !== -1 ? true : false;
							invalid = responseText.indexOf(SERVER_RESPONSES.INVALID.toLowerCase()) !== -1 ? true : false;

							if (tokenError && (expired || invalid)) {
								if (!me.reSignonAttempted) {
									me.reSignonAttempted = true;
									me._attemptResignon(args);
								} else {
									failureCallback(ERROR.TOKEN_ERROR);
								}
							} else if (error.responseText.indexOf(SERVER_RESPONSES.QUOTA_EXCEEDED.toLowerCase()) !== -1) {
								failureCallback(ERROR.QUOTA_EXCEEDED);
							} else {
								failureCallback(ERROR_CODES[error.httpStatus]);
							}
							break;
						default:
							failureCallback(ERROR_CODES[error.httpStatus] || ERROR_CODES.DEFAULT);
						}
					} else {
						failureCallback(ERROR_CODES.DEFAULT);
					}
				};

			if (token) {
				fullQueryString += "token=" + encodeURIComponent(token);
			}
			if (queryParams) {
				fullQueryString += token ? "&" + queryParams : queryParams;
			}
			constructedUrl = fullQueryString.length > 0 ? url + "?" + fullQueryString : url;
			xssRequest = new $N.apps.core.XssRequest(httpMethod, constructedUrl, xssRequestSuccess, xssRequestFailure);
			if ((httpMethod === this.HttpMethods.PUT || httpMethod === this.HttpMethods.POST) && httpPayload) {
				if (getConstructorType(httpPayload) === ConstructorTypes.OBJ) {
					xssRequest.setContentType(this.contentTypes.JSON);
					parsedPayload = $N.apps.util.JSON.stringify(httpPayload);
				}
				xssRequest.send(parsedPayload);
			} else {
				xssRequest.send();
			}
		};

		/**
		 * Attempts re-sign on if the token is expired
		 * @private
		 */
		LockerService.prototype._attemptResignon = function (args) {
			var me = this,
			    signonSuccess = function () {
				    me._invokeMethod.apply(me, args);
					$N.services.sdp.Signon.unregisterListener(signonSuccess);
				};
			$N.services.sdp.Signon.registerListener(signonSuccess, this);
			$N.services.sdp.BaseService._RE_AUTHORISE_REQUEST.reIssueRequest();
		};

		/**
		 * Gets the Auth Token from BaseService
		 * @method getAuthToken
		 * @return{String} Auth token
		 * @private
		 */
		LockerService.prototype._getAuthToken = function () {
			return $N.services.sdp.BaseService._AUTH_TOKEN;
		};

		/**
		 * Asynchronously gets all recordings
		 * @method getAllRecordings
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {Object} filter - Filters to be applied to the request
		 * @param {Object} sortOrder - Order in which to return recordings
		 * @param {Object} fieldList - Fields to return
		 * @param {Number} count - Number of recordings to return
		 * @param {Number} offset - Offset
		 */
		LockerService.prototype.getAllRecordings = function (successCallback, failureCallback, filter, sortOrder, fieldList, count, offset) {
			var queryParams = buildQueryString([["filter", filter], ["sort", sortOrder], ["fields", fieldList], ["limit", count], ["offset", offset]]),
				url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.GET);
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.GET, null, queryParams);
		};

		/**
		 * Asynchronously gets a single recording
		 * @method getSingleRecording
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} recordingId - ID of the recording to get
		 * @param {Object} fieldList - Fields to return
		 */
		LockerService.prototype.getSingleRecording = function (successCallback, failureCallback, recordingId, fieldList) {
			var queryParams = buildQueryString([["fields", fieldList]]),
				url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.GET) + "/" + encodeURIComponent(recordingId);
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.GET, null, queryParams);
		};

		/**
		 * Asynchronously gets a series recording
		 * @method getSeriesRecordingRequest
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} seriesId - ID of the series to get (BTVEvent seriesRef)
		 */
		LockerService.prototype.getSeriesRecordingRequest = function (successCallback, failureCallback, seriesId) {
			var	queryParams = buildQueryString([["seriesId", seriesId]]);
				url = this._createUrl(this.serviceEndpoints.SERIES_RECORDING_REQUESTS, this.HttpMethods.GET);
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.GET, null, queryParams);
		};

		/**
		 * Asynchronously creates a recording request
		 * @method createRecordingRequest
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} mdsProgrammeId - ID of the MDS Event to schedule a recording for
		 * @param {String} accountId - ID of the account to associate with a scheduled recording
		 */
		LockerService.prototype.createRecordingRequest = function (successCallback, failureCallback, mdsProgrammeId, accountId) {
			var url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.POST),
				httpPayload = {
					accountNumber: accountId,
					programmeId: mdsProgrammeId
				};
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.POST, httpPayload, null);
		};

		/**
		 * Asynchronously creates a recording request for a whole series
		 * @method createSeriesRequest
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} mdsProgrammeId - ID of the MDS Event to schedule a recording for
		 * @param {String} seriesRef - ID of the series the MDS Event is an episode of
		 * @param {String} accountId - ID of the account to associate with a scheduled recording
		 */
		LockerService.prototype.createSeriesRequest = function (successCallback, failureCallback, mdsProgrammeId, seriesRef, accountId) {
			var url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.POST),
				httpPayload = {
					accountNumber: accountId,
					programmeId: mdsProgrammeId,
					seriesId: seriesRef
				};
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.POST, httpPayload, this.queryParams.SERIES);
		};

		/**
		 * Asynchronously updates a recording request
		 * @method updateRecordingRequest
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} recordingId - ID of the recording to update
		 * @param {Object} payload - Recording request data to update.
		 */
		LockerService.prototype.updateRecordingRequest = function (successCallback, failureCallback, recordingId, payload) {
			var filter = {
					id: recordingId
				},
				queryString = buildQueryString([["filter", filter]]),
				url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.PUT);

			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.PUT, payload, queryString);
		};

		/**
		 * Asynchronously deletes a recording
		 * @method deleteRecordingRequest
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} recordingId - ID of the recording to get
		 */
		LockerService.prototype.deleteRecordingRequest = function (successCallback, failureCallback, recordingId) {
			var url = this._createUrl(this.serviceEndpoints.RECORDING_REQUESTS, this.HttpMethods.DELETE) + "/" + encodeURIComponent(recordingId);
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.DELETE, null, null);
		};

		/**
		 * Asynchronously stops series recording and keeps all recorded episodes for that series
		 * @method cancelSeriesDeleteUnrecordedEpisodes
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} seriesId - ID of the series to get rid of
		 */
		LockerService.prototype.cancelSeriesDeleteUnrecordedEpisodes = function (successCallback, failureCallback, seriesId) {
			var url = this._createUrl(this.serviceEndpoints.SERIES_RECORDING_REQUESTS, this.HttpMethods.DELETE) + "/" + encodeURIComponent(seriesId) + this.seriesDeleteMethods.CANCEL_SCHEDULES;
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.DELETE, null, null);
		};

		/**
		 * Asynchronously keeps series recording but deletes all recorded episodes for that series
		 * @method deleteRecordedEpisodes
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} seriesId - ID of the series to get rid of
		 */
		LockerService.prototype.deleteRecordedEpisodes = function (successCallback, failureCallback, seriesId) {
			var url = this._createUrl(this.serviceEndpoints.SERIES_RECORDING_REQUESTS, this.HttpMethods.PUT) + "/" + encodeURIComponent(seriesId) + this.seriesDeleteMethods.DELETE_RECORDINGS;
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.PUT, null, null);
		};

		/**
		 * Asynchronously stops series recording AND deletes all recorded episodes for that series
		 * @method deleteSeriesDeleteAllEpisodes
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} seriesId - ID of the series to get rid of
		 */
		LockerService.prototype.deleteSeriesDeleteAllEpisodes = function (successCallback, failureCallback, seriesId) {
			var url = this._createUrl(this.serviceEndpoints.SERIES_RECORDING_REQUESTS, this.HttpMethods.DELETE) + "/" + encodeURIComponent(seriesId) + this.seriesDeleteMethods.CLEAR_ALL;
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.DELETE, null, null);
		};

		/**
		 * Asynchronously gets quota usage
		 * @method getQuotaUsage
		 * @async
		 * @param {Function} successCallback - Function to execute on success
		 * @param {Function} failureCallback - Function to execute on failure
		 * @param {String} accountNumber - ID of the account to get quota usage for
		 */
		LockerService.prototype.getQuotaUsage = function (successCallback, failureCallback, accountNumber) {
			var queryString = buildQueryString([["accountNumber", accountNumber]]),
				url = this._createUrl(this.serviceEndpoints.QUOTA_USAGE, this.HttpMethods.GET);
			this._invokeMethod(successCallback, failureCallback, url, this.HttpMethods.GET, null, queryString);
		};

		/**
		 * Defines constants for error types,
		 * one of:
		 * UNAUTHORISED,
		 * INTERNAL_ERROR,
		 * FORBIDDEN,
		 * UNKNOWN,
		 * CANNOT_DELETE_PROTECTED
		 * MAX_SIGNON_ATTEMPTS_REACHED
		 * @property {String} ERROR
		 */
		LockerService.ERROR = ERROR;

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.LockerService = LockerService;
		return LockerService;
	});
