/*global define, $N, window, drmAgent */
/**
 * SignonOnBrowser class
 * Contains NMP browser plugin specific signon functions
 * @class $N.services.sdp.signon.SignonOnBrowser
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.signon.AbstractSignonOnNMP
 */
define('jsfw/services/sdp/signon/SignonOnBrowser',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/signon/AbstractSignonOnNMP'
	],
	function (Log, AbstractSignonOnNMP) {

		function SignonOnBrowser(signonService, initialInterval, maximumRetries, backoffValue) {
			this._log = new $N.apps.core.Log("sdp.signon", "SignonOnBrowser");
			this.drmAgentInitialised = false;
			SignonOnBrowser.superConstructor.call(this, signonService, initialInterval, maximumRetries, backoffValue);
		}

		$N.apps.util.Util.extend(SignonOnBrowser, $N.services.sdp.signon.AbstractSignonOnNMP);

		SignonOnBrowser.prototype.getDrmAgentProperties = function (callback) {
			var attributes = {};
			attributes.state = drmAgent.state;
			attributes.lastCommunicationStatus = drmAgent.lastCommunicationStatus;
			attributes.prefetchLicensesState = drmAgent.prefetchLicensesState;
			attributes.deviceId = drmAgent.deviceId;
			if (attributes.state !== this.TDRM_STATE.STATE_INITIALIZING) {
				attributes.initializationPayloadForServer = drmAgent.initializationPayloadForServer;
				attributes.serverPrivateData = drmAgent.serverPrivateData;
			}
			this._log("getDRMAgentAttributesCallback ---> PROPS ", JSON.stringify(attributes));
			callback(attributes);
		};

		SignonOnBrowser.prototype.addInitializedEventListener = function (listener) {
			if (navigator.userAgent.indexOf("MSIE") === -1 && navigator.userAgent.indexOf("Trident") === -1) {
				drmAgent.addEventListener("initialized", listener, false);
			} else {
				drmAgent.attachEvent("oninitialized", listener);
			}
		};

		SignonOnBrowser.prototype.removeInitializedEventListener = function (listener) {
			if (navigator.userAgent.indexOf("MSIE") === -1 && navigator.userAgent.indexOf("Trident") === -1) {
				drmAgent.removeEventListener("initialized", listener);
			} else {
				drmAgent.detachEvent("oninitialized", listener);
			}
		};


		SignonOnBrowser.prototype.silentInitializeCallback = function (successCallback, failureCallback) {
			if (drmAgent.state === this.TDRM_STATE.STATE_READY || drmAgent.state === this.TDRM_STATE.STATE_INITIALIZING) {
				successCallback();
			} else {
				failureCallback();
			}
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.SignonOnBrowser = SignonOnBrowser;
		return SignonOnBrowser;
	});
