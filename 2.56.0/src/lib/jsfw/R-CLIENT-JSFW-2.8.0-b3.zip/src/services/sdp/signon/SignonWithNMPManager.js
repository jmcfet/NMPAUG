/*global drmAgent, require, define, Network, alert, Layer, Group, GlobalKeysInterceptor, $, Option, console, $N */
/**
 * Manager class for NMP SignOn. Controls sign on logic.
 * End point for each NMP signon is that both a device initialisation
 * is performed (either silent or non-silent) AND a sign on by user and
 * device is performed.
 * @class $N.services.sdp.signon.SignonWithNMPManager
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.signon.AbstractSignonOnNMP
 */
define('jsfw/services/sdp/signon/SignonWithNMPManager',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/signon/SignonOnBrowser',
		'jsfw/services/sdp/signon/SignonOnHandheld'
	],
	function (Log, SignonOnBrowser, SignonOnHandheld) {

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.SignonWithNMPManager = (function () {

			var log = new $N.apps.core.Log('sdp.signon', 'SignonWithNMPManager'),
				signonWorkflow = {},
				signonProperties = {},
				INIT_WORKFLOW =
				{
					isSignedOn: false,
					isSignedOnByUserAndDevice: false,
					isCheckedForUpgrade: false,
					isDeviceInitialised: false,
					isDeviceNameChecked: false
				},
				signonDevice = {};
				GetDRMAgentAttributesCallback = function (callback) {
					this.attributes = function (attributes) {
						log("getDRMAgentAttributesCallback ", attributes.state);
						callback(attributes);
					};
				};

			function _getDRMAgentProperties(successCallback) {
				var callback = function (attributes) {
					log("attributes : ", JSON.stringify(attributes));
					signonProperties.state = attributes.state;
					signonProperties.lastCommunicationStatus = attributes.lastCommunicationStatus;
					signonProperties.prefetchLicensesState = attributes.prefetchLicensesState;
					if (attributes.state !== signonDevice.TDRM_STATE.STATE_INITIALIZING) {
						signonProperties.initializationPayload = attributes.initializationPayloadForServer;
						signonProperties.serverPrivateData = attributes.serverPrivateData;
						signonDevice.setDeviceId(attributes.deviceId);
					}
					signonDevice.setSignonProperties(signonProperties);
					successCallback();
				};
				if ($N.env.platform === "NMP_PLUGIN") {
					signonDevice.getDrmAgentProperties(callback);
				} else {
					$N.services.sdp.signon.SignonWithNMPManager._getDRMAgentAttributesCallbackInstance = new GetDRMAgentAttributesCallback(callback);
					drmAgent.getGlobalAttributes("$N.services.sdp.signon.SignonWithNMPManager._getDRMAgentAttributesCallbackInstance");
				}
			}

			function _isPlayerUpgradeRecommended(data) {
				if (data.status === "PLAYER_UPGRADE_RECOMMENDED") {
					return true;
				}
				return false;
			}

			function _isSuccessful(data) {
				log("_isSuccessful", data.status);
				if (data.status === "OK" || data.status === "PLAYER_UPGRADE_RECOMMENDED" || data.status === "NO UPGRADE MANAGER SERVICE") {
					return true;
				}
				return false;
			}

			function _setDeviceNameFailureCallback(result) {
				log("_setDeviceNameFailureCallback", "Enter");
				signonDevice.setDeviceNamedFailedCallback(result);
			}

			function _setDeviceNameSuccessCallback(result) {
				log("_setDeviceNameSuccessCallback", "Enter");
				signonWorkflow.isDeviceNameChecked = true;
				_checkWorkFlow();
			}

			function _setDeviceName() {
				if (signonDevice.getDeviceName()) {
					signonDevice.setDeviceName(_setDeviceNameSuccessCallback, _setDeviceNameFailureCallback);
				} else {
					signonWorkflow.isDeviceNameChecked = true;
					_checkWorkFlow();
				}
			}

			function _removeListeners() {
				if ($N.env.platform === "NMP_PLUGIN") {
					if ($N.Config.DIRECT_MODE_SIGNON) {
						signonDevice.removeInitializedEventListener(_silentInitializeCallback);
					} else {
						signonDevice.removeInitializedEventListener(_initializeDRMAgentCallback);
					}
				} else {
					signonDevice.removeInitializedEventListener("$N.services.sdp.signon.SignonWithNMPManager._drmInitializedCallback");
				}
			}

			function _refreshDRMAttributes() {
				log("__refreshDRMAttributes", "Enter");
				if (signonDevice.getDrmAgentState() === signonDevice.TDRM_STATE.STATE_READY) {
					signonWorkflow.isDeviceInitialised = true;
					_removeListeners();
					_checkWorkFlow();
				} else {
					if (signonDevice.getDrmAgentState() !== signonDevice.TDRM_STATE.STATE_INITIALIZING) {
						_removeListeners();
						if (signonDevice.isWhiteboxCryptoError()) {
							_silentInitialize();
						}
					}
				}
				log("__refreshDRMAttributes", "Exit");
			}

			function _refreshDRM() {
				var callback = function() {
					_refreshDRMAttributes();
				};
				_getDRMAgentProperties(callback);
			}

			function _initializeDRMAgentCallback(result) {
				log("_initializeDRMAgentCallback", "Enter");
				_refreshDRM();
			}

			function _initializeSuccessCallback(data) {
				log("_initializeSuccessCallback", "Enter " + JSON.stringify(data));
				if (_isSuccessful(data)) {
					signonWorkflow.isDeviceInitialised = true;
					if (_isPlayerUpgradeRecommended(data)) {
						signonDevice.setPlayerUpgradeRecommended(data);
					}
					if ($N.env.platform === "NMP_PLUGIN") {
						signonDevice.addInitializedEventListener(_initializeDRMAgentCallback);
					} else {
						signonDevice.addInitializedEventListener("$N.services.sdp.signon.SignonWithNMPManager._drmInitializedCallback");
					}
					signonDevice.initialiseDRMAgent(data);
				} else {
					signonDevice.reportFailureStatus(data);
				}
			}

			function _initializeFailureCallback(result) {
				log("_initializeFailureCallback", "Enter");
				signonDevice.initializeFailureCallback(result);
			}

			function _silentInitializeSuccessCallback() {
				log("_silentInitializeSuccessCallback", "Enter");
				_refreshDRM();
			}

			function _silentInitializeFailureCallback() {
				log("_silentInitializeFailureCallback", "Enter");
				if (signonDevice.isWhiteboxCryptoError()) {
					_silentInitialize();
				} else {
					if ($N.env.platform === "NMP_PLUGIN") {
						signonDevice.removeInitializedEventListener(_silentInitializeCallback);
					} else {
						signonDevice.removeInitializedEventListener("$N.services.sdp.signon.SignonWithNMPManager._drmInitializedCallback");
					}
					signonDevice.signonFailedCallback("silent initialization error: " + drmAgent.lastCommunicationStatus + " " + drmAgent.state);
				}
			}

			function _silentInitializeCallback() {
				log("_silentInitializeCallback", "Enter");
				signonDevice.silentInitializeCallback(_silentInitializeSuccessCallback, _silentInitializeFailureCallback);
			}

			function _silentInitialize() {
				log("_silentInitialize", "Enter: " + signonDevice.getDrmAgentState());
				if ($N.env.platform === "NMP_PLUGIN") {
					signonDevice.addInitializedEventListener(_silentInitializeCallback);
				} else {
					signonDevice.addInitializedEventListener("$N.services.sdp.signon.SignonWithNMPManager._drmInitializedCallback");
				}
				signonDevice.silentInitialize();
				if (signonDevice.getDrmAgentState() === signonDevice.TDRM_STATE.STATE_READY && $N.env.deviceId) {
					signonWorkflow.isDeviceInitialised = true;
					_checkWorkFlow();
				}
			}

			function _checkForUpgradeSuccessCallback(response) {
				log("_checkForUpgradeSuccessCallback", "Enter");
				signonWorkflow.isCheckedForUpgrade = true;
				if (_isSuccessful(response)) {
					if (_isPlayerUpgradeRecommended(response)) {
						signonDevice.setPlayerUpgradeRecommended(response);
					}
					_checkWorkFlow();
				} else {
					signonDevice.reportFailureStatus(response);
				}
			}

			function _checkForUpgradeFailureCallback(response) {
				log("_checkForUpgradeFailureCallback", "Enter");
				signonDevice.signonFailedCallback(response.errorCode + " " + response.errorMessage + " " + response.status);
			}

			function _signonByUserAndDeviceSuccessCallback(result, token) {
				log("_signonByUserSuccessCallback", "Enter");
				signonDevice.setSignonSuccess(token);
				signonWorkflow.isSignedOnByUserAndDevice = true;
				_checkWorkFlow();
			}

			function _signonByUserAndDeviceFailureCallback(result, token) {
				signonDevice.signedOnByUserAndDeviceFailedCallback(result, token);
			}

			function _signonByUserSuccessCallback(result, token) {
				log("_signonByUserSuccessCallback", "Enter");
				signonDevice.setSignonSuccess(token);
				signonWorkflow.isSignedOn = true;
				_checkWorkFlow();
			}

			function _signonByUserFailureCallback(result, token) {
				signonDevice.signedOnByUserFailedCallback(result, token);
			}

			function _checkDeviceName() {
				if (signonWorkflow.isDeviceNameChecked) {
					if (signonWorkflow.isSignedOnByUserAndDevice) {
						signonDevice.signonSuccess(null, signonDevice.getToken());
					} else {
						signonDevice.doSignonByUserAndDevice(_signonByUserAndDeviceSuccessCallback, _signonByUserAndDeviceFailureCallback);
					}
				} else {
					_setDeviceName();
				}
			}

			function _checkWorkFlow() {
				if (signonWorkflow.isSignedOn || signonWorkflow.isSignedOnByUserAndDevice) {
					if ($N.Config.DIRECT_MODE_SIGNON) {
						if (signonWorkflow.isCheckedForUpgrade) {
							if (signonWorkflow.isDeviceInitialised) {
								_checkDeviceName();
							} else {
								_silentInitialize();
							}
						} else {
							signonDevice.checkForUpgrade(_checkForUpgradeSuccessCallback, _checkForUpgradeFailureCallback);
						}
					} else {
						if (signonWorkflow.isDeviceInitialised) {
							_checkDeviceName();
						} else {
							signonDevice.initialize(_initializeSuccessCallback, _initializeFailureCallback);
						}
					}
				} else {
					if ($N.env.deviceId) {
						signonDevice.doSignonByUserAndDevice(_signonByUserAndDeviceSuccessCallback, _signonByUserAndDeviceFailureCallback);
					} else {
						signonDevice.doSignonByUser(_signonByUserSuccessCallback, _signonByUserFailureCallback);
					}
				}
			}

			function _getPropertiesCallback() {
				log("_getPropertiesCallback", "Enter");
				_checkWorkFlow();
				log("_getPropertiesCallback", "Exit");
			}
/*
 * INIT
 */
			/**
			 * Initialises SignonWithNMPManager
			 * @method init
			 * @param {Object} signonObject. Sign on object - Either SignonOnHandheld or SignonOnBrowser
			 */
			function init(signonObject) {
				signonDevice = signonObject;
				log("init", "platform = " + $N.env.platform);
				if ($N.env.platform === "ANDROID" || $N.env.platform === "IOS") {
					$N.services.sdp.signon.SignonWithNMPManager._drmInitializedCallback = {
						initialized: function () {
							log("Sign on manager", "Initialize DRM");
							_initializeDRMAgentCallback();
						},
						prefetchingLicenseStateChanged: function() {},
						sessionsChanged: function () {}
					};
				}
			}

/*
 * SIGN ON AND INITIALISE BY NMP
 */
			/**
			 * Causes initiation of signon workflow
			 * @method signonAndInitialiseForNMP
			 * @param {String} userId
			 * @param {String} password
			 * @param {String} deviceName
			 * @param {String} directModeUrl url for direct mode signon
			 * @param {Object} upgradeManagerService upgradeManagerService
			 */
			function signonAndInitialiseForNMP(userId, password, deviceName, directModeURL, upgradeManagerService) {
				log("signonAndInitialiseForNMP", "Enter");
				signonWorkflow = INIT_WORKFLOW;
				signonProperties.username = userId;
				signonProperties.password = password;
				signonProperties.deviceName = deviceName;
				signonProperties.directModeURL = directModeURL;
				signonDevice.setUpgradeManagerService(upgradeManagerService);
				signonDevice.setSignonProperties(signonProperties);
				_getDRMAgentProperties(_getPropertiesCallback);
			}

			return {
				init: init,
				signonAndInitialiseForNMP : signonAndInitialiseForNMP
			};
		}());
		return $N.services.sdp.signon.SignonWithNMPManager;
	}
);