/*global define, $N, window */
/**
 * Abstract sign on class that is inherited by AbstractSignonOnNMP and SignonOnSTB
 * Contains common signon functions
 * @class $N.services.sdp.signon.AbstractSignon
 * @requires $N.apps.core.Log
 */
define('jsfw/services/sdp/signon/AbstractSignon',
	[
		'jsfw/apps/core/Log'
	],
	function (Log) {

		var retryInterval = 60000,
			retryMax = 8,
			retryBackOff = 2;

		function AbstractSignon(signonService, initialInterval, maximumRetries, backoffValue) {
			this._log = new $N.apps.core.Log("sdp.signon", "AbstractSignon");
			this.authToken = null;
			this.signonService = signonService;
			this.signonFailedCallback = function () {};
			this.listeners = [];
			this.signonParameters = [];
			this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
			this.retryInterval = initialInterval || retryInterval;
			this.retryMax = (maximumRetries !== undefined) ? maximumRetries : retryMax;
			this.retryCount = 0;
			this.retryBackOff = backoffValue ||retryBackOff;
			this.upgradeRecommended = false;
			this.upgradeData = {};
		}

		/**
		 * Calls the registered listeners
		 * @method applyListeners
		 * @private
		 */
		AbstractSignon.prototype.applyListeners = function (param) {
			this._log("applyListeners", "Enter");
			var i;

			for (i = this.listeners.length - 1; i >= 0; i--) {
				this._log("applyListeners", "Applying listener...");
				this.listeners[i].listener.apply(this.listeners[i].listeningObject, param);
			}
			this.upgradeRecommended = false;
			this.upgradeData = {};
			this._log("applyListeners", "Exit");
		};

		/**
		 * Sets the authorisation token
		 * @method setToken
		 * @private
		 */
		AbstractSignon.prototype.setToken = function (token) {
			if (token) {
				this.authToken = token;
			} else {
				this._log("setToken", "No token returned!");
			}
		};

		/**
		 * Returns the authorisation token that was obtained after successful
		 * sign on, otherwise returns null
		 * @method getToken
		 * @private
		 * @return {String}
		 */
		AbstractSignon.prototype.getToken = function () {
			return this.authToken;
		};

		/**
		 * Stops any re-attempts to signon if a previous request was unsuccessful.
		 * @method cancelOutstandingSignon
		 * @private
		 */
		AbstractSignon.prototype.cancelOutstandingSignon = function () {
			this.signonParameters = [];
			this.retryCount = 0;
			if (this.retryTimeout) {
				clearTimeout(this.retryTimeout);
			}
			this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
		};

		/**
		 * Sets up a retry timeout to re-attempt signon, upon every call to this
		 * method the retry timeout period increases up to a  maximum of the retryMax.
		 * @method setFailedSignonToPending
		 * @private
		 * @param {Function} signonMethod the signon function to use
		 * @param {String} parameter the value of MAC address, smartcardId or CASN
		 */
		AbstractSignon.prototype.setFailedSignonToPending = function (signonMethod, parameters) {
			var actualRetryInterval = this.retryInterval * Math.pow(this.retryBackOff, this.retryCount);
			this.retryCount++;
			if (this.retryCount <= this.retryMax) {
				this.log("setFailedSignonToPending", "Will retry signon in: " + String((actualRetryInterval / 1000) / 60) + " minute(s).", "warn");
				this.retryTimeout = setTimeout(function () {
					this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
					signonMethod(parameters[0], parameters[1], parameters[2]);
				}, actualRetryInterval);
			} else {
				$N.services.sdp.Signon.cancelOutstandingSignon();
				this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
				this.log("setFailedSignonToPending", "All signon retry attempts used up, failed to signon", "warn");
			}
		};

		/**
		 * Called after a successful signon, updates the internal state
		 * to STATE_SIGNED_ON and executes the registered listeners.
		 * @method signonSuccess
		 * @private
		 * @param {Object} result The result object returned by the signon service
		 * @param {String} token The token generated from the signon
		 */
		AbstractSignon.prototype.signonSuccess = function (result, token) {
			this._log("signonSuccess", "Signed In.");
			this.setToken(token);
			this.state = $N.services.sdp.Signon.STATE_SIGNED_ON;
			this.applyListeners();
			this._log("signonSuccess", "Exit");
		};

		/**
		 * Called in case of a signon failure, if set notifies the calling function
		 * by executing the signonFailedCallback
		 * @method signonFailureUserID
		 * @private
		 * @param {Object} result The result returned by the signon service
		 */
		AbstractSignon.prototype.signonFailureUserID = function (result) {
			this.log("signonFailureUserID", "Signed In Failed: " + result, "warn");
			this.authToken = null;
			if (this.signonFailedCallback) {
				this.signonFailedCallback(result);
			}
			if (result.indexOf("code=23017") === -1) {
				this.setFailedSignonToPending($N.services.sdp.Signon.signonByUser, this.signonParameters);
			} else {
				this.state = $N.services.sdp.Signon.STATE_NOT_SIGNED;
			}
			this.log("signonFailureUserID", "Exit");
		};

		/**
		 * Default callback executed on a successful signon by user call
		 * @method signedOnByUserCallback
		 * @private
		 * @param {Object} result The result returned by the signon service
		 */
		AbstractSignon.prototype.signedOnByUserCallback = function (result, token) {
			this.signonSuccess(result, token);
		};

		/**
		 * Default callback executed on a failed signon by user call
		 * @method ignedOnByUserFailedCallback
		 * @private
		 * @param {Object} result The result returned by the signon service
		 */
		AbstractSignon.prototype.signedOnByUserFailedCallback = function (result) {
			this.signonFailureUserID(result);
		};

		/**
		 * Registers a function to be executed upon successful signon
		 * @method registerListener
		 * @param {Function} listener a function to execute on signon
		 * @param {Object} listeningObject a reference back to the object containing the listener
		 */
		AbstractSignon.prototype.registerListener = function (listener, listeningObject) {
			this._log("registerListener", "New Listener Added");
			this.listeners.push({listener: listener, listeningObject: listeningObject});
		};

		/**
		 * Unregisters the previously registered function identified by the
		 * listener parameter, after calling this method the function will
		 * no longer execute upon successful signon
		 * @method unregisterListener
		 * @param {Function} listener
		 */
		AbstractSignon.prototype.unregisterListener = function (listener) {
			var i;
			for (i = 0; i < this.listeners.length; i++) {
				if (this.listeners[i].listener === listener) {
					this._log("unregisterListener", "Listener Removed");
					this.listeners.splice(i, 1);
					break;
				}
			}
		};

		/**
		 * Sets the callback to be executed if signon fails, this allows the class
		 * calling the signon method to be notified of the failure.
		 * @method setSignonFailedCallback
		 * @param {Function} callback
		 */
		AbstractSignon.prototype.setSignonFailedCallback = function (callback) {
			this.signonFailedCallback = callback;
		};

		/**
		 * Determines if the system is successfully signed on to SDP
		 * @method isSignedOn
		 * @return {Boolean} true if successfully signed on; false otherwise
		 */
		AbstractSignon.prototype.isSignedOn = function () {
			return (this.state === $N.services.sdp.Signon.STATE_SIGNED_ON);
		};

		/**
		* Checks whether there is a server connection error and returns a boolean
		* @method isConnectionError
		* @private
		* @param {String} result The result from the SDP call
		* @return {Boolean} true if there is a server connection error
		*/
		AbstractSignon.prototype.isConnectionError = function (result) {
			if (result === "[-1]") {
				return true;
			}
			return false;
		};

		/**
		 * Calls the signon service with the given username and password
		 * @method signonByUser
		 * @param {String} userID The User ID
		 * @param {String} password The Password (Param will be null when this is recalled after a timeout)
		 */
		AbstractSignon.prototype.signonByUser = function (userID, password, successCallback, failureCallback) {
			this._log("signonByUser", "Enter");
			var signonFailedMessage,
				signonSuccessCallback = successCallback || this.signedOnByUserCallback,
				signonFailureCallback = failureCallback || this.signedOnByUserFailedCallback;

			if (userID && password) {
				if (this.state !== $N.services.sdp.Signon.STATE_SIGNING_ON) {
					this._log("signonByUser", "userID: " + userID);
					this.signonParameters = [];
					this.signonParameters[0] = userID;
					this.signonParameters[1] = password;
					this.state = $N.services.sdp.Signon.STATE_SIGNING_ON;
					this.signonService.signonByUser(this, signonSuccessCallback, signonFailureCallback, userID, password);
				} else {
					signonFailedMessage = "signon request ignored - already attempting signon.";
					this._log("signonByUser", signonFailedMessage);
				}
			} else {
				signonFailedMessage = "No user id or password";
				this._log("signonByUser", signonFailedMessage);
				signonFailureCallback(signonFailedMessage);
			}
			this._log("signonByUser", "Exit");
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.AbstractSignon = AbstractSignon;
		return AbstractSignon;
	});
