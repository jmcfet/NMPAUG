/*global define, $N, window, drmAgent, userAgent */
/**
 * SignonOnHandheld class
 * Contains NMP IOS and Android specific signon functions
 * @class $N.services.sdp.signon.SignonOnHandheld
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.signon.AbstractSignonOnNMP
 */
define('jsfw/services/sdp/signon/SignonOnHandheld',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/signon/AbstractSignonOnNMP'
	],
	function (Log, AbstractSignonOnNMP) {

		function SignonOnHandheld(signonService, initialInterval, maximumRetries, backoffValue) {
			this._log = new $N.apps.core.Log("sdp.signon", "SignonOnHandheld");
			this.deviceInitialisedResponse = null;
			SignonOnHandheld.superConstructor.call(this, signonService, initialInterval, maximumRetries, backoffValue);
		}

		$N.apps.util.Util.extend(SignonOnHandheld, $N.services.sdp.signon.AbstractSignonOnNMP);

		SignonOnHandheld.prototype.addInitializedEventListener = function (listener) {
			this._log("addInitializedEventListener", "Enter");
			drmAgent.registerEventListener(listener);
			this._log("addInitializedEventListener", "Exit");
		};


		SignonOnHandheld.prototype.removeInitializedEventListener = function (listener) {
			this._log("removeInitializedEventListener", "Enter");
			drmAgent.unregisterEventListener(listener);
			this._log("removeInitializedEventListener", "Exit");
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};
		$N.services.sdp.signon = $N.services.sdp.signon || {};
		$N.services.sdp.signon.SignonOnHandheld = SignonOnHandheld;
		return SignonOnHandheld;
	});
