/**
 * Manages the list of favourite channels and VOD items created by the user.
 *
 * @class $N.services.sdp.Favourites
 * @singleton
 * @requires $N.apps.core.Log
 * @requires $N.services.sdp.Preferences
 * @requires $N.platform.system.Preferences
 */

/* global define */
define('jsfw/services/sdp/Favourites',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/Preferences',
		'jsfw/platform/system/Preferences'
	],
	function (Log, SDPPreferences, SystemPreferences) {
		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};

		$N.services.sdp.Favourites = (function () {
			var log = new $N.apps.core.Log('sdp', 'Favourites'),
				FAVOURITES = 'FAVOURITES',
				preferences,
				maxNumberOfFavourites,
				isLocalStorage = false,
				DEFAULT_MAX_ITEMS = 100,
				ERROR_CODES = {
					SERVER_ERROR_CREATE: 1000,
					SERVER_ERROR_DELETE: 1001,
					LOCAL_STORAGE_ERROR: 1002,
					MAX_FAVOURITES_REACHED: 1003,
					STALE_UPDATE: 1004
				};

			function getItemIndexInArray(item, type, array) {
				var returnIndex = -1,
					i;
				for (i = array.length - 1; i >= 0; i--) {
					if (array[i].cId === item && array[i].cT === type) {
						returnIndex = i;
						break;
					}
				}
				return returnIndex;
			}

			function doesItemExistInArray(item, type, array) {
				return getItemIndexInArray(item, type, array) > -1 ? true : false;
			}

			function removeFromArray(item, type, array) {
				var index = getItemIndexInArray(item, type, array);
				if (index > -1) {
					array.splice(index, 1);
				}
				return array;
			}

			/**
			 * Checks if a given error object represents a stale  update
			 * @param  {Object}  error error object to check
			 * @return {Boolean}       true if stale update
			 * @method _isStaleUpdate
			 * @private
			 */
			function _isStaleUpdate(error) {
 				return error.indexOf("20503:2504") !== -1 ? true : false;
			}

			/**
			 * Gets favourites (VOD & BTV) stored in SDP preferences
			 * @method getFavourites
			 * @param {Function} successCallback function to be called when favourites have been retrieved.
			 * @async
			 */
			function getFavourites(successCallback) {
				var failureCallback = function () {
						successCallback([]);
					},
					getSuccessCallback = function (items) {
						var parseError;
						if (items) {
							if (items.length > 0) {
								try {
									items = JSON.parse(items);
									log('getFavourites', 'Exit');
								} catch (e) {
									parseError = true;
									failureCallback();
									log('getFavourites', 'Exit');
								}
								if (!parseError) {
									successCallback(items);
								}
							} else {
								successCallback([]);
							}
						}
					},
					response;
				if (isLocalStorage) {
					response = preferences.get(FAVOURITES);
					if (response) {
						getSuccessCallback(response);
					} else {
						failureCallback();
					}
				} else {
					preferences.get(FAVOURITES, getSuccessCallback,	failureCallback);
				}
			}

			/**
			 * Adds favourite (BTV & VOD) to SDP preferences
			 * @method addToFavourites
			 * @param {String} favouriteToAdd the new favourite to be added
			 * @param {String} type the type of favourite (BTV or VOD)
			 * @param {Function} callback function to be called after an addition to favourites has been attempted.
			 * @param {Boolean} callback.successState Indicates if the addToFavourites call was successful or not.
			 * @param {Object} [callback.errorObject] Object containing error information if the request was unsuccessful.
			 * @param {String} [callback.errorObject.code] Error code indicating why the request failed
			 * @async
			 */
			function addToFavourites(favouriteToAdd, type, callback) {
				log('addFavourites', 'Enter');
				var j,
					response,
					allFavourites = [],
					failureCallback = function (error) {
						var errorCode;
						if (_isStaleUpdate(error)) {
							errorCode = ERROR_CODES.STALE_UPDATE;
						} else {
							errorCode = ERROR_CODES.SERVER_ERROR_CREATE;
						}
						callback(false, {code: errorCode});
					},
					successCallback = function () {
						callback(true);
					};

				if (favouriteToAdd) {
					getFavourites(function (storedFavourites) {
						var item = {
								cId: favouriteToAdd,
								cT: type
							};
						for (j = 0; j < storedFavourites.length; j++) {
							if (favouriteToAdd === storedFavourites[j].cId && type === storedFavourites[j].cT) {
								storedFavourites.splice(j, 1);
							}
						}
						if (storedFavourites.length < maxNumberOfFavourites) {
							if (storedFavourites.length > 0) {
								storedFavourites.unshift(item);
							} else {
								storedFavourites.push(item);
							}
							if (isLocalStorage) {
								response = preferences.set(FAVOURITES, JSON.stringify(storedFavourites));
								if (response) {
									successCallback();
								} else {
									callback(false, {code: ERROR_CODES.LOCAL_STORAGE_ERROR});
								}
							} else {
								preferences.set(FAVOURITES, JSON.stringify(storedFavourites), 'String', '', successCallback, failureCallback);
							}
						} else {
							callback(false, {code: ERROR_CODES.MAX_FAVOURITES_REACHED});
						}
					},
						failureCallback);
				} else {
					successCallback();
					log('addFavourites', 'Exit');
				}
			}

			/**
			 * Removes favourite (BTV or VOD) from SDP preferences
			 * @method removeFromFavourites
			 * @param {String} favouriteToRemove the new favourite to be added
			 * @param {String} type the type of favourite (BTV or VOD)
			 * @param {Function} callback function to be called after a removal from favourites has been attempted.
			 * @param {Boolean} callback.successState Indicates if the removeFromFavourites call was successful or not.
			 * @param {Object} [callback.errorObject] Object containing error information if the request was unsuccessful.
			 * @param {String} [callback.errorObject.code] Error code indicating why the request failed
			 * @asyncLOCAL_STORAGE_ERROR
			 */
			function removeFromFavourites(favouriteToRemove, type, callback) {
				log('removeFavourites', 'Enter');
				var i,
					allFavourites = [],
					response,
					failureCallback = function (error) {
						var errorCode;
						if (_isStaleUpdate(error)) {
							errorCode = ERROR_CODES.STALE_UPDATE;
						} else {
							errorCode = ERROR_CODES.SERVER_ERROR_DELETE;
						}
						callback(false, {code: errorCode});
					},
					successCallback = function () {
						callback(true);
					};
				if (favouriteToRemove) {
					getFavourites(function (storedFavourites) {
						if (favouriteToRemove) {
							allFavourites = removeFromArray(favouriteToRemove, type, storedFavourites);
							if (isLocalStorage) {
								response = preferences.set(FAVOURITES, JSON.stringify(allFavourites));
								if (response) {
									successCallback();
								} else {
									callback(false, {code: ERROR_CODES.LOCAL_STORAGE_ERROR});
								}
							} else {
								preferences.set(FAVOURITES, JSON.stringify(allFavourites), 'String', '', successCallback, failureCallback);
							}
						}
					}, failureCallback);
				} else {
					successCallback();
				}
				log('removeFavourites', 'Exit');
			}

			/**
			 * Test as to whether an item (BTV or VOD) is stored as a favourite in SDP preferences
			 * @method isItemInFavourites
			 * @param {String} item the item id to be checked
			 * @param {String} type the type of item (BTV or VOD)
			 * @param {Function} successCallback function to be called when item has been checked.
			 * A boolean value is passed in as a parameter to the callback.
			 * @async
			 */
			function isItemInFavourites(item, type, successCallback) {
				log('isItemInFavourites', 'Enter');
				getFavourites(function (items) {
					if (items && items.length && successCallback) {
						successCallback(doesItemExistInArray(item, type, items));
					} else if (successCallback) {
						successCallback(false);
					}
				}, function () {

					successCallback(false);
				});
				log('isItemInFavourites', 'Exit');
			}

			/**
			 * Deletes all favourites from SDP preferences.
			 * @method deleteAll
			 * @param {Function} successCallback function to be called when favourites have been deleted.
			 * @async
			 */
			function deleteAll(successCallback) {
				var failureCallback = function () {
						successCallback(false);
					},
					deleteSuccessCallback = function () {
						if (successCallback) {
							successCallback();
						}
					},
					response;
				if (isLocalStorage) {
					response = preferences.deletePreference(FAVOURITES);
					if (response) {
						deleteSuccessCallback();
					} else {
						failureCallback();
					}
				} else {
					preferences.deletePreference(FAVOURITES, deleteSuccessCallback, failureCallback);
				}
			}

			return {
				/**
				 * Initialises the class
				 * @method init
				 * @param {Number} maxItems the maximum number of favourites to be stored.
				 * @param {Boolean} useLocalStorage if set to true will write favourites to local storage as opposed to SDP
				 */
				init: function (maxItems, useLocalStorage) {
					isLocalStorage = useLocalStorage;
					preferences = useLocalStorage ? $N.platform.system.Preferences : $N.services.sdp.Preferences;
					maxNumberOfFavourites = maxItems || DEFAULT_MAX_ITEMS;
				},
				getFavourites: getFavourites,
				addToFavourites: addToFavourites,
				removeFromFavourites: removeFromFavourites,
				isItemInFavourites: isItemInFavourites,
				deleteAll: deleteAll,

				/**
				 * One of CONTENT_TYPE.BTV and CONTENT_TYPE.VOD
				 * @property {Number} CONTENT_TYPE
				 * @readonly
				 */
				CONTENT_TYPE: {
					BTV: 1,
					VOD: 2
				},

				/**
				 * One of ERROR_CODES.SERVER_ERROR_CREATE, SERVER_ERROR_DELETE, ERROR_CODES.MAX_FAVOURITES_REACHED, LOCAL_STORAGE_ERROR
				 * @property {Number} ERROR_CODES
				 * @readonly
				 */
				ERROR_CODES: ERROR_CODES
			};
		}());
		return $N.services.sdp.Favourites;
	});