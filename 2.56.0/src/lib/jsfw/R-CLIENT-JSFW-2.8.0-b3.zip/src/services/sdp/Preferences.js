/**
 * Preferences is a singleton utility class used for retrieving and storing a preference stored in SDP.
 *
 * @class $N.services.sdp.Preferences
 * @static
 * @singleton
 * @requires $N.services.sdp.ServiceFactory
 */
/* global define */
define('jsfw/services/sdp/Preferences',
	[
		'jsfw/services/sdp/ServiceFactory'
	],
	function (ServiceFactory) {
		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.sdp = $N.services.sdp || {};

		$N.services.sdp.Preferences = (function () {
			var ACCOUNT_ID = "";
			var USER_ID = "";
			var preferenceService;

			/* PRIVATE METHODS */

			/**
			 * Gets the list of prefs stored in SDP against user and account ids and extracts preferences
			 * that match the provided preference name.
			 * @method getPrefs
			 * @private
			 * @async
			 * @param {String} preference Name of the preference to find
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function getPrefs(preference, success, failure) {
				var getListCallback = function (list) {
					var i;
					var prefs = [];
					list.forEach(function (item) {
						if (item.paramName === preference.toUpperCase()) {
							prefs.push(item);
						}
					});
					if (prefs.length > 0) {
						success(prefs);
					} else {
						failure();
					}
				};
				preferenceService.getList(this, getListCallback, failure, ACCOUNT_ID, null, USER_ID);
			}

			/**
			 * Returns the most recently created preference that matches the provided preference name.
			 * @method getPref
			 * @private
			 * @async
			 * @param {String} preference Name of the preference to find
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function getPref(preference, success, failure) {
				var latestResult,
					getPrefsSuccess = function (result) {
						if (result && result.length) {
							result.forEach(function (item) {
								if (!latestResult) {
									latestResult = item;
								} else if (item.creationDate > latestResult.creationDate) {
									latestResult = item;
								}
							});
							success(latestResult);
						} else {
							failure();
						}
					};
				getPrefs(preference, getPrefsSuccess, failure);
			}

			/**
			 * Sets a new preference
			 * @method setPref
			 * @private
			 * @async
			 * @param {String} preference Name of the preference to set
			 * @param {String} value the value to be set
			 * @param {String} type Defines the parameter type associated to the preference (e.g. Long, String, Boolean etc)
			 * @param {String} domain Domain associated to the preference. Must be upper case and words separated by underscore (e.g. BV, NVOD, COD, COR etc)
			 * @param {Function} success Function to run upon upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function setPref(preference, value, type, domain, success, failure) {
				domain = domain ? domain.toUpperCase() : null;
				preference = preference.toUpperCase();
				preferenceService.create(this, success, failure, ACCOUNT_ID, domain, USER_ID, preference, value, type, null, null);
			}

			/**
			 * Deletes a single preference
			 * @method deleteSinglePref
			 * @private
			 * @async
			 * @param {String} preferenceUid UID of the preference to delete
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function deleteSinglePref(preferenceUid, success, fail) {
				preferenceService.del(this, success, fail, preferenceUid);
			}

			/**
			 * Gets and deletes all preferences matching the provided preference name
			 * @method deletePrefs
			 * @private
			 * @async
			 * @param {String} preference Name of the preference to delete
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function deletePrefs(preference, success, failure) {
				var getSuccess = function (result) {
					var prefsCount,
						deleteCallback = function () {
							prefsCount--;
							if (prefsCount === 0) {
								success();
							}
						};
					prefsCount = result.length;
					result.forEach(function (item) {
						deleteSinglePref(item.uid, deleteCallback, deleteCallback);
					});
				};
				getPrefs(preference, getSuccess, failure);
			}

			/**
			 * Updates a single preference
			 * @method updatePref
			 * @private
			 * @async
			 * @param {String} prefUid Uid of the preference to update
			 * @param {String} domain Domain associated to the preference. Must be upper case and words separated by underscore (e.g. BV, NVOD, COD, COR etc)
			 * @param {String} prefName The name of the preference to update
			 * @param {String} prefValue The new value to be set
			 * @param {String} prefType Defines the parameter type associated to the preference (e.g. Long, String, Boolean etc)
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 * @param {Number} modifiedDate The modified date of the preference to update
			 */
			function updatePref(prefUid, domain, prefName, prefValue, prefType, success, failure, modifiedDate) {
				prefName = prefName.toUpperCase();
				preferenceService.update(this, success, failure, prefUid, ACCOUNT_ID, domain, USER_ID, prefName, prefValue, prefType, modifiedDate);
			}

			/**
			 * Updates or creates a preference. If multiple preferences exist with the same name, the most recent one will be updated and the remaining
			 * preferences will be deleted.
			 * @method updateOrCreatePref
			 * @private
			 * @async
			 * @param {String} preference The name of the preference to create or update.
			 * @param {String} value The new value to be set
			 * @param {String} type Defines the parameter type associated to the preference (e.g. Long, String, Boolean etc)
			 * @param {String} domain Domain associated to the preference. Must be upper case and words separated by underscore (e.g. BV, NVOD, COD, COR etc)
			 * @param {Function} success Function to run upon success
			 * @param {Function} failure Function to run upon failure
			 */
			function updateOrCreatePref(preference, value, type, domain, success, failure) {
				var getSuccess = function (result) {
						var lastUid;
						result.forEach(function (item) {
							if (!lastUid) {
								lastUid = item.uid;
							} else {
								if (item.uid > lastUid) {
									item = item.uid;
								}
							}
						});
						result.forEach(function (item, index) {
							if (item.uid !== lastUid) {
								deleteSinglePref(item.uid, function () {}, function () {});
							} else {
								updatePref(lastUid, domain, preference, value, type, success, failure, item.modifiedDate);
							}
						});
					},
					getFail = function () {
						setPref(preference, value, type, domain, success, failure);
					};
				getPrefs(preference, getSuccess, getFail);
			}

			/* PUBLIC METHODS */

			return {

				/**
				 * Initialise the Preference class with the account and user ids
				 * @method init
				 * @param {Number} accountID
				 * @param {Number} userID
				 */
				init: function (accountID, userID) {
					preferenceService = $N.services.sdp.ServiceFactory.get("PreferenceService");
					ACCOUNT_ID = accountID;
					USER_ID = userID;
				},

				/**
				 * Initialise the Preference class with the account and user ids
				 * @method initialise
				 * @deprecated use init()
				 * @param {Number} accountID
				 * @param {Number} userID
				 */
				initialise: function (accountID, userID) {
					this.init(accountID, userID);
				},

				/**
				 * Retrieves a specified preference value.
				 * @method get
				 * @param {String} preference the name of the preference we're interested in
				 * @param {Function} success Function to run upon successfully retrieving the given preference
				 * @param {Function} failure Function to run upon failing to retrieve the given preference
				 */
				get: function (preference, success, failure) {
					var getCallback = function (pref) {
							success(pref.paramValue);
						};
					getPref(preference, getCallback, failure);
				},

				/**
				 * Stores a specified preference.
				 * @method set
				 * @param {String} preference the name of the preference we're interested in
				 * @param {String} value the value to be set
				 * @param {String} type Defines the parameter type associated to the preference (e.g. Long, String, Boolean etc)
				 * @param {String} domain Domain associated to the preference. Must be upper case and words separated by underscore (e.g. BV, NVOD, COD, COR etc)
				 * @param {Function} success Function to run after successfully setting the preference
				 * @param {Function} failure Function to run upon failure to set the preference
				 * @param {Boolean} isChunk True if part of a chunk - should only be set internally
				 */
				set: function (preference, value, type, domain, success, failure) {
					updateOrCreatePref(preference, value, type, domain, success, failure);
				},

				/**
				 * Removes a specified preference
				 * @method deletePreference
				 * @param {String} preference the name of the preference we'd like to remove
				 * @param {Function} success Function to run upon successfully deleting the preference
				 * @param {Function} failure Function to run upon failure to delete the preference
				 */
				deletePreference: function (preference, success, failure) {
					deletePrefs(preference, success, failure);
				}
			};
		}());
		return $N.services.sdp.Preferences;
	});