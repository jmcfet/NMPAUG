/**
 * Interacts with the head end UpgradeManagerService
 * @class $N.services.sdp.UpgradeManagerService
 * @constructor
 * @param{String} baseUrl - Multidrm Service Base URL
 * @param{String} port - Multidrm Service port
 * @param{String} servicePath - Path of the required UpgradeManagerService API
 * @param{String} securityRequired - True or false depending on whether HTTPS should be used
 */
/*global define, $N, window */
define('jsfw/services/multidrm/UpgradeManagerService',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/RESTService'
	],
	function (Log, RESTService) {

		/**
		 * UpgradeManagerService Constructor
		 * @param {String} url - URL of web service
		 * @param {Boolean} securityRequired - Determines whether https request used
		 * @private
		 */
		function UpgradeManagerService(url, securityRequired) {
			this._log = new $N.apps.core.Log("multidrm", "UpgradeManagerService");
			UpgradeManagerService.superConstructor.call(this, url, null, null, securityRequired);
		}

		$N.apps.util.Util.extend(UpgradeManagerService, $N.services.sdp.RESTService);

		//Public methods

		/**
		 * Calls checkForUpgrade function
		 * @method checkForUpgrade
		 * @param {Function} successCallback success callback function fired
		 * @param {Function} failureCallback failure callback function fired
		 * @param {Object} checkForUpgradeRequest checkForUpgradeRequest object
		 */
		UpgradeManagerService.prototype.checkForUpgrade = function (successCallback, failureCallback, checkForUpgradeRequest) {
			var endPoint =  "checkForUpgrade";
			this.postRequest(successCallback, failureCallback, endPoint, checkForUpgradeRequest);
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.multidrm = $N.services.multidrm || {};
		$N.services.multidrm.UpgradeManagerService = UpgradeManagerService;
		return UpgradeManagerService;
	});
