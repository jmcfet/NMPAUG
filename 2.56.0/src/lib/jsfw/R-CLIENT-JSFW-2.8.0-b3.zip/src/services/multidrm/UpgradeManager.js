/*global define, $N, window, document, navigator */
/**
 * Class that allows interaction with the multidrm upgradeManager service
 * @class $N.services.sdp.UpgradeManager
 * @constructor
 * @param {Object} multidrm UpgradeManagerService instance
*/
define('jsfw/services/multidrm/UpgradeManager',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/multidrm/UpgradeManagerService'
	],
	function (Log, UpgradeManagerService) {

		var ERROR = {
			FAILED_TO_CHECK_FOR_UPGRADE: "Failed to check for upgrade"
		};

		function UpgradeManager(upgradeManagerService) {
			this._log = new $N.apps.core.Log("multidrm", "UpgradeManager");
			this._upgradeManagerService = upgradeManagerService;
		}

		/**
		 * Checks if a plugin upgrade is required.
		 * @method checkForUpgrade
		 * @param {Function} successCallback Callback function fired on success
		 * @param {Function} failureCallback Callback function fired on failure
		 * @param {String} applicationData Application data to use in the request body
		 */
		UpgradeManager.prototype.checkForUpgrade = function (successCallback, failureCallback, applicationData) {
			var me = this,
				platform,
				playerVersion,
				checkForUpgradeRequest;

			switch (navigator.platform) {
			case 'Mac68K':
			case 'MacPPC':
			case 'MacIntel':
				platform = "MacOS";
				break;
			default:
				platform = navigator.platform;
			}

			playerVersion = $N.env.playerVersion || null;

			checkForUpgradeRequest = {
				'applicationData': applicationData,
				'platform': platform,
				'playerOrPluginVersion': playerVersion
			};

			this._upgradeManagerService.checkForUpgrade(
				successCallback,
				failureCallback,
				checkForUpgradeRequest
			);
		};

		/**
		 * Returns recommendations for the current account
		 * @method downloadPlugin
		 * @param {Object} downloadData Download data containing the download URL
		 */
		UpgradeManager.prototype.downloadPlugin = function (downloadData) {
			var iframe = document.createElement('iframe');
			var downloadUrl = downloadData.downloadUrl.replace(".cab", ".exe");

			iframe.style.display = 'none';
			document.body.appendChild(iframe);
			iframe.src = downloadUrl;
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.multidrm = $N.services.multidrm || {};
		$N.services.multidrm.UpgradeManager = UpgradeManager;
		return UpgradeManager;
	});
