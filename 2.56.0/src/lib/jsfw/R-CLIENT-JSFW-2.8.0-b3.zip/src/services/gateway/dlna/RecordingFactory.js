/**
 * RecordingFactory creates an Recording object or an array of Recording objects
 * passed in from an external application. This factory creates its output from
 * Recordings passed in from OTV 5 gateway.
 * @class $N.services.gateway.dlna.RecordingFactory
 * @author Scott Dermott
 * @constructor
 */
/* global define */
define('jsfw/services/gateway/dlna/RecordingFactory',
	[
		'jsfw/data/Recording'
	],
	function (Recording) {
		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.gateway = $N.services.gateway || {};
		$N.services.gateway.dlna = $N.services.gateway.dlna || {};

		$N.services.gateway.dlna.RecordingFactory = (function () {

			var defineGetter;
			if (Object.defineProperty) {
				defineGetter = function (obj, property, getterFunction) {
					Object.defineProperty(obj, property, {
						get: getterFunction
					});
				};
			} else {
				defineGetter = function (obj, property, getterFunction) {
					obj.__defineGetter__(property, getterFunction);
				};
			}

			function getDurationMilliseconds(duration) {
				//duration in format P01:02:33
				var timeArray = duration.split(":");
				var hoursAsMilliseconds = timeArray[0].substring(1) * 3600000;
				var minutesAsMillisecond = timeArray[1] * 60000;
				var secondsAsMillisecond = timeArray[2] * 1000;
				return (hoursAsMilliseconds + minutesAsMillisecond + secondsAsMillisecond);
			}

			function isValidDate(d) {
				if (Object.prototype.toString.call(d) !== "[object Date]")
					return false;
				return !isNaN(d.getTime());
			}

			function getMappedObject(obj) {
				var recordingType,
					mapped = {
						_data: obj
					};

				defineGetter(mapped, "taskId", function () {
					if (mapped._data.srsRecordTaskID){
						return mapped._data.srsRecordTaskID.text;
					} else if (mapped._data['class'] === 'OBJECT.RECORDTASK'){
						return mapped._data.id;
					}
					return null;
				});
				defineGetter(mapped, "jobId", function () {
					if (mapped._data.recordScheduleID){
						return mapped._data.recordScheduleID.text || mapped._data.recordScheduleID;
					} else if(mapped._data.srsRecordScheduleID){
						return mapped._data.srsRecordScheduleID.text || mapped._data.srsRecordScheduleID;
					} else if(mapped._data.id){
						return mapped._data.id;
					}
					return null;
				});
				defineGetter(mapped, "seriesId", function () {
					if (mapped._data.matchingID){
						return mapped._data.matchingID.text;
					} else if (mapped._data.seriesID) {
						return mapped._data.seriesID.text;
					}
					return null;
				});
				defineGetter(mapped, "seasonId", function () {
					return null;
				});
				defineGetter(mapped, "episodeId", function () {
					if (mapped._data.episodeID){
						return mapped._data.episodeID.text || mapped._data.episodeID;
					}
					return null;
				});
				defineGetter(mapped, "seriesName", function () {
					if (mapped._data.programTitle){
						return mapped._data.programTitle.text || mapped._data.programTitle;
					} else if (mapped._data.title){
						return mapped._data.title.text || mapped._data.title;
					}
					return null;
				});
				defineGetter(mapped, "title", function () {
					if (mapped._data.title){
						return mapped._data.title.text || mapped._data.title;
					}
					return null;
				});
				defineGetter(mapped, "url", function () {
					if (mapped._data.defaultPlaybackInfo) {
						return mapped._data.defaultPlaybackInfo.url;
					}
					return null;
				});
				defineGetter(mapped, "eventId", function () {
					if (mapped._data.programID) {
						return mapped._data.programID.text;
					}
					return null;
				});
				defineGetter(mapped, "startTime", function () {
					if (mapped._data.taskStartDateTime) {
						return isValidDate(new Date(mapped._data.taskStartDateTime)) ? new Date(mapped._data.taskStartDateTime) : mapped._data.taskStartDateTime;
					} else if (mapped._data.recordedStartDateTime) {
						return isValidDate(new Date(mapped._data.recordedStartDateTime.text)) ? new Date(mapped._data.recordedStartDateTime.text) : mapped._data.recordedStartDateTime.text;
					} else if (mapped._data.scheduledStartDateTime) {
						return isValidDate(new Date(mapped._data.scheduledStartDateTime)) ? new Date(mapped._data.scheduledStartDateTime) : mapped._data.scheduledStartDateTime;
					}
					return null;
				});
				defineGetter(mapped, "endTime", function () {
					if (mapped._data.scheduledEndTime) {
						return isValidDate(new Date(mapped._data.scheduledEndTime.text)) ? new Date(mapped._data.scheduledEndTime.text) : mapped._data.scheduledEndTime.text;
					}
					return null;
				});
				defineGetter(mapped, "softPrepaddingDuration", function () {
					if (mapped._data.scheduledStartDateTimeAdjust) {
						return getDurationMilliseconds(mapped._data.scheduledStartDateTimeAdjust);
					} else if (mapped._data.taskStartDateTimeAdjust) {
						return getDurationMilliseconds(mapped._data.taskStartDateTimeAdjust);
					}
					return null;
				});
				defineGetter(mapped, "softPostpaddingDuration", function () {
					if (mapped._data.scheduledDurationAdjust) {
						return getDurationMilliseconds(mapped._data.scheduledDurationAdjust);
					} else if (mapped._data.taskDurationAdjust) {
						return getDurationMilliseconds(mapped._data.taskDurationAdjust);
					}
					return null;
				});
				defineGetter(mapped, "duration", function () {
					if (mapped._data.taskDuration) {
						return getDurationMilliseconds(mapped._data.taskDuration);
					} else if (mapped._data.recordedDuration) {
						return getDurationMilliseconds(mapped._data.recordedDuration.text);
					} else if (mapped._data.scheduledDuration) {
						return getDurationMilliseconds(mapped._data.scheduledDuration);
					}
					return null;
				});
				defineGetter(mapped, "serviceId", function () {
					if (mapped._data.channelID) {
						return mapped._data.channelID.text || mapped._data.channelID;
					} else if(mapped._data.scheduledChannelID) {
						return mapped._data.scheduledChannelID.text || mapped._data.scheduledChannelID;
					} else if(mapped._data.taskChannelID) {
						return mapped._data.taskChannelID.text || mapped._data.taskChannelID;
					}
					return null;
				});
				defineGetter(mapped, "shortDesc", function () {
					if (mapped._data.description) {
						return mapped._data.description.text || null;
					}
					return null;
				});
				defineGetter(mapped, "longDesc", function () {
					if (mapped._data.longDescription) {
						return mapped._data.longDescription.text || null;
					}
					return null;
				});
				defineGetter(mapped, "contentDesc", function () {
					if (mapped._data.longDescription) {
						return mapped._data.longDescription.text || null;
					}
					return null;
				});
				defineGetter(mapped, "keep", function () {
					if(mapped._data.restricted){
						return mapped._data.restricted;
					}
					return null;
				});
				defineGetter(mapped, "bookmark", function () {
					if(mapped._data.lastPlaybackPosition){
						return getDurationMilliseconds(mapped._data.lastPlaybackPosition.text);
					}
					return null;
				});
				defineGetter(mapped, "parentalRating", function () {
					if(mapped._data.rating){
						return mapped._data.rating.text || mapped._data.rating;
					}
					return null;
				});
				defineGetter(mapped, "recordingType", function () {
					if(mapped._data.matchingID && mapped._data['class'] !== 'OBJECT.RECORDTASK'){
						return $N.data.Recording.RECORDING_TYPE.SERIES;
					}
					return $N.data.Recording.RECORDING_TYPE.SINGLE;
				});
				defineGetter(mapped, "image", function () {
					if(mapped._data.albumArtURI){
						return mapped._data.albumArtURI.text || mapped._data.albumArtURI;
					}
					return null;
				});
				return mapped;
			}

			function getMappedArray(array) {
				var i,
					mapped,
					mappedArray	= [];

				if (array.length > 0) {
					for (i = 0; i < array.length; i++) {
						mapped = getMappedObject(array[i]);
						mappedArray.push(mapped);
					}
				}
				return mappedArray;
			}

			return {
				/**
				 * Takes a recording object as returned from the platform and returns a
				 * recording object mapped to the framework standard as defined
				 * in Recording
				 * @method mapObject
				 * @param {Object} obj the object to map
				 * @return {Object}
				 */
				mapObject: function (obj) {
					if (obj) {
						return getMappedObject(obj);
					} else {
						return null;
					}
				},

				/**
				 * Takes an array of recording objects from the platform and returns an
				 * array of recording objects mapped to the framework standard as defined
				 * in Recording
				 * @method mapArray
				 * @param {Object} array the objects to map
				 * @return {Array}
				 */
				mapArray: function (array) {
					if (array) {
						return getMappedArray(array);
					} else {
						return [];
					}
				}
			};
		}());
		return $N.services.gateway.dlna.RecordingFactory;
	}
);