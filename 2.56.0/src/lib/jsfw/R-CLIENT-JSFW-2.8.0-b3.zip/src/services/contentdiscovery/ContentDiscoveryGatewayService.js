/**
 * Interacts with the head end ContentDiscoveryGatewayService
 * @class $N.services.sdp.ContentDiscoveryGatewayService
 * @constructor
 * @param{String} baseUrl - Locker Service Base URL
 * @param{String} port - Locker Service port
 * @param{String} servicePath - Path of the required ContentDiscoveryGatewayService API
 * @param{String} securityRequired - True or false depending on whether HTTPS should be used
 */
/*global define, $N, window */
define('jsfw/services/contentdiscovery/ContentDiscoveryGatewayService',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/sdp/RESTService'
	],
	function (Log, RESTService) {

		/*
		 * Main ContentDiscoveryGatewayService Constructor
		 */
		function ContentDiscoveryGatewayService(baseUrl, port, servicePath, securityRequired) {
			this._log = new $N.apps.core.Log("sdp", "ContentDiscoveryGatewayService");
			ContentDiscoveryGatewayService.superConstructor.call(this, baseUrl, port, servicePath, securityRequired);
		}

		$N.apps.util.Util.extend(ContentDiscoveryGatewayService, $N.services.sdp.RESTService);

		//Public methods

		ContentDiscoveryGatewayService.prototype.fetchRecommendationsByAccount = function (successCallback, failureCallback, accountId,
																		filterArray, fields, count, offset) {
			var endPoint =  "recommendations/account/" + accountId;
			this.getRequest(successCallback, failureCallback, endPoint, filterArray, fields, count, offset);
		};

		ContentDiscoveryGatewayService.prototype.fetchRecommendationsByAccountAndUser = function (successCallback, failureCallback, accountId,
																		userUid, filterArray, fields, count, offset) {
			var endPoint =  "recommendations/account/" + accountId + "/user/" + userUid;
			this.getRequest(successCallback, failureCallback, endPoint, filterArray, fields, count, offset);
		};

		ContentDiscoveryGatewayService.prototype.setUserActivityByAccount = function (successCallback, failureCallback, activityName, accountId,
																							 userActivity) {
			var endPoint =  "useractivity/" + activityName + "/account/" + accountId;
			this.postRequest(successCallback, failureCallback, endPoint, userActivity);
		};

		ContentDiscoveryGatewayService.prototype.setUserActivityByAccountAndUser = function (successCallback, failureCallback, activityName,
																									accountId, userUid, userActivity) {
			var endPoint =  "useractivity/" + activityName + "/account/" + accountId + "/user/" + userUid;
			this.postRequest(successCallback, failureCallback, endPoint, userActivity);
		};

		ContentDiscoveryGatewayService.prototype.fetchUserActivityByAccount = function (successCallback, failureCallback, activityName, accountId) {
			var endPoint =  "useractivity/" + activityName + "/account/" + accountId;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		ContentDiscoveryGatewayService.prototype.fetchUserActivityByAccountAndUser = function (successCallback, failureCallback, activityName, accountId,
																		userUid) {
			var endPoint = "useractivity/" + activityName + "/account/" + accountId + "/user/" + userUid;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		ContentDiscoveryGatewayService.prototype.deleteUserActivityByAccount = function (successCallback, failureCallback, accountId, deleteRequest) {
			var endPoint = "useractivity/account/" + accountId;
			this.deleteRequest(successCallback, failureCallback, endPoint, deleteRequest);
		};

		ContentDiscoveryGatewayService.prototype.deleteUserActivityByAccountAndUser = function (successCallback, failureCallback, accountId,
																		userUid, deleteRequest) {
			var endPoint =  "useractivity/account/" + accountId + "/user/" + userUid;
			this.deleteRequest(successCallback, failureCallback, endPoint, deleteRequest);
		};

		ContentDiscoveryGatewayService.prototype.setRatingByAccount = function (successCallback, failureCallback, accountId,
																							 ratingRequest) {
			var endPoint =  "ratings/account/" + accountId;
			this.postRequest(successCallback, failureCallback, endPoint, ratingRequest);
		};

		ContentDiscoveryGatewayService.prototype.setRatingByAccountAndUser = function (successCallback, failureCallback,
																									accountId, userUid, ratingRequest) {
			var endPoint =  "ratings/account/" + accountId + "/user/" + userUid;
			this.postRequest(successCallback, failureCallback, endPoint, ratingRequest);
		};

		ContentDiscoveryGatewayService.prototype.fetchRatingsByAccount = function (successCallback, failureCallback, accountId) {
			var endPoint =  "ratings/account/" + accountId;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		ContentDiscoveryGatewayService.prototype.fetchRatingsByAccountAndUser = function (successCallback, failureCallback, accountId,
																		userUid) {
			var endPoint =  "ratings/account/" + accountId + "/user/" + userUid;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		ContentDiscoveryGatewayService.prototype.fetchContentRatingByAccount = function (successCallback, failureCallback, accountId, contentId) {
			var endPoint =  "ratings/content/" + contentId + "/account/" + accountId;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		ContentDiscoveryGatewayService.prototype.fetchContentRatingByAccountAndUser = function (successCallback, failureCallback, accountId,
																		userUid, contentId) {
			var endPoint =  "ratings/content/" + contentId + "/account/" + accountId + "/user/" + userUid;
			this.getRequest(successCallback, failureCallback, endPoint);
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.contentdiscovery = $N.services.contentdiscovery || {};
		$N.services.contentdiscovery.ContentDiscoveryGatewayService = ContentDiscoveryGatewayService;
		return ContentDiscoveryGatewayService;
	});
