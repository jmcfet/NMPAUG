/*global define, $N, window */
/**
 * Class that allows interaction with the head end locker service
 * @class $N.services.sdp.DynamicRecommendations
 * @constructor
 * @param {Object} contentDiscoveryGateway ContentDiscoveryGatewayService instance
*/
define('jsfw/services/contentdiscovery/DynamicRecommendations',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/contentdiscovery/ContentDiscoveryGatewayService',
		'jsfw/services/sdp/Account'
	],
	function (Log, ContentDiscoveryGatewayService, Account) {

		var ERROR = {
			FAILED_TO_GET_RECOMMENDATIONS: "Failed to get recommendations"
		};

		function getFilterArray(recommendationRequest, filter) {
			var	filterArray = [],
				filterObject = {
					name: "filter",
					filter: filter
				},
				RRfilterObject = {
					name: "recommendationRequest",
					filter: recommendationRequest
				};

			filterArray.push(RRfilterObject);
			if (filter) {
				filterArray.push(filterObject);
			}
			return filterArray;
		}

		function DynamicRecommendations(contentDiscoveryGatewayService) {
			this._log = new $N.apps.core.Log("contentdiscovery", "DynamicRecommendations");
			this._contentDiscoveryGatewayService = contentDiscoveryGatewayService;
		}

		/**
		 * Returns recommendations for the current account
		 * @method fetchRecommendationsByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {Object} recommendationRequest recommendationRequest object
		 * @param {Object} filter filter object
		 * @param {Array} fieldList array of fields to retrieve
		 * @param {Number} count number of recommendations to retrieve
		 */
		DynamicRecommendations.prototype.fetchRecommendationsByAccount = function (callback, account, recommendationRequest, filter,
																					fieldList, count) {
			var me = this,
				successCallback = function (recommendations) {
					callback(recommendations);
				},
				failureCallback = function () {
					me._log("fetchRecommendationsByAccount", ERROR.FAILED_TO_GET_RECOMMENDATIONS);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchRecommendationsByAccount(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				getFilterArray(recommendationRequest, filter),
				fieldList,
				count
			);
		};

		/**
		 * Returns recommendations for the current account and user
		 * @method fetchRecommendationsByAccountAndUser
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {Object} recommendationRequest recommendationRequest object
		 * @param {Object} filter filter object
		 * @param {Array} fieldList array of fields to retrieve
		 * @param {Number} count number of recommendations to retrieve
		 */
		DynamicRecommendations.prototype.fetchRecommendationsByAccountAndUser = function (callback, account, user, recommendationRequest, filter,
																					fieldList, count) {
			var me = this,
				successCallback = function (recommendations) {
					callback(recommendations);
				},
				failureCallback = function () {
					me._log("fetchRecommendationsByAccountAndUser", ERROR.FAILED_TO_GET_RECOMMENDATIONS);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchRecommendationsByAccountAndUser(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				user,
				getFilterArray(recommendationRequest, filter),
				fieldList,
				count
			);
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.contentdiscovery = $N.services.contentdiscovery || {};
		$N.services.contentdiscovery.DynamicRecommendations = DynamicRecommendations;
		return DynamicRecommendations;
	});
