/*global define, $N, window */
/**
 * Class that allows interaction with the head end locker service
 * @class $N.services.sdp.Ratings
 * @constructor
 * @param {Object} contentDiscoveryGateway ContentDiscoveryGatewayService instance
*/
define('jsfw/services/contentdiscovery/Ratings',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/contentdiscovery/ContentDiscoveryGatewayService',
		'jsfw/services/sdp/Account'
	],
	function (Log, ContentDiscoveryGatewayService, Account) {

		var ERROR = {
			FAILED_TO_GET_RATING: "Failed to get rating for content ",
			FAILED_TO_GET_RATINGS: "Failed to get ratings",
			FAILED_TO_SET_RATING: "Failed to set rating"
		};

		function Ratings(contentDiscoveryGatewayService) {
			this._log = new $N.apps.core.Log("contentdiscovery", "Ratings");
			this._contentDiscoveryGatewayService = contentDiscoveryGatewayService;
		}

		/**
		 * Sets rating for the current account
		 * @method setRatingByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {Object} ratingRequest ratingRequest object
		 */
		Ratings.prototype.setRatingByAccount = function (callback, account, ratingRequest) {
			var me = this,
				successCallback = function (response) {
					callback(true);
				},
				failureCallback = function () {
					me._log("setRatingByAccount", ERROR.FAILED_TO_SET_RATING);
					callback(false);
				};

			this._contentDiscoveryGatewayService.setRatingByAccount(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				ratingRequest
			);
		};

		/**
		 * Sets rating for the current account and user
		 * @method setRatingByAccountAndUser
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {Object} ratingRequest ratingRequest object
		 */
		Ratings.prototype.setRatingByAccountAndUser = function (callback, account, user, ratingRequest) {
			var me = this,
				successCallback = function (response) {
					callback(true);
				},
				failureCallback = function () {
					me._log("setRatingByAccountAndUser", ERROR.FAILED_TO_SET_RATING);
					callback(false);
				};

			this._contentDiscoveryGatewayService.setRatingByAccountAndUser(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				user,
				ratingRequest
			);
		};

		/**
		 * Returns ratings for the current account
		 * @method fetchRatingsByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 */
		Ratings.prototype.fetchRatingsByAccount = function (callback, account) {
			var me = this,
				successCallback = function (ratings) {
					callback(ratings);
				},
				failureCallback = function () {
					me._log("fetchRatingsByAccount", ERROR.FAILED_TO_GET_RATINGS);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchRatingsByAccount(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber()
			);
		};

		/**
		 * Returns recommendations for the current account and user
		 * @method fetchRecommendationsByAccountAndUser
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 */
		Ratings.prototype.fetchRatingsByAccountAndUser = function (callback, account, user) {
			var me = this,
				successCallback = function (ratings) {
					callback(ratings);
				},
				failureCallback = function () {
					me._log("fetchRatingsByAccountAndUser", ERROR.FAILED_TO_GET_RATINGS);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchRatingsByAccountAndUser(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				user
			);
		};

		/**
		 * Returns ratings for the current account
		 * @method fetchRatingsByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {String} contentId id of the content for which rating is to be retrieved
		 */
		Ratings.prototype.fetchContentRatingByAccount = function (callback, account, contentId) {
			var me = this,
				successCallback = function (ratings) {
					callback(ratings);
				},
				failureCallback = function () {
					me._log("fetchContentRatingByAccount", ERROR.FAILED_TO_GET_RATING +  contentId);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchContentRatingByAccount(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				contentId
			);
		};

		/**
		 * Returns recommendations for the current account and user
		 * @method fetchRecommendationsByAccountAndUser
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {String} contentId id of the content for which rating is to be retrieved
		 */
		Ratings.prototype.fetchContentRatingByAccountAndUser = function (callback, account, user, contentId) {
			var me = this,
				successCallback = function (ratings) {
					callback(ratings);
				},
				failureCallback = function () {
					me._log("fetchContentRatingByAccountAndUser", ERROR.FAILED_TO_GET_RATING + contentId);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchContentRatingByAccountAndUser(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				user,
				contentId
			);
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.contentdiscovery = $N.services.contentdiscovery || {};
		$N.services.contentdiscovery.Ratings = Ratings;
		return Ratings;
	});
