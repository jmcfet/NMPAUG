/*global define, $N, window */
/**
 * Class that allows interaction with the head end locker service
 * @class $N.services.sdp.UserActivity
 * @constructor
 * @param {Object} contentDiscoveryGateway ContentDiscoveryGatewayService instance
*/
define('jsfw/services/contentdiscovery/UserActivity',
	[
		'jsfw/apps/core/Log',
		'jsfw/services/contentdiscovery/ContentDiscoveryGatewayService',
		'jsfw/services/sdp/Account'
	],
	function (Log, ContentDiscoveryGatewayService, Account) {

		var ERROR = {
			FAILED_TO_GET_USER_ACTIVITY: "Failed to get user activity",
			FAILED_TO_SET_USER_ACTIVITY: "Failed to set user activity",
			FAILED_TO_DELETE_USER_ACTIVITY: "Failed to delete user activity"
		};

		function UserActivity(contentDiscoveryGatewayService) {
			this._log = new $N.apps.core.Log("contentdiscovery", "UserActivity");
			this._contentDiscoveryGatewayService = contentDiscoveryGatewayService;
		}

		/**
		 * Sets user activity for the current account
		 * @method setUserActivityByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} activityName name of activity
		 * @param {Object} userActivity userActivity object
		 */
		UserActivity.prototype.setUserActivityByAccount = function (callback, account, activityName, userActivity) {
			var me = this,
				successCallback = function (response) {
					callback(true);
				},
				failureCallback = function () {
					me._log("setUserActivityByAccount", ERROR.FAILED_TO_SET_USER_ACTIVITY);
					callback(false);
				};

			this._contentDiscoveryGatewayService.setUserActivityByAccount(
				successCallback,
				failureCallback,
				activityName,
				account || $N.services.sdp.Account.getAccountNumber(),
				userActivity
			);
		};

		/**
		 * Sets user activity for the current account and user
		 * @method setUserActivityByAccountAndUser
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {String} activityName name of activity
		 * @param {Object} userActivity userActivity object
		 */
		UserActivity.prototype.setUserActivityByAccountAndUser = function (callback, account, user, activityName, userActivity) {
			var me = this,
				successCallback = function (response) {
					callback(true);
				},
				failureCallback = function () {
					me._log("setUserActivityByAccountAndUser", ERROR.FAILED_TO_SET_USER_ACTIVITY);
					callback(false);
				};

			this._contentDiscoveryGatewayService.setUserActivityByAccountAndUser(
				successCallback,
				failureCallback,
				activityName,
				account || $N.services.sdp.Account.getAccountNumber(),
				user,
				userActivity
			);
		};

		/**
		 * Returns user activity for the current account
		 * @method fetchRecommendationsByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} activityName name of activity
		 */
		UserActivity.prototype.fetchUserActivityByAccount = function (callback, account, activityName) {
			var me = this,
				successCallback = function (useractivity) {
					callback(useractivity);
				},
				failureCallback = function () {
					me._log("fetchUserActivityByAccount", ERROR.FAILED_TO_GET_USER_ACTIVITY);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchUserActivityByAccount(
				successCallback,
				failureCallback,
				activityName,
				account || $N.services.sdp.Account.getAccountNumber()
			);
		};

		/**
		 * Returns user activity for the current account and user
		 * @method fetchRecommendationsByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {String} activityName name of activity
		 */
		UserActivity.prototype.fetchUserActivityByAccountAndUser = function (callback, account, user, activityName) {
			var me = this,
				successCallback = function (useractivity) {
					callback(useractivity);
				},
				failureCallback = function () {
					me._log("fetchUserActivityByAccountAndUser", ERROR.FAILED_TO_GET_USER_ACTIVITY);
					callback(false);
				};

			this._contentDiscoveryGatewayService.fetchUserActivityByAccountAndUser(
				successCallback,
				failureCallback,
				activityName,
				account || $N.services.sdp.Account.getAccountNumber(),
				user
			);
		};

		/**
		 * Deletes user activity for the current account
		 * @method deleteUserActivityByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} deleteRequest delete request object
		 */
		UserActivity.prototype.deleteUserActivityByAccount = function (callback, account, deleteRequest) {
			var me = this,
				successCallback = function (useractivity) {
					callback(true);
				},
				failureCallback = function () {
					me._log("deleteUserActivityByAccount", ERROR.FAILED_TO_DELETE_USER_ACTIVITY);
					callback(false);
				},
				filterObject = {
					name: "deleteActivityRequest",
					filter: deleteRequest
				};

			this._contentDiscoveryGatewayService.deleteUserActivityByAccount(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				[filterObject]
			);
		};

		/**
		 * Deletes user activity by current account and user
		 * @method deleteUserActivityByAccount
		 * @param {Function} callback Callback function fired
		 * @param {String} account account number. If none provided it uses the currently signed on account.
		 * @param {String} user user name
		 * @param {String} deleteRequest delete request object
		 */
		UserActivity.prototype.deleteUserActivityByAccountAndUser = function (callback, account, user, deleteRequest) {
			var me = this,
				successCallback = function (useractivity) {
					callback(true);
				},
				failureCallback = function () {
					me._log("deleteUserActivityByAccountAndUser", ERROR.FAILED_TO_DELETE_USER_ACTIVITY);
					callback(false);
				},
				filterObject = {
					name: "deleteActivityRequest",
					filter: deleteRequest
				};

			this._contentDiscoveryGatewayService.deleteUserActivityByAccountAndUser(
				successCallback,
				failureCallback,
				account || $N.services.sdp.Account.getAccountNumber(),
				user,
				[filterObject]
			);
		};

		window.$N = $N || {};
		$N.services = $N.services || {};
		$N.services.contentdiscovery = $N.services.contentdiscovery || {};
		$N.services.contentdiscovery.UserActivity = UserActivity;
		return UserActivity;
	});
